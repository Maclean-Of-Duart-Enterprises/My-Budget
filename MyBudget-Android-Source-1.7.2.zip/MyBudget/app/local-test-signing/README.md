# My Budget local-development signing key

This directory intentionally contains `mybudget-local-test.keystore` at the user's request.

- Purpose: private sideloading and update continuity for the replacement-key 1.2.0 and the 1.3.0–1.7.1 builds
- Alias: `androiddebugkey`
- Store password: `android`
- Key password: `android`
- Certificate SHA-256: `2B:8B:C4:8C:FC:F4:F0:17:0A:80:F9:AA:10:60:5F:59:8F:EF:87:7C:1D:E0:16:68:1D:0B:B4:15:D8:F4:2F:A0`

This is not a protected release key. Anyone who receives this source bundle can sign APK updates under this development identity. Never use it for a public app store or a production release.

The original 1.0.0–1.2.0 APKs used certificate SHA-256 `E9:B9:EA:2B:23:D7:66:DF:17:A9:DC:B4:EF:4D:ED:B7:26:1B:32:09:BF:3D:B5:AF:E5:7C:2C:B1:C5:C2:A6:3A`; its private key was not retained and cannot be reconstructed from those APKs.
