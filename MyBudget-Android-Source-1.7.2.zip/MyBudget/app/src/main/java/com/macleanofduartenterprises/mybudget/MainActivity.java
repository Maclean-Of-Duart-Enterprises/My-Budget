package com.macleanofduartenterprises.mybudget;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int REQUEST_DOCUMENT = 100;
    private static final int REQUEST_BACKGROUND = 101;
    private static final int REQUEST_AVATAR = 102;
    private static final int REQUEST_CAMERA = 103;
    private static final int REQUEST_BANK_STATEMENT = 104;

    private BudgetDatabase database;
    private AppSettings settings;
    private CategoryStore categoryStore;
    private ManualBudgetStore manualBudgets;
    private PasscodeManager passcode;
    private SecureDocumentStore documents;
    private OcrEngine ocr;
    private LanguageManager language;
    private BudgetAgent agent;
    private final DocumentTextParser parser = new DocumentTextParser();
    private final BankStatementParser statementParser = new BankStatementParser();
    private ReportGenerator reportGenerator;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private FrameLayout contentHost;
    private String currentScreen = "dashboard";
    private String reportMode = BudgetPeriod.WEEKLY;
    private String budgetMode = BudgetPeriod.MONTHLY;
    private String categoryReportPeriod = BudgetPeriod.WEEKLY;
    private String categoryReportType = TransactionRecord.EXPENSE;
    private String categoryReportCategory = "";
    private Uri pendingCameraUri;
    private File pendingCameraFile;
    private TransactionRecord draftBeforeDocument;
    private EditorFields editorFields;
    private TransactionRecord editorOriginal;
    private String statementReviewPath = "";
    private String statementReviewMime = "";
    private String statementReviewText = "";
    private String transactionAccountFilter = "";
    private boolean transactionManagementMode;
    private boolean transactionMutationInProgress;
    private final Set<Long> selectedTransactionIds = new HashSet<>();
    private final List<SelectedUpload> pendingDocumentUploads = new ArrayList<>();
    private final List<SelectedUpload> pendingStatementUploads = new ArrayList<>();
    private boolean documentBatchActive;
    private int documentBatchTotal;
    private int documentBatchCompleted;
    private int documentBatchSaved;
    private int documentBatchFailed;
    private boolean statementBatchActive;
    private boolean statementBatchManualEditor;
    private int statementBatchTotal;
    private int statementBatchCompleted;
    private int statementBatchImported;
    private int statementBatchTransactions;
    private int statementBatchFailed;
    private long pausedAt;
    private boolean lockShown;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        database = new BudgetDatabase(this);
        settings = new AppSettings(this);
        categoryStore = new CategoryStore(this);
        manualBudgets = new ManualBudgetStore(this);
        refreshLocalization();
        passcode = new PasscodeManager(this);
        documents = new SecureDocumentStore(this);
        ocr = new OcrEngine(this);
        getWindow().setStatusBarColor(Color.rgb(13, 38, 31));
        getWindow().setNavigationBarColor(Color.rgb(13, 38, 31));
        buildShell("dashboard");
        if (passcode.hasPasscode()) showUnlockDialog();
    }

    @Override protected void onPause() {
        super.onPause();
        pausedAt = System.currentTimeMillis();
    }

    @Override protected void onResume() {
        super.onResume();
        int timeout = settings.lockTimeoutSeconds();
        long awayFor = pausedAt == 0 ? 0 : System.currentTimeMillis() - pausedAt;
        boolean automaticLockDue = LockPolicy.shouldLock(timeout, awayFor);
        if (pausedAt > 0 && automaticLockDue && passcode.hasPasscode() && !lockShown) {
            showUnlockDialog();
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
        if (ocr != null) ocr.close();
        if (database != null) database.close();
    }

    @Override public void onBackPressed() {
        if (transactionMutationInProgress) {
            Toast.makeText(this, t("Please wait while the local transaction task finishes."),
                    Toast.LENGTH_SHORT).show();
            return;
        }
        if ("transactions".equals(currentScreen) && transactionManagementMode) {
            transactionManagementMode = false;
            selectedTransactionIds.clear();
            showScreen("transactions");
            return;
        }
        if ("license".equals(currentScreen)) {
            showScreen("settings");
            return;
        }
        if ("statement_review".equals(currentScreen)) {
            discardStatementReview();
            if (statementBatchActive) {
                statementBatchCompleted++;
                processNextStatementUpload();
            } else {
                buildShell("dashboard");
            }
            return;
        }
        if ("statement_processing".equals(currentScreen) || "statement_importing".equals(currentScreen)) {
            Toast.makeText(this, t("Please wait while the local statement task finishes."), Toast.LENGTH_SHORT).show();
            return;
        }
        if ("document_processing".equals(currentScreen)) {
            Toast.makeText(this, t("Please wait while the local document task finishes."), Toast.LENGTH_SHORT).show();
            return;
        }
        if ("editor".equals(currentScreen) && (documentBatchActive || statementBatchManualEditor)) {
            cancelEditor();
            return;
        }
        super.onBackPressed();
    }

    private void buildShell(String screen) {
        currentScreen = screen;
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(settings.backgroundColor());
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });

        String backgroundPath = settings.backgroundPath();
        if (!backgroundPath.isEmpty() && new File(backgroundPath).exists()) {
            ImageView background = new ImageView(this);
            background.setScaleType(ImageView.ScaleType.CENTER_CROP);
            background.setImageBitmap(loadScaled(backgroundPath, 1800));
            background.setAlpha(settings.backgroundOpacity() / 100f);
            background.setContentDescription(t("Custom background"));
            root.addView(background, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        root.addView(shell, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        shell.addView(buildHeader());
        contentHost = new FrameLayout(this);
        shell.addView(contentHost, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        shell.addView(buildNavigation(screen));
        setContentView(root);
        showScreen(screen);
    }

    private View buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(UiKit.dp(this, 14), UiKit.dp(this, 9), UiKit.dp(this, 14), UiKit.dp(this, 9));
        header.setBackgroundColor(Color.rgb(22, 56, 46));

        ImageView avatar = new ImageView(this);
        int avatarSize = UiKit.dp(this, 48);
        avatar.setLayoutParams(new LinearLayout.LayoutParams(avatarSize, avatarSize));
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable avatarBackground = new GradientDrawable();
        avatarBackground.setShape(GradientDrawable.OVAL);
        avatarBackground.setColor(Color.rgb(201, 167, 80));
        avatar.setBackground(avatarBackground);
        avatar.setClipToOutline(true);
        String avatarPath = settings.avatarPath();
        if (!avatarPath.isEmpty() && new File(avatarPath).exists()) avatar.setImageBitmap(loadScaled(avatarPath, 512));
        else avatar.setImageResource(com.macleanofduartenterprises.mybudget.R.drawable.ic_launcher_foreground);
        avatar.setContentDescription(t("Budget avatar"));
        avatar.setOnClickListener(view -> {
            if (uploadTaskBlocksNavigation()) showUploadNavigationMessage();
            else showScreen("settings");
        });
        header.addView(avatar);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(UiKit.dp(this, 12), 0, 0, 0);
        titles.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView title = new TextView(this);
        title.setText(t("My Budget"));
        title.setTextColor(Color.WHITE);
        title.setTextSize(21);
        title.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        TextView privacy = new TextView(this);
        privacy.setText(t("Private • Offline • On this device"));
        privacy.setTextColor(Color.rgb(224, 215, 184));
        privacy.setTextSize(11);
        titles.addView(title);
        titles.addView(privacy);
        header.addView(titles);

        Button quickAdd = UiKit.goldButton(this, t("+ Add"));
        quickAdd.setLayoutParams(new LinearLayout.LayoutParams(UiKit.dp(this, 82), UiKit.dp(this, 44)));
        quickAdd.setOnClickListener(view -> {
            if (uploadTaskBlocksNavigation()) showUploadNavigationMessage();
            else showEditor(new TransactionRecord());
        });
        header.addView(quickAdd);
        return header;
    }

    private View buildNavigation(String selected) {
        LinearLayout navigation = new LinearLayout(this);
        navigation.setGravity(Gravity.CENTER);
        navigation.setPadding(UiKit.dp(this, 4), UiKit.dp(this, 5), UiKit.dp(this, 4), UiKit.dp(this, 4));
        navigation.setBackgroundColor(Color.rgb(13, 38, 31));
        addNav(navigation, t("Home"), "dashboard", selected);
        addNav(navigation, t("Transactions"), "transactions", selected);
        addNav(navigation, t("Scan"), "scan", selected);
        addNav(navigation, t("Reports"), "reports", selected);
        addNav(navigation, t("Settings"), "settings", selected);
        return navigation;
    }

    private void addNav(LinearLayout row, String label, String screen, String selected) {
        TextView item = new TextView(this);
        item.setText(label);
        item.setGravity(Gravity.CENTER);
        item.setTextSize(11);
        item.setTypeface(Typeface.create(Typeface.DEFAULT, screen.equals(selected) ? Typeface.BOLD : Typeface.NORMAL));
        item.setTextColor(screen.equals(selected) ? Color.rgb(201, 167, 80) : Color.WHITE);
        item.setPadding(UiKit.dp(this, 2), UiKit.dp(this, 10), UiKit.dp(this, 2), UiKit.dp(this, 10));
        item.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        item.setContentDescription(label);
        item.setOnClickListener(view -> {
            if (uploadTaskBlocksNavigation()) {
                showUploadNavigationMessage();
                return;
            }
            if ("scan".equals(screen)) showScanChoices();
            else showScreen(screen);
        });
        row.addView(item);
    }

    private boolean uploadTaskBlocksNavigation() {
        return documentBatchActive || statementBatchActive || transactionMutationInProgress
                || "document_processing".equals(currentScreen)
                || "statement_processing".equals(currentScreen)
                || "statement_importing".equals(currentScreen)
                || "statement_review".equals(currentScreen);
    }

    private void showUploadNavigationMessage() {
        Toast.makeText(this, t(transactionMutationInProgress
                        ? "Please wait while the local transaction task finishes."
                        : "Finish or skip the current upload before leaving this screen."),
                Toast.LENGTH_SHORT).show();
    }

    private void showScreen(String screen) {
        if (!"transactions".equals(screen)) {
            transactionManagementMode = false;
            selectedTransactionIds.clear();
        }
        currentScreen = screen;
        if (contentHost == null) return;
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(UiKit.dp(this, 14), UiKit.dp(this, 14), UiKit.dp(this, 14), UiKit.dp(this, 28));
        scroll.addView(page, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        contentHost.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        switch (screen) {
            case "transactions": renderTransactions(page); break;
            case "reports": renderReports(page); break;
            case "settings": renderSettings(page); break;
            case "license": renderLicense(page); break;
            default: renderDashboard(page); break;
        }
    }

    private void renderDashboard(LinearLayout page) {
        List<TransactionRecord> all = database.all("timestamp", false);
        long now = System.currentTimeMillis();
        BudgetPlan plan = agent.createPlan(all, now, budgetMode);
        long monthStart = startOfMonth();
        PeriodReport month = agent.createReport(all, monthStart, startOfNextMonth(), t("This month"));
        PeriodReport budgetActual = currentPeriodReport(all, budgetMode,
                t(BudgetPeriod.isWeekly(budgetMode) ? "This week" : "This month"));

        page.addView(UiKit.heading(this, settings, t("Your budget at a glance")));
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button scan = UiKit.goldButton(this, t("Add document or statement"));
        Button manual = UiKit.primaryButton(this, t("Enter manually"));
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        left.setMargins(0, 0, UiKit.dp(this, 5), 0);
        scan.setLayoutParams(left);
        LinearLayout.LayoutParams right = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        right.setMargins(UiKit.dp(this, 5), 0, 0, 0);
        manual.setLayoutParams(right);
        scan.setOnClickListener(view -> showScanChoices());
        manual.setOnClickListener(view -> showEditor(new TransactionRecord()));
        actions.addView(scan);
        actions.addView(manual);
        page.addView(actions);

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        metrics.addView(metricCard(t("Income"), Money.format(month.income), Color.rgb(22, 111, 78)), UiKit.weighted(1));
        metrics.addView(metricCard(t("Spent"), Money.format(month.expenses), Color.rgb(155, 60, 52)), UiKit.weighted(1));
        metrics.addView(metricCard(t("Net"), Money.format(month.net), month.net >= 0 ? Color.rgb(22, 111, 78) : Color.rgb(155, 60, 52)), UiKit.weighted(1));
        page.addView(metrics);

        page.addView(budgetPeriodTabs("dashboard"));
        page.addView(manualBudgetPanel(manualBudgets.load(budgetMode), budgetActual.spendingByCategory,
                6, "dashboard", budgetMode));

        LinearLayout agentPanel = UiKit.panel(this, settings);
        agentPanel.addView(UiKit.heading(this, settings, t(BudgetPeriod.isWeekly(budgetMode)
                ? "AI weekly budget" : "AI monthly budget")));
        agentPanel.addView(UiKit.caption(this, settings,
                plan.confidencePercent == 0 ? t("Waiting for spending history")
                        : t("Learned-plan confidence: %1$d%% from %2$d days", plan.confidencePercent, plan.historyDays)));
        if (plan.categoryLimits.isEmpty()) {
            agentPanel.addView(UiKit.text(this, settings, plan.insights.get(0), 0, false));
        } else {
            Map<String, Long> spent = budgetActual.spendingByCategory;
            int shown = 0;
            for (Map.Entry<String, Long> entry : plan.categoryLimits.entrySet()) {
                if (shown++ == 6) break;
                long actual = spent.getOrDefault(entry.getKey(), 0L);
                agentPanel.addView(budgetProgress(entry.getKey(), actual, entry.getValue()));
            }
            for (String insight : plan.insights) agentPanel.addView(bullet(insight));
        }
        page.addView(agentPanel);

        LinearLayout recentPanel = UiKit.panel(this, settings);
        recentPanel.addView(UiKit.heading(this, settings, t("Recent transactions")));
        if (all.isEmpty()) recentPanel.addView(UiKit.text(this, settings, t("No transactions yet. Scan a document or enter one manually."), 0, false));
        else {
            for (int i = 0; i < Math.min(5, all.size()); i++) recentPanel.addView(transactionRow(all.get(i)));
            Button allButton = UiKit.secondaryButton(this, settings, t("View all transactions"));
            allButton.setOnClickListener(view -> buildShell("transactions"));
            recentPanel.addView(allButton);
        }
        page.addView(recentPanel);
    }

    private View metricCard(String label, String value, int valueColor) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(UiKit.dp(this, 5), UiKit.dp(this, 14), UiKit.dp(this, 5), UiKit.dp(this, 14));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        params.setMargins(UiKit.dp(this, 3), UiKit.dp(this, 12), UiKit.dp(this, 3), UiKit.dp(this, 12));
        card.setLayoutParams(params);
        card.setBackground(UiKit.roundRect(settings.boxColor(), settings.boxOpacity(), UiKit.dp(this, 14), 0, 0));
        TextView caption = UiKit.caption(this, settings, label);
        caption.setGravity(Gravity.CENTER);
        TextView amount = UiKit.text(this, settings, value, 0, true);
        amount.setTextColor(valueColor);
        amount.setGravity(Gravity.CENTER);
        amount.setAutoSizeTextTypeUniformWithConfiguration(10, 18, 1, TextView.AUTO_SIZE_TEXT_TYPE_UNIFORM);
        card.addView(caption);
        card.addView(amount);
        return card;
    }

    private View budgetProgress(String category, long actual, long limit) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, UiKit.dp(this, 8), 0, UiKit.dp(this, 6));
        LinearLayout labels = new LinearLayout(this);
        TextView name = UiKit.text(this, settings, language.category(category), -2, true);
        name.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView amount = UiKit.caption(this, settings, Money.format(actual) + " / " + Money.format(limit));
        labels.addView(name);
        labels.addView(amount);
        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress((int) Math.min(100, limit == 0 ? 0 : actual * 100 / limit));
        progress.setProgressTintList(ColorStateList.valueOf(actual <= limit ? Color.rgb(201, 167, 80) : Color.rgb(164, 62, 54)));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(UiKit.withAlpha(settings.textColor(), 15)));
        wrap.addView(labels);
        wrap.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UiKit.dp(this, 9)));
        return wrap;
    }

    private View budgetPeriodTabs(String returnScreen) {
        LinearLayout panel = UiKit.panel(this, settings);
        panel.addView(UiKit.heading(this, settings, t("Budget period")));
        panel.addView(UiKit.caption(this, settings,
                t("Switch between independent weekly and monthly manual and AI budgets.")));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button weekly = BudgetPeriod.isWeekly(budgetMode)
                ? UiKit.goldButton(this, t("Weekly"))
                : UiKit.secondaryButton(this, settings, t("Weekly"));
        Button monthly = BudgetPeriod.isWeekly(budgetMode)
                ? UiKit.secondaryButton(this, settings, t("Monthly"))
                : UiKit.goldButton(this, t("Monthly"));
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        left.setMargins(0, 0, UiKit.dp(this, 5), 0);
        weekly.setLayoutParams(left);
        LinearLayout.LayoutParams right = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        right.setMargins(UiKit.dp(this, 5), 0, 0, 0);
        monthly.setLayoutParams(right);
        weekly.setOnClickListener(view -> {
            budgetMode = BudgetPeriod.WEEKLY;
            showScreen(returnScreen);
        });
        monthly.setOnClickListener(view -> {
            budgetMode = BudgetPeriod.MONTHLY;
            showScreen(returnScreen);
        });
        row.addView(weekly);
        row.addView(monthly);
        panel.addView(row);
        return panel;
    }

    private PeriodReport currentPeriodReport(List<TransactionRecord> records, String period, String title) {
        if (BudgetPeriod.isWeekly(period)) {
            return agent.createReport(records, startOfWeek(), startOfNextWeek(), title);
        }
        return agent.createReport(records, startOfMonth(), startOfNextMonth(), title);
    }

    private View manualBudgetPanel(ManualBudget budget, Map<String, Long> spending,
                                   int maximumCategories, String returnScreen, String requestedPeriod) {
        String period = BudgetPeriod.normalize(requestedPeriod);
        LinearLayout panel = UiKit.panel(this, settings);
        panel.addView(UiKit.heading(this, settings, t(BudgetPeriod.isWeekly(period)
                ? "Manual weekly budget" : "Manual monthly budget")));
        panel.addView(UiKit.caption(this, settings,
                t("Your editable limits stay separate from the AI-suggested budget.")));
        if (!budget.isConfigured()) {
            panel.addView(UiKit.text(this, settings,
                    t("Create your own income, savings, and category limits, or start from the AI suggestion."), 0, false));
        } else {
            addDetail(panel, t("Expected income"), Money.format(budget.expectedMonthlyIncome));
            addDetail(panel, t("Category allocation"), Money.format(budget.totalAllocated()));
            addDetail(panel, t("Savings target"), Money.format(budget.savingsTarget));
            if (budget.expectedMonthlyIncome > 0) {
                addDetail(panel, t("Planned remainder"), Money.format(budget.plannedRemainder()));
            }
            int shown = 0;
            for (Map.Entry<String, Long> entry : budget.categoryLimits.entrySet()) {
                if (shown++ >= maximumCategories) break;
                panel.addView(budgetProgress(entry.getKey(), spending.getOrDefault(entry.getKey(), 0L), entry.getValue()));
            }
            if (budget.expectedMonthlyIncome > 0 && budget.plannedRemainder() < 0) {
                panel.addView(bullet(t("Manual limits and savings exceed expected income by %s.",
                        Money.format(-budget.plannedRemainder()))));
            }
        }
        Button edit = UiKit.primaryButton(this, t(budget.isConfigured() ? "Edit manual budget" : "Create manual budget"));
        edit.setOnClickListener(view -> showManualBudgetEditor(period, returnScreen));
        panel.addView(edit);
        return panel;
    }

    private void showManualBudgetEditor(String requestedPeriod, String returnScreen) {
        String period = BudgetPeriod.normalize(requestedPeriod);
        String destination = returnScreen == null ? "dashboard" : returnScreen;
        ManualBudget current = manualBudgets.load(period);
        currentScreen = "manual_budget";
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(UiKit.dp(this, 14), UiKit.dp(this, 14), UiKit.dp(this, 14), UiKit.dp(this, 32));
        scroll.addView(page);
        contentHost.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        page.addView(UiKit.heading(this, settings, t(current.isConfigured() ? "Edit manual budget" : "Create manual budget")));
        page.addView(UiKit.caption(this, settings,
                t(BudgetPeriod.isWeekly(period)
                        ? "Enter weekly amounts. A blank or zero category removes that limit."
                        : "Enter monthly amounts. A blank or zero category removes that limit.")));
        LinearLayout panel = UiKit.panel(this, settings);
        panel.addView(UiKit.caption(this, settings, t("Expected income")));
        EditText income = UiKit.moneyInput(this, settings, "0.00");
        setMoneyText(income, current.expectedMonthlyIncome);
        panel.addView(income);
        panel.addView(UiKit.caption(this, settings, t("Savings target")));
        EditText savings = UiKit.moneyInput(this, settings, "0.00");
        setMoneyText(savings, current.savingsTarget);
        panel.addView(savings);
        panel.addView(UiKit.heading(this, settings, t(BudgetPeriod.isWeekly(period)
                ? "Weekly category limits" : "Monthly category limits")));

        Map<String, EditText> categoryInputs = new LinkedHashMap<>();
        List<String> expenseCategories = categoriesFor(TransactionRecord.EXPENSE);
        for (String category : expenseCategories) {
            panel.addView(UiKit.caption(this, settings, language.category(category)));
            EditText input = UiKit.moneyInput(this, settings, "0.00");
            setMoneyText(input, current.categoryLimits.getOrDefault(category, 0L));
            categoryInputs.put(category, input);
            panel.addView(input);
        }

        Button useAi = UiKit.goldButton(this, t("Use AI suggestions as a starting point"));
        useAi.setOnClickListener(view -> {
            BudgetPlan suggestion = agent.createPlan(database.all("timestamp", false),
                    System.currentTimeMillis(), period);
            if (suggestion.categoryLimits.isEmpty()) {
                Toast.makeText(this, t("Add more transaction history before using an AI starting point."), Toast.LENGTH_LONG).show();
                return;
            }
            setMoneyText(income, suggestion.expectedMonthlyIncome);
            setMoneyText(savings, suggestion.savingsTarget);
            for (String category : expenseCategories) {
                setMoneyText(categoryInputs.get(category), suggestion.categoryLimits.getOrDefault(category, 0L));
            }
            Toast.makeText(this, t("AI suggestions copied. Review and save your manual budget."), Toast.LENGTH_LONG).show();
        });
        panel.addView(useAi);

        Button save = UiKit.primaryButton(this, t("Save manual budget"));
        save.setOnClickListener(view -> {
            ManualBudget edited = new ManualBudget();
            edited.expectedMonthlyIncome = Money.parseCents(income.getText().toString());
            edited.savingsTarget = Money.parseCents(savings.getText().toString());
            for (Map.Entry<String, EditText> entry : categoryInputs.entrySet()) {
                long value = Money.parseCents(entry.getValue().getText().toString());
                if (value > 0) edited.categoryLimits.put(entry.getKey(), value);
            }
            if (edited.expectedMonthlyIncome <= 0 && edited.savingsTarget <= 0 && edited.categoryLimits.isEmpty()) {
                income.setError(t(BudgetPeriod.isWeekly(period)
                        ? "Enter at least one weekly amount." : "Enter at least one monthly amount."));
                income.requestFocus();
                return;
            }
            edited.updatedAt = System.currentTimeMillis();
            manualBudgets.save(period, edited);
            Toast.makeText(this, t("Manual budget saved"), Toast.LENGTH_SHORT).show();
            buildShell(destination);
        });
        panel.addView(save);

        if (current.isConfigured()) {
            Button clear = UiKit.secondaryButton(this, settings, t("Clear manual budget"));
            clear.setTextColor(Color.rgb(150, 42, 37));
            clear.setOnClickListener(view -> new AlertDialog.Builder(this)
                    .setTitle(t("Clear the manual budget?"))
                    .setMessage(t("Your AI suggestions and transactions will not be changed."))
                    .setNegativeButton(t("Cancel"), null)
                    .setPositiveButton(t("Clear"), (dialog, which) -> {
                        manualBudgets.clear(period);
                        Toast.makeText(this, t("Manual budget cleared"), Toast.LENGTH_SHORT).show();
                        buildShell(destination);
                    }).show());
            panel.addView(clear);
        }
        Button cancel = UiKit.secondaryButton(this, settings, t("Cancel"));
        cancel.setOnClickListener(view -> buildShell(destination));
        panel.addView(cancel);
        page.addView(panel);
    }

    private void setMoneyText(EditText input, long cents) {
        if (input == null) return;
        input.setText(cents > 0 ? String.format(language.locale(), "%.2f", cents / 100.0) : "");
    }

    private void renderTransactions(LinearLayout page) {
        page.addView(UiKit.heading(this, settings, t("Transactions")));
        List<TransactionRecord> history = database.all("timestamp", false);
        Set<Long> existingIds = new HashSet<>();
        for (TransactionRecord record : history) existingIds.add(record.id);
        selectedTransactionIds.retainAll(existingIds);
        Map<String, String> accounts = new LinkedHashMap<>();
        for (TransactionRecord record : history) {
            if (record.accountId == null || record.accountId.isEmpty()) continue;
            String label = record.accountName == null || record.accountName.isEmpty()
                    ? record.bankName : record.accountName;
            accounts.putIfAbsent(record.accountId, label == null || label.isEmpty()
                    ? t("Imported account") : label);
        }
        page.addView(UiKit.caption(this, settings,
                t("Combined history • %1$d bank accounts • %2$d transactions",
                        accounts.size(), history.size())));
        TextView sort = UiKit.caption(this, settings, t("Sorted by %1$s • %2$s. Change this in Settings.",
                friendlySort(settings.sortField()), t(settings.sortAscending() ? "ascending" : "descending")));
        page.addView(sort);

        TransactionManagementUi management = transactionManagementMode
                ? new TransactionManagementUi() : null;
        if (!history.isEmpty() && !transactionManagementMode) {
            Button manage = UiKit.goldButton(this, t("Manage transactions"));
            manage.setOnClickListener(view -> {
                selectedTransactionIds.clear();
                transactionManagementMode = true;
                showScreen("transactions");
            });
            page.addView(manage);
        } else if (management != null) {
            LinearLayout controls = UiKit.panel(this, settings);
            controls.addView(UiKit.heading(this, settings, t("Transaction management")));
            controls.addView(UiKit.caption(this, settings,
                    t("Select one transaction for full editing, or select several to replace checked fields or delete them together.")));
            management.status = UiKit.text(this, settings, "", -1, true);
            controls.addView(management.status);

            LinearLayout selectActions = new LinearLayout(this);
            selectActions.setOrientation(LinearLayout.HORIZONTAL);
            management.selectAll = UiKit.secondaryButton(this, settings, t("Select all shown"));
            management.clear = UiKit.secondaryButton(this, settings, t("Clear selection"));
            LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            left.setMargins(0, 0, UiKit.dp(this, 5), 0);
            management.selectAll.setLayoutParams(left);
            LinearLayout.LayoutParams right = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            right.setMargins(UiKit.dp(this, 5), 0, 0, 0);
            management.clear.setLayoutParams(right);
            selectActions.addView(management.selectAll);
            selectActions.addView(management.clear);
            controls.addView(selectActions);

            management.edit = UiKit.primaryButton(this, t("Edit or replace selected"));
            management.delete = UiKit.secondaryButton(this, settings, t("Delete selected"));
            management.delete.setTextColor(Color.rgb(150, 42, 37));
            Button done = UiKit.secondaryButton(this, settings, t("Done managing"));
            controls.addView(management.edit);
            controls.addView(management.delete);
            controls.addView(done);
            page.addView(controls);

            management.selectAll.setOnClickListener(view -> {
                selectedTransactionIds.addAll(management.visibleIds);
                if (management.refresh != null) management.refresh.run();
            });
            management.clear.setOnClickListener(view -> {
                selectedTransactionIds.clear();
                if (management.refresh != null) management.refresh.run();
            });
            management.edit.setOnClickListener(view -> {
                if (selectedTransactionIds.size() == 1) {
                    long id = selectedTransactionIds.iterator().next();
                    TransactionRecord record = database.byId(id);
                    transactionManagementMode = false;
                    selectedTransactionIds.clear();
                    if (record != null) showEditor(record.copy());
                    else showScreen("transactions");
                } else if (selectedTransactionIds.size() > 1) {
                    showBulkEditDialog(new HashSet<>(selectedTransactionIds));
                }
            });
            management.delete.setOnClickListener(view -> {
                if (!selectedTransactionIds.isEmpty()) {
                    confirmDeleteSelected(new HashSet<>(selectedTransactionIds));
                }
            });
            done.setOnClickListener(view -> {
                transactionManagementMode = false;
                selectedTransactionIds.clear();
                showScreen("transactions");
            });
        }

        EditText search = UiKit.input(this, settings, t("Search merchant, category, or note"));
        page.addView(search);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        if (accounts.size() > 1) {
            List<String> accountIds = new ArrayList<>();
            List<String> accountLabels = new ArrayList<>();
            accountIds.add("");
            accountLabels.add(t("All bank accounts"));
            for (Map.Entry<String, String> entry : accounts.entrySet()) {
                accountIds.add(entry.getKey());
                accountLabels.add(entry.getValue());
            }
            Spinner accountFilter = spinner(accountLabels);
            int selected = accountIds.indexOf(transactionAccountFilter);
            accountFilter.setSelection(Math.max(0, selected), false);
            accountFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                private boolean first = true;
                @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (first) { first = false; return; }
                    transactionAccountFilter = accountIds.get(position);
                    populateTransactions(list, search.getText().toString(), management);
                }
                @Override public void onNothingSelected(AdapterView<?> parent) {}
            });
            page.addView(accountFilter);
        } else {
            transactionAccountFilter = "";
        }
        page.addView(list);
        Runnable refresh = () -> populateTransactions(list, search.getText().toString(), management);
        if (management != null) management.refresh = refresh;
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { refresh.run(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        refresh.run();
    }

    private void populateTransactions(LinearLayout container, String query,
                                      TransactionManagementUi management) {
        container.removeAllViews();
        if (management != null) management.visibleIds.clear();
        String needle = query == null ? "" : query.trim().toLowerCase(language.locale());
        List<TransactionRecord> all = database.all(settings.sortField(), settings.sortAscending());
        int count = 0;
        for (TransactionRecord record : all) {
            if (!transactionAccountFilter.isEmpty()
                    && !transactionAccountFilter.equals(record.accountId)) continue;
            String haystack = (record.merchant + " " + record.category + " "
                    + language.category(record.category) + " " + record.note + " "
                    + record.bankName + " " + record.accountName)
                    .toLowerCase(language.locale());
            if (!needle.isEmpty() && !haystack.contains(needle)) continue;
            LinearLayout panel = UiKit.panel(this, settings);
            panel.setPadding(UiKit.dp(this, 12), UiKit.dp(this, 4), UiKit.dp(this, 12), UiKit.dp(this, 4));
            if (management == null) panel.addView(transactionRow(record));
            else {
                management.visibleIds.add(record.id);
                panel.addView(selectableTransactionRow(record, management));
            }
            container.addView(panel);
            count++;
        }
        if (count == 0) {
            LinearLayout empty = UiKit.panel(this, settings);
            empty.addView(UiKit.text(this, settings, t(needle.isEmpty() ? "No transactions yet." : "No transactions match your search."), 0, false));
            Button add = UiKit.primaryButton(this, t("Add a transaction"));
            add.setOnClickListener(view -> showEditor(new TransactionRecord()));
            empty.addView(add);
            container.addView(empty);
        }
        if (management != null) updateTransactionManagementUi(management);
    }

    private View selectableTransactionRow(TransactionRecord record,
                                          TransactionManagementUi management) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setGravity(Gravity.CENTER_VERTICAL);
        CheckBox selected = new CheckBox(this);
        selected.setChecked(selectedTransactionIds.contains(record.id));
        selected.setContentDescription(t("Select transaction: %s",
                record.merchant.isEmpty() ? language.category(record.category) : record.merchant));
        View row = transactionRow(record);
        row.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        selected.setOnCheckedChangeListener((button, checked) -> {
            if (checked) selectedTransactionIds.add(record.id);
            else selectedTransactionIds.remove(record.id);
            updateTransactionManagementUi(management);
        });
        row.setOnClickListener(view -> selected.setChecked(!selected.isChecked()));
        wrap.addView(selected);
        wrap.addView(row);
        return wrap;
    }

    private void updateTransactionManagementUi(TransactionManagementUi management) {
        if (management == null || management.status == null) return;
        int selected = selectedTransactionIds.size();
        management.status.setText(t("%1$d selected • %2$d shown", selected,
                management.visibleIds.size()));
        management.selectAll.setEnabled(!management.visibleIds.isEmpty());
        management.clear.setEnabled(selected > 0);
        management.edit.setEnabled(selected > 0);
        management.delete.setEnabled(selected > 0);
        management.edit.setText(selected == 0 ? t("Edit or replace selected")
                : t(selected == 1 ? "Edit or replace selected transaction"
                : "Replace fields in %d selected transactions", selected));
        management.delete.setText(selected == 0 ? t("Delete selected")
                : t(selected == 1 ? "Delete selected transaction"
                : "Delete %d selected transactions", selected));
    }

    private View transactionRow(TransactionRecord record) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, UiKit.dp(this, 9), 0, UiKit.dp(this, 9));
        row.setClickable(true);
        row.setFocusable(true);
        row.setContentDescription(t("%1$s %2$s at %3$s",
                t(TransactionRecord.INCOME.equals(record.type) ? "Income" : "Expense"),
                Money.format(record.amountCents), record.merchant));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        String party = record.merchant.trim().isEmpty() ? record.category : record.merchant;
        TextView merchant = UiKit.text(this, settings, party + (record.documentPath.isEmpty() ? "" : "  📎"), -1, true);
        String account = record.accountName == null || record.accountName.isEmpty()
                ? "" : " • " + record.accountName;
        String excluded = record.excludeFromBudget ? " • " + t("Excluded from budget") : "";
        TextView detail = UiKit.caption(this, settings, language.category(record.category)
                + " • " + date(record.timestamp) + account + excluded);
        info.addView(merchant);
        info.addView(detail);
        TextView amount = UiKit.text(this, settings,
                (TransactionRecord.INCOME.equals(record.type) ? "+" : "−") + Money.format(record.amountCents), -1, true);
        amount.setTextColor(TransactionRecord.INCOME.equals(record.type) ? Color.rgb(22, 111, 78) : Color.rgb(155, 60, 52));
        row.addView(info);
        row.addView(amount);
        row.setOnClickListener(view -> showTransactionDetail(record.id));
        return row;
    }

    private void showTransactionDetail(long id) {
        TransactionRecord record = database.byId(id);
        if (record == null) { showScreen("transactions"); return; }
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(UiKit.dp(this, 14), UiKit.dp(this, 14), UiKit.dp(this, 14), UiKit.dp(this, 28));
        scroll.addView(page);
        contentHost.addView(scroll);
        Button back = UiKit.secondaryButton(this, settings, t("← Back to transactions"));
        back.setOnClickListener(view -> showScreen("transactions"));
        page.addView(back);
        LinearLayout panel = UiKit.panel(this, settings);
        panel.addView(UiKit.heading(this, settings, record.merchant.isEmpty() ? language.category(record.category) : record.merchant));
        addDetail(panel, t("Amount"), Money.format(record.amountCents));
        addDetail(panel, t("Type"), t(TransactionRecord.INCOME.equals(record.type) ? "Income" : "Expense"));
        addDetail(panel, t("Category"), language.category(record.category));
        addDetail(panel, t("Date"), date(record.timestamp));
        if (record.bankName != null && !record.bankName.isEmpty()) {
            addDetail(panel, t("Bank or institution"), record.bankName);
        }
        if (record.accountName != null && !record.accountName.isEmpty()) {
            addDetail(panel, t("Bank account"), record.accountName);
        }
        addDetail(panel, t("AI budget and reports"), t(record.excludeFromBudget
                ? "Excluded as a transfer or adjustment" : "Included"));
        if (!record.note.isEmpty()) addDetail(panel, t("Note"), record.note);
        if (!record.documentPath.isEmpty()) {
            String documentLabel = TransactionRecord.DOCUMENT_BANK_STATEMENT.equals(record.documentKind)
                    ? "View bank statement"
                    : "application/pdf".equals(record.documentMime) ? "View document" : "View receipt or paystub";
            Button viewDocument = UiKit.goldButton(this, t(documentLabel));
            viewDocument.setOnClickListener(view -> openDocument(record));
            panel.addView(viewDocument);
        }
        Button edit = UiKit.primaryButton(this, t("Edit or replace transaction"));
        edit.setOnClickListener(view -> showEditor(record.copy()));
        Button delete = UiKit.secondaryButton(this, settings, t("Delete transaction"));
        delete.setTextColor(Color.rgb(150, 42, 37));
        delete.setOnClickListener(view -> confirmDelete(record));
        panel.addView(edit);
        panel.addView(delete);
        page.addView(panel);
    }

    private void addDetail(LinearLayout panel, String label, String value) {
        panel.addView(UiKit.caption(this, settings, label));
        TextView text = UiKit.text(this, settings, value, 0, false);
        text.setPadding(0, 0, 0, UiKit.dp(this, 10));
        panel.addView(text);
    }

    private void confirmDelete(TransactionRecord record) {
        String message = record.documentPath.isEmpty() ? "This cannot be undone."
                : database.documentReferenceCount(record.documentPath) > 1
                ? "The source bank statement will remain available from its other imported transactions."
                : "The attached document will also be deleted from the app.";
        new AlertDialog.Builder(this)
                .setTitle(t("Delete this transaction?"))
                .setMessage(t(message))
                .setNegativeButton(t("Cancel"), null)
                .setPositiveButton(t("Delete"), (dialog, which) -> {
                    database.delete(record.id);
                    deleteDocumentIfUnused(record.documentPath);
                    Toast.makeText(this, t("Transaction deleted"), Toast.LENGTH_SHORT).show();
                    buildShell("transactions");
                }).show();
    }

    private void confirmDeleteSelected(Set<Long> ids) {
        if (ids == null || ids.isEmpty()) return;
        Set<String> documentPaths = new HashSet<>();
        int existing = 0;
        for (Long id : ids) {
            if (id == null) continue;
            TransactionRecord record = database.byId(id);
            if (record == null) continue;
            existing++;
            if (record.documentPath != null && !record.documentPath.isEmpty()) {
                documentPaths.add(record.documentPath);
            }
        }
        if (existing == 0) {
            selectedTransactionIds.clear();
            showScreen("transactions");
            return;
        }
        int count = existing;
        new AlertDialog.Builder(this)
                .setTitle(t("Delete %d selected transactions?", count))
                .setMessage(t("Attached financial documents no longer used by another transaction will also be deleted. This cannot be undone."))
                .setNegativeButton(t("Cancel"), null)
                .setPositiveButton(t("Delete selected"), (dialog, which) -> {
                    transactionMutationInProgress = true;
                    showProgress(t("Deleting selected transactions…"),
                            t("Updating the local history and encrypted document storage."));
                    io.execute(() -> {
                        try {
                            int deleted = database.deleteAll(ids);
                            for (String path : documentPaths) deleteDocumentIfUnused(path);
                            runOnUiThread(() -> {
                                transactionMutationInProgress = false;
                                transactionManagementMode = false;
                                selectedTransactionIds.clear();
                                Toast.makeText(this, t("Deleted %d transactions", deleted),
                                        Toast.LENGTH_LONG).show();
                                buildShell("transactions");
                            });
                        } catch (Exception error) {
                            runOnUiThread(() -> {
                                transactionMutationInProgress = false;
                                Toast.makeText(this, t("The selected transactions could not be deleted."),
                                        Toast.LENGTH_LONG).show();
                                buildShell("transactions");
                            });
                        }
                    });
                }).show();
    }

    private void showBulkEditDialog(Set<Long> ids) {
        if (ids == null || ids.size() < 2) return;
        ScrollView scroll = new ScrollView(this);
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(UiKit.dp(this, 18), UiKit.dp(this, 8),
                UiKit.dp(this, 18), UiKit.dp(this, 8));
        scroll.addView(fields);
        fields.addView(UiKit.caption(this, settings,
                t("Only checked fields will be replaced. Attachments and original import fingerprints will remain unchanged.")));

        CheckBox replaceMerchant = bulkOption(t("Replace merchant or income source"));
        EditText merchant = UiKit.input(this, settings, t("New merchant or income source"));
        merchant.setEnabled(false);
        replaceMerchant.setOnCheckedChangeListener((button, checked) -> merchant.setEnabled(checked));
        fields.addView(replaceMerchant);
        fields.addView(merchant);

        CheckBox replaceAmount = bulkOption(t("Replace amount"));
        EditText amount = UiKit.moneyInput(this, settings, "0.00");
        amount.setEnabled(false);
        replaceAmount.setOnCheckedChangeListener((button, checked) -> amount.setEnabled(checked));
        fields.addView(replaceAmount);
        fields.addView(amount);

        CheckBox replaceType = bulkOption(t("Replace transaction type and category"));
        Spinner type = spinner(Arrays.asList(t("Expense"), t("Income")));
        Spinner category = spinner(language.categoryList(categoriesFor(TransactionRecord.EXPENSE)));
        type.setEnabled(false);
        category.setEnabled(false);
        replaceType.setOnCheckedChangeListener((button, checked) -> {
            type.setEnabled(checked);
            category.setEnabled(checked);
        });
        type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                setStatementCategoryAdapter(category, position == 1,
                        position == 1 ? "Other income" : "Other");
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        fields.addView(replaceType);
        fields.addView(UiKit.caption(this, settings, t("Transaction type")));
        fields.addView(type);
        fields.addView(UiKit.caption(this, settings, t("Category")));
        fields.addView(category);

        CheckBox replaceDate = bulkOption(t("Replace date"));
        long[] dateMillis = {System.currentTimeMillis()};
        Button dateButton = UiKit.secondaryButton(this, settings, date(dateMillis[0]));
        dateButton.setEnabled(false);
        replaceDate.setOnCheckedChangeListener((button, checked) -> dateButton.setEnabled(checked));
        dateButton.setOnClickListener(view -> {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(dateMillis[0]);
            DatePickerDialog picker = new DatePickerDialog(this, (chosen, year, month, day) -> {
                Calendar value = Calendar.getInstance();
                value.clear();
                value.set(year, month, day, 12, 0, 0);
                dateMillis[0] = value.getTimeInMillis();
                dateButton.setText(date(dateMillis[0]));
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH));
            picker.getDatePicker().setMaxDate(System.currentTimeMillis() + 86_400_000L);
            picker.show();
        });
        fields.addView(replaceDate);
        fields.addView(dateButton);

        CheckBox replaceNote = bulkOption(t("Replace or clear note"));
        EditText note = UiKit.input(this, settings, t("New note; leave blank to clear"));
        note.setSingleLine(false);
        note.setMinLines(2);
        note.setEnabled(false);
        replaceNote.setOnCheckedChangeListener((button, checked) -> note.setEnabled(checked));
        fields.addView(replaceNote);
        fields.addView(note);

        CheckBox replaceAccount = bulkOption(t("Replace or clear bank account association"));
        EditText bank = UiKit.input(this, settings, t("Bank or institution"));
        EditText account = UiKit.input(this, settings, t("Account name or last four digits"));
        bank.setEnabled(false);
        account.setEnabled(false);
        replaceAccount.setOnCheckedChangeListener((button, checked) -> {
            bank.setEnabled(checked);
            account.setEnabled(checked);
        });
        fields.addView(replaceAccount);
        fields.addView(UiKit.caption(this, settings,
                t("Enter both values, or leave both blank to remove the bank account association.")));
        fields.addView(bank);
        fields.addView(account);

        CheckBox replaceInclusion = bulkOption(t("Replace AI budget and report treatment"));
        Spinner inclusion = spinner(Arrays.asList(t("Include in AI budget and reports"),
                t("Exclude from AI budget and reports")));
        inclusion.setEnabled(false);
        replaceInclusion.setOnCheckedChangeListener((button, checked) -> inclusion.setEnabled(checked));
        fields.addView(replaceInclusion);
        fields.addView(inclusion);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(t("Replace fields in %d selected transactions", ids.size()))
                .setView(scroll)
                .setNegativeButton(t("Cancel"), null)
                .setPositiveButton(t("Apply replacements"), null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    TransactionBulkEdit edit = new TransactionBulkEdit();
                    edit.replaceMerchant = replaceMerchant.isChecked();
                    edit.merchant = merchant.getText().toString().trim();
                    edit.replaceAmount = replaceAmount.isChecked();
                    edit.amountCents = Money.parseCents(amount.getText().toString());
                    edit.replaceTypeAndCategory = replaceType.isChecked();
                    edit.type = type.getSelectedItemPosition() == 1
                            ? TransactionRecord.INCOME : TransactionRecord.EXPENSE;
                    List<String> bulkCategories = categoriesFor(edit.type);
                    int bulkCategoryIndex = category.getSelectedItemPosition();
                    edit.category = bulkCategoryIndex >= 0 && bulkCategoryIndex < bulkCategories.size()
                            ? bulkCategories.get(bulkCategoryIndex)
                            : categoryStore.resolve(edit.type, TransactionRecord.INCOME.equals(edit.type)
                            ? "Other income" : "Other");
                    edit.replaceTimestamp = replaceDate.isChecked();
                    edit.timestamp = dateMillis[0];
                    edit.replaceNote = replaceNote.isChecked();
                    edit.note = note.getText().toString().trim();
                    edit.replaceAccount = replaceAccount.isChecked();
                    edit.bankName = bank.getText().toString().trim();
                    edit.accountName = account.getText().toString().trim();
                    edit.replaceBudgetInclusion = replaceInclusion.isChecked();
                    edit.excludeFromBudget = inclusion.getSelectedItemPosition() == 1;

                    if (!edit.hasChanges()) {
                        Toast.makeText(this, t("Choose at least one field to replace."),
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (edit.replaceMerchant && edit.merchant.isEmpty()) {
                        merchant.setError(t("Enter the merchant or income source"));
                        merchant.requestFocus();
                        return;
                    }
                    if (edit.replaceAmount && edit.amountCents <= 0) {
                        amount.setError(t("Enter an amount greater than zero"));
                        amount.requestFocus();
                        return;
                    }
                    if (edit.replaceAccount && edit.bankName.isEmpty() != edit.accountName.isEmpty()) {
                        if (edit.bankName.isEmpty()) bank.setError(t("Enter the bank or institution"));
                        else account.setError(t("Enter an account name"));
                        return;
                    }
                    dialog.dismiss();
                    applyBulkEdit(ids, edit);
                }));
        dialog.show();
    }

    private CheckBox bulkOption(String label) {
        CheckBox option = new CheckBox(this);
        option.setText(label);
        option.setTextColor(settings.textColor());
        option.setTextSize(settings.textSizeSp());
        option.setPadding(0, UiKit.dp(this, 6), 0, 0);
        return option;
    }

    private void applyBulkEdit(Set<Long> ids, TransactionBulkEdit edit) {
        transactionMutationInProgress = true;
        showProgress(t("Updating selected transactions…"),
                t("Applying only the checked replacements to local transaction history."));
        io.execute(() -> {
            try {
                int updated = database.updateAll(ids, edit);
                runOnUiThread(() -> {
                    transactionMutationInProgress = false;
                    transactionManagementMode = false;
                    selectedTransactionIds.clear();
                    Toast.makeText(this, t("Updated %d transactions", updated),
                            Toast.LENGTH_LONG).show();
                    buildShell("transactions");
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    transactionMutationInProgress = false;
                    Toast.makeText(this, t("The selected transactions could not be updated."),
                            Toast.LENGTH_LONG).show();
                    buildShell("transactions");
                });
            }
        });
    }

    private void openDocument(TransactionRecord record) {
        Intent intent = new Intent(this, DocumentViewerActivity.class);
        intent.putExtra(DocumentViewerActivity.EXTRA_PATH, record.documentPath);
        intent.putExtra(DocumentViewerActivity.EXTRA_MIME, record.documentMime);
        intent.putExtra(DocumentViewerActivity.EXTRA_TITLE, record.merchant.isEmpty() ? language.category(record.category) : record.merchant);
        startActivity(intent);
    }

    private void showEditor(TransactionRecord requested) {
        TransactionRecord record = requested == null ? new TransactionRecord() : requested.copy();
        if (record.timestamp == 0) record.timestamp = System.currentTimeMillis();
        editorOriginal = record.id == 0 ? null : database.byId(record.id);
        currentScreen = "editor";
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(UiKit.dp(this, 14), UiKit.dp(this, 14), UiKit.dp(this, 14), UiKit.dp(this, 32));
        scroll.addView(page);
        contentHost.addView(scroll);

        page.addView(UiKit.heading(this, settings, t(record.id == 0 ? "Add transaction" : "Edit transaction")));
        if (documentBatchActive) {
            page.addView(UiKit.caption(this, settings,
                    t("Review upload %1$d of %2$d. Save or skip this transaction to continue.",
                            documentBatchCompleted + 1, documentBatchTotal)));
        } else if (statementBatchManualEditor) {
            page.addView(UiKit.caption(this, settings,
                    t("Save or skip this transaction to continue with the remaining statements.")));
        }
        LinearLayout panel = UiKit.panel(this, settings);
        editorFields = new EditorFields();
        editorFields.working = record;
        editorFields.dateMillis = record.timestamp;

        panel.addView(UiKit.caption(this, settings, t("Transaction type")));
        editorFields.type = spinner(Arrays.asList(t("Expense"), t("Income")));
        panel.addView(editorFields.type);
        panel.addView(UiKit.caption(this, settings, t("Merchant or employer")));
        editorFields.merchant = UiKit.input(this, settings, t("Merchant or employer"));
        editorFields.merchant.setText(record.merchant);
        panel.addView(editorFields.merchant);
        panel.addView(UiKit.caption(this, settings, t("Amount")));
        editorFields.amount = UiKit.moneyInput(this, settings, "0.00");
        if (record.amountCents > 0) editorFields.amount.setText(String.format(language.locale(), "%.2f", record.amountCents / 100.0));
        panel.addView(editorFields.amount);
        panel.addView(UiKit.caption(this, settings, t("Category")));
        editorFields.category = spinner(language.categoryList(categoriesFor(TransactionRecord.EXPENSE)));
        panel.addView(editorFields.category);
        panel.addView(UiKit.caption(this, settings, t("Date")));
        editorFields.date = UiKit.secondaryButton(this, settings, date(record.timestamp));
        editorFields.date.setOnClickListener(view -> chooseDate());
        panel.addView(editorFields.date);
        panel.addView(UiKit.caption(this, settings, t("Note (optional)")));
        editorFields.note = UiKit.input(this, settings, t("Note"));
        editorFields.note.setSingleLine(false);
        editorFields.note.setMinLines(2);
        editorFields.note.getLayoutParams().height = UiKit.dp(this, 84);
        editorFields.note.setText(record.note);
        panel.addView(editorFields.note);

        panel.addView(UiKit.caption(this, settings, t("Bank account association (optional)")));
        editorFields.bankName = UiKit.input(this, settings, t("Bank or institution"));
        editorFields.bankName.setText(record.bankName);
        panel.addView(editorFields.bankName);
        editorFields.accountName = UiKit.input(this, settings, t("Account name or last four digits"));
        editorFields.accountName.setText(record.accountName);
        panel.addView(editorFields.accountName);
        panel.addView(UiKit.caption(this, settings,
                t("Enter both values, or leave both blank for no bank account association.")));

        editorFields.excludeFromBudget = new CheckBox(this);
        editorFields.excludeFromBudget.setText(t("Exclude from AI budget and reports (transfer or adjustment)"));
        editorFields.excludeFromBudget.setTextColor(settings.textColor());
        editorFields.excludeFromBudget.setTextSize(settings.textSizeSp());
        editorFields.excludeFromBudget.setChecked(record.excludeFromBudget);
        panel.addView(editorFields.excludeFromBudget);

        editorFields.type.setSelection(TransactionRecord.INCOME.equals(record.type) ? 1 : 0, false);
        setCategoryAdapter(TransactionRecord.INCOME.equals(record.type), record.category);
        editorFields.type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            private boolean first = true;
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (first) { first = false; return; }
                setCategoryAdapter(position == 1, position == 1 ? "Paycheck" : "Other");
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        LinearLayout attachment = new LinearLayout(this);
        attachment.setOrientation(LinearLayout.VERTICAL);
        attachment.setPadding(0, UiKit.dp(this, 8), 0, UiKit.dp(this, 8));
        boolean statement = TransactionRecord.DOCUMENT_BANK_STATEMENT.equals(record.documentKind);
        String attachedText = record.documentPath.isEmpty()
                ? t("No financial document attached")
                : t(statement ? "Bank statement attached securely" : "Receipt/paystub attached securely")
                + (record.extractedText.isEmpty() ? "" : " • " + t("text read locally"));
        attachment.addView(UiKit.text(this, settings, attachedText, -2, true));
        Button attach = UiKit.goldButton(this, t(record.documentPath.isEmpty() ? "Scan or upload document" : "Replace or remove document"));
        attach.setOnClickListener(view -> {
            draftBeforeDocument = collectEditor(false);
            showAttachmentChoices();
        });
        attachment.addView(attach);
        panel.addView(attachment);

        Button save = UiKit.primaryButton(this, t("Save transaction"));
        save.setOnClickListener(view -> saveEditor());
        Button cancel = UiKit.secondaryButton(this, settings,
                t(documentBatchActive ? "Skip this upload"
                        : statementBatchManualEditor ? "Skip this statement" : "Cancel"));
        cancel.setOnClickListener(view -> cancelEditor());
        panel.addView(save);
        panel.addView(cancel);
        if (documentBatchActive || statementBatchManualEditor) {
            Button cancelRemaining = UiKit.secondaryButton(this, settings, t("Cancel remaining uploads"));
            cancelRemaining.setOnClickListener(view -> {
                if (documentBatchActive) cancelDocumentBatch();
                else cancelStatementBatchFromEditor();
            });
            panel.addView(cancelRemaining);
        }
        page.addView(panel);
    }

    private Spinner spinner(List<String> values) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
        spinner.setAdapter(adapter);
        spinner.setBackground(UiKit.roundRect(settings.boxColor(), 100, UiKit.dp(this, 10), UiKit.withAlpha(settings.textColor(), 35), UiKit.dp(this, 1)));
        spinner.setPadding(UiKit.dp(this, 10), 0, UiKit.dp(this, 10), 0);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UiKit.dp(this, 52));
        params.setMargins(0, UiKit.dp(this, 4), 0, UiKit.dp(this, 10));
        spinner.setLayoutParams(params);
        return spinner;
    }

    private void setCategoryAdapter(boolean income, String selected) {
        if (editorFields == null || editorFields.category == null) return;
        String type = income ? TransactionRecord.INCOME : TransactionRecord.EXPENSE;
        List<String> categories = categoriesFor(type);
        editorFields.category.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, language.categoryList(categories)));
        int index = indexOfIgnoreCase(categories, selected);
        if (index < 0) index = indexOfIgnoreCase(categories, categoryStore.resolve(type, selected));
        editorFields.category.setSelection(Math.max(0, index), false);
    }

    private void chooseDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(editorFields.dateMillis);
        DatePickerDialog dialog = new DatePickerDialog(this, (view, year, month, day) -> {
            Calendar chosen = Calendar.getInstance();
            chosen.clear();
            chosen.set(year, month, day, 12, 0, 0);
            editorFields.dateMillis = chosen.getTimeInMillis();
            editorFields.date.setText(date(editorFields.dateMillis));
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        dialog.getDatePicker().setMaxDate(System.currentTimeMillis() + 86_400_000L);
        dialog.show();
    }

    private TransactionRecord collectEditor(boolean validate) {
        TransactionRecord record = editorFields.working.copy();
        record.type = editorFields.type.getSelectedItemPosition() == 1 ? TransactionRecord.INCOME : TransactionRecord.EXPENSE;
        record.merchant = editorFields.merchant.getText().toString().trim();
        record.amountCents = Money.parseCents(editorFields.amount.getText().toString());
        List<String> categories = categoriesFor(record.type);
        int categoryIndex = editorFields.category.getSelectedItemPosition();
        record.category = categoryIndex >= 0 && categoryIndex < categories.size()
                ? categories.get(categoryIndex)
                : categoryStore.resolve(record.type, TransactionRecord.INCOME.equals(record.type)
                ? "Other income" : "Other");
        record.timestamp = editorFields.dateMillis;
        record.note = editorFields.note.getText().toString().trim();
        record.bankName = editorFields.bankName.getText().toString().trim();
        record.accountName = editorFields.accountName.getText().toString().trim();
        record.accountId = record.bankName.isEmpty() && record.accountName.isEmpty()
                ? "" : BankAccountIdentity.stableId(record.bankName, record.accountName);
        record.excludeFromBudget = editorFields.excludeFromBudget != null
                && editorFields.excludeFromBudget.isChecked();
        return record;
    }

    private void saveEditor() {
        TransactionRecord record = collectEditor(true);
        if (record.amountCents <= 0) {
            editorFields.amount.setError(t("Enter an amount greater than zero"));
            editorFields.amount.requestFocus();
            return;
        }
        if (record.merchant.isEmpty()) {
            editorFields.merchant.setError(t(TransactionRecord.INCOME.equals(record.type)
                    ? "Enter the employer or income source" : "Enter the merchant"));
            editorFields.merchant.requestFocus();
            return;
        }
        if (record.bankName.isEmpty() != record.accountName.isEmpty()) {
            if (record.bankName.isEmpty()) {
                editorFields.bankName.setError(t("Enter the bank or institution"));
                editorFields.bankName.requestFocus();
            } else {
                editorFields.accountName.setError(t("Enter an account name"));
                editorFields.accountName.requestFocus();
            }
            return;
        }
        database.save(record);
        if (editorOriginal != null && !editorOriginal.documentPath.isEmpty()
                && !editorOriginal.documentPath.equals(record.documentPath)) {
            deleteDocumentIfUnused(editorOriginal.documentPath);
        }
        if (documentBatchActive) {
            documentBatchSaved++;
            documentBatchCompleted++;
            Toast.makeText(this, t("Transaction saved"), Toast.LENGTH_SHORT).show();
            processNextDocumentUpload();
            return;
        }
        if (statementBatchManualEditor) {
            statementBatchManualEditor = false;
            statementBatchImported++;
            statementBatchTransactions++;
            statementBatchCompleted++;
            Toast.makeText(this, t("Transaction saved"), Toast.LENGTH_SHORT).show();
            processNextStatementUpload();
            return;
        }
        Toast.makeText(this, t("Transaction saved"), Toast.LENGTH_SHORT).show();
        buildShell("transactions");
    }

    private void cancelEditor() {
        if (editorFields != null && editorFields.working != null && !editorFields.working.documentPath.isEmpty()) {
            boolean newlyImported = editorOriginal == null || !editorFields.working.documentPath.equals(editorOriginal.documentPath);
            if (newlyImported) deleteDocumentIfUnused(editorFields.working.documentPath);
        }
        if (documentBatchActive) {
            documentBatchCompleted++;
            processNextDocumentUpload();
            return;
        }
        if (statementBatchManualEditor) {
            statementBatchManualEditor = false;
            statementBatchCompleted++;
            processNextStatementUpload();
            return;
        }
        buildShell(editorOriginal == null ? "dashboard" : "transactions");
    }

    private void showScanChoices() {
        draftBeforeDocument = null;
        new AlertDialog.Builder(this)
                .setTitle(t("Add to My Budget"))
                .setItems(new String[]{t("Take a receipt/paystub photo"), t("Upload receipt/paystub photos or PDFs"),
                        t("Upload bank statements"), t("Enter manually")}, (dialog, which) -> {
                    if (which == 0) captureDocument();
                    else if (which == 1) chooseDocument();
                    else if (which == 2) chooseBankStatement();
                    else showEditor(new TransactionRecord());
                })
                .show();
    }

    private void showAttachmentChoices() {
        boolean hasDocument = draftBeforeDocument != null && !draftBeforeDocument.documentPath.isEmpty();
        List<String> choices = new ArrayList<>();
        choices.add(t("Take a photo"));
        choices.add(t("Upload image or PDF"));
        if (hasDocument) choices.add(t("Remove attachment"));
        new AlertDialog.Builder(this)
                .setTitle(t("Receipt or paystub"))
                .setItems(choices.toArray(new String[0]), (dialog, which) -> {
                    if (which == 0) captureDocument();
                    else if (which == 1) chooseDocument();
                    else if (hasDocument) {
                        TransactionRecord restored = draftBeforeDocument.copy();
                        if (editorOriginal == null || !restored.documentPath.equals(editorOriginal.documentPath)) {
                            deleteDocumentIfUnused(restored.documentPath);
                        }
                        restored.documentPath = "";
                        restored.documentMime = "";
                        restored.documentKind = "";
                        restored.extractedText = "";
                        draftBeforeDocument = null;
                        showEditor(restored);
                    }
                })
                .setOnCancelListener(dialog -> draftBeforeDocument = null)
                .show();
    }

    private void chooseDocument() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "application/pdf"});
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, draftBeforeDocument == null);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, REQUEST_DOCUMENT); }
        catch (ActivityNotFoundException error) { Toast.makeText(this, t("No document picker is available."), Toast.LENGTH_LONG).show(); }
    }

    private void chooseBankStatement() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "application/pdf"});
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, REQUEST_BANK_STATEMENT); }
        catch (ActivityNotFoundException error) {
            Toast.makeText(this, t("No document picker is available."), Toast.LENGTH_LONG).show();
        }
    }

    private void captureDocument() {
        try {
            File directory = new File(getCacheDir(), "camera");
            if (!directory.exists()) directory.mkdirs();
            pendingCameraFile = new File(directory, "receipt-" + System.currentTimeMillis() + ".jpg");
            pendingCameraUri = LocalFileProvider.getUriForFile(this, pendingCameraFile);
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, REQUEST_CAMERA);
        } catch (Exception error) {
            Toast.makeText(this, t("A camera app is not available."), Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) {
            draftBeforeDocument = null;
            return;
        }
        if (requestCode == REQUEST_CAMERA && pendingCameraUri != null) {
            processDocument(pendingCameraUri, "image/jpeg", pendingCameraFile);
            return;
        }
        if (requestCode == REQUEST_DOCUMENT || requestCode == REQUEST_BANK_STATEMENT) {
            List<SelectedUpload> uploads = selectedUploads(data);
            if (uploads.isEmpty()) return;
            if (requestCode == REQUEST_BANK_STATEMENT) {
                if (uploads.size() == 1) {
                    SelectedUpload upload = uploads.get(0);
                    processBankStatement(upload.uri, upload.mime);
                } else {
                    startStatementBatch(uploads);
                }
            } else if (draftBeforeDocument != null || uploads.size() == 1) {
                SelectedUpload upload = uploads.get(0);
                processDocument(upload.uri, upload.mime, null);
            } else {
                startDocumentBatch(uploads);
            }
        } else if (requestCode == REQUEST_BACKGROUND || requestCode == REQUEST_AVATAR) {
            if (data == null || data.getData() == null) return;
            Uri uri = data.getData();
            processAppearanceImage(uri, requestCode == REQUEST_BACKGROUND);
        }
    }

    private List<SelectedUpload> selectedUploads(Intent data) {
        List<SelectedUpload> uploads = new ArrayList<>();
        if (data == null) return uploads;
        ClipData clips = data.getClipData();
        if (clips != null) {
            for (int index = 0; index < clips.getItemCount(); index++) {
                addSelectedUpload(uploads, clips.getItemAt(index).getUri(), data.getFlags());
            }
        } else {
            addSelectedUpload(uploads, data.getData(), data.getFlags());
        }
        return uploads;
    }

    private void addSelectedUpload(List<SelectedUpload> uploads, Uri uri, int intentFlags) {
        if (uri == null) return;
        for (SelectedUpload upload : uploads) if (upload.uri.equals(uri)) return;
        try {
            int flags = intentFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION;
            if (flags != 0) getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) {}
        String mime = getContentResolver().getType(uri);
        if (mime == null) {
            mime = uri.toString().toLowerCase(Locale.US).endsWith(".pdf")
                    ? "application/pdf" : "image/jpeg";
        }
        if ("application/pdf".equals(mime) || mime.startsWith("image/")) {
            uploads.add(new SelectedUpload(uri, mime));
        }
    }

    private void startDocumentBatch(List<SelectedUpload> uploads) {
        pendingDocumentUploads.clear();
        pendingDocumentUploads.addAll(uploads);
        documentBatchTotal = uploads.size();
        documentBatchCompleted = 0;
        documentBatchSaved = 0;
        documentBatchFailed = 0;
        documentBatchActive = true;
        Toast.makeText(this, t("Selected %d files", uploads.size()), Toast.LENGTH_SHORT).show();
        processNextDocumentUpload();
    }

    private void processNextDocumentUpload() {
        if (!documentBatchActive) return;
        if (pendingDocumentUploads.isEmpty()) {
            int skipped = Math.max(0, documentBatchTotal - documentBatchSaved - documentBatchFailed);
            int saved = documentBatchSaved;
            int failed = documentBatchFailed;
            resetDocumentBatch();
            buildShell("transactions");
            Toast.makeText(this, t("Batch complete • %1$d saved • %2$d skipped • %3$d failed",
                    saved, skipped, failed), Toast.LENGTH_LONG).show();
            return;
        }
        SelectedUpload upload = pendingDocumentUploads.remove(0);
        processDocument(upload.uri, upload.mime, null);
    }

    private void resetDocumentBatch() {
        pendingDocumentUploads.clear();
        documentBatchActive = false;
        documentBatchTotal = 0;
        documentBatchCompleted = 0;
        documentBatchSaved = 0;
        documentBatchFailed = 0;
    }

    private void cancelDocumentBatch() {
        if (editorFields != null && editorFields.working != null) {
            deleteDocumentIfUnused(editorFields.working.documentPath);
        }
        resetDocumentBatch();
        buildShell("dashboard");
    }

    private void startStatementBatch(List<SelectedUpload> uploads) {
        pendingStatementUploads.clear();
        pendingStatementUploads.addAll(uploads);
        statementBatchTotal = uploads.size();
        statementBatchCompleted = 0;
        statementBatchImported = 0;
        statementBatchTransactions = 0;
        statementBatchFailed = 0;
        statementBatchActive = true;
        Toast.makeText(this, t("Selected %d files", uploads.size()), Toast.LENGTH_SHORT).show();
        processNextStatementUpload();
    }

    private void processNextStatementUpload() {
        if (!statementBatchActive) return;
        if (pendingStatementUploads.isEmpty()) {
            int skipped = Math.max(0, statementBatchTotal - statementBatchImported - statementBatchFailed);
            int imported = statementBatchImported;
            int transactions = statementBatchTransactions;
            int failed = statementBatchFailed;
            resetStatementBatch();
            buildShell("dashboard");
            Toast.makeText(this, t("Statements complete • %1$d imported • %2$d transactions • %3$d skipped • %4$d failed",
                    imported, transactions, skipped, failed), Toast.LENGTH_LONG).show();
            return;
        }
        SelectedUpload upload = pendingStatementUploads.remove(0);
        processBankStatement(upload.uri, upload.mime);
    }

    private void resetStatementBatch() {
        pendingStatementUploads.clear();
        statementBatchActive = false;
        statementBatchManualEditor = false;
        statementBatchTotal = 0;
        statementBatchCompleted = 0;
        statementBatchImported = 0;
        statementBatchTransactions = 0;
        statementBatchFailed = 0;
    }

    private void cancelStatementBatchFromEditor() {
        if (editorFields != null && editorFields.working != null) {
            deleteDocumentIfUnused(editorFields.working.documentPath);
        }
        resetStatementBatch();
        buildShell("dashboard");
    }

    private void processDocument(Uri uri, String mime, File cameraFile) {
        TransactionRecord base = draftBeforeDocument == null ? new TransactionRecord() : draftBeforeDocument.copy();
        if (base.timestamp == 0) base.timestamp = System.currentTimeMillis();
        draftBeforeDocument = null;
        currentScreen = "document_processing";
        String progressTitle = t("Securing and reading the document…");
        if (documentBatchActive) {
            progressTitle = t("%1$s (%2$d of %3$d)", progressTitle,
                    documentBatchCompleted + 1, documentBatchTotal);
        }
        showProgress(progressTitle, t("OCR runs locally; financial documents are not uploaded."));
        io.execute(() -> {
            try {
                String encryptedPath = documents.importDocument(uri);
                runOnUiThread(() -> ocr.scan(uri, mime, language.code(), new OcrEngine.Callback() {
                    @Override public void onSuccess(String text) {
                        if (cameraFile != null) cameraFile.delete();
                        ParsedDocument parsed = parser.parse(text, base.timestamp, language.code());
                        base.documentPath = encryptedPath;
                        base.documentMime = mime;
                        base.documentKind = TransactionRecord.DOCUMENT_RECEIPT_PAYSTUB;
                        base.extractedText = text;
                        if (base.merchant.isEmpty()) base.merchant = parsed.party;
                        if (base.amountCents == 0) base.amountCents = parsed.amountCents;
                        if (base.id == 0) base.type = parsed.transactionType;
                        if (base.id == 0 || "Other".equals(base.category)) {
                            base.category = categoryStore.resolve(base.type, parsed.category);
                        }
                        if (base.id == 0) base.timestamp = parsed.dateMillis;
                        Toast.makeText(MainActivity.this, t("Document read locally • %d%% extraction confidence", parsed.confidencePercent), Toast.LENGTH_LONG).show();
                        showEditor(base);
                    }

                    @Override public void onError(Exception error) {
                        if (cameraFile != null) cameraFile.delete();
                        base.documentPath = encryptedPath;
                        base.documentMime = mime;
                        base.documentKind = TransactionRecord.DOCUMENT_RECEIPT_PAYSTUB;
                        Toast.makeText(MainActivity.this, t("The document is attached, but its text could not be read. Enter the details manually."), Toast.LENGTH_LONG).show();
                        showEditor(base);
                    }
                }));
            } catch (Exception error) {
                if (cameraFile != null) cameraFile.delete();
                runOnUiThread(() -> {
                    Toast.makeText(this, t("Unable to import that document."), Toast.LENGTH_LONG).show();
                    if (documentBatchActive) {
                        documentBatchFailed++;
                        documentBatchCompleted++;
                        processNextDocumentUpload();
                    } else {
                        showEditor(base);
                    }
                });
            }
        });
    }

    private void processBankStatement(Uri uri, String mime) {
        currentScreen = "statement_processing";
        String progressTitle = t("Securing and reading the bank statement…");
        if (statementBatchActive) {
            progressTitle = t("%1$s (%2$d of %3$d)", progressTitle,
                    statementBatchCompleted + 1, statementBatchTotal);
        }
        showProgress(progressTitle,
                t("Up to 12 PDF pages are read locally. Nothing is imported until you review it."));
        io.execute(() -> {
            try {
                String encryptedPath = documents.importDocument(uri);
                runOnUiThread(() -> ocr.scanStatement(uri, mime, language.code(), new OcrEngine.Callback() {
                    @Override public void onSuccess(String text) {
                        io.execute(() -> {
                            BankStatementResult result = statementParser.parse(text,
                                    System.currentTimeMillis(), language.code());
                            runOnUiThread(() -> showBankStatementReview(result, encryptedPath, mime, text));
                        });
                    }

                    @Override public void onError(Exception error) {
                        BankStatementResult result = new BankStatementResult();
                        result.warnings.add("The statement text could not be read.");
                        showBankStatementReview(result, encryptedPath, mime, "");
                    }
                }));
            } catch (Exception error) {
                runOnUiThread(() -> {
                    Toast.makeText(this, t("Unable to import that bank statement."), Toast.LENGTH_LONG).show();
                    if (statementBatchActive) {
                        statementBatchFailed++;
                        statementBatchCompleted++;
                        processNextStatementUpload();
                    } else {
                        buildShell("dashboard");
                    }
                });
            }
        });
    }

    private void showBankStatementReview(BankStatementResult result, String path, String mime, String text) {
        statementReviewPath = path == null ? "" : path;
        statementReviewMime = mime == null ? "" : mime;
        statementReviewText = text == null ? "" : text;
        currentScreen = "statement_review";
        for (BankStatementEntry entry : result.entries) {
            entry.type = TransactionRecord.INCOME.equals(entry.type)
                    ? TransactionRecord.INCOME : TransactionRecord.EXPENSE;
            entry.category = categoryStore.resolve(entry.type, entry.category);
        }
        markStatementDuplicates(result);
        result.recalculateTotals();
        contentHost.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(UiKit.dp(this, 14), UiKit.dp(this, 14), UiKit.dp(this, 14), UiKit.dp(this, 32));
        scroll.addView(page);
        contentHost.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        String reviewTitle = t("Review bank statement");
        if (statementBatchActive) {
            reviewTitle = t("%1$s (%2$d of %3$d)", reviewTitle,
                    statementBatchCompleted + 1, statementBatchTotal);
        }
        page.addView(UiKit.heading(this, settings, reviewTitle));
        page.addView(UiKit.caption(this, settings,
                t("Check every amount, type, category, and date. Only selected rows will be imported.")));
        if (!result.warnings.isEmpty()) {
            page.addView(UiKit.caption(this, settings,
                    t("Some summary or unreadable rows may have been skipped. Compare this list with the statement.")));
        }

        LinearLayout accountPanel = UiKit.panel(this, settings);
        accountPanel.addView(UiKit.heading(this, settings, t("Statement bank account")));
        addDetail(accountPanel, t("Bank or institution"), result.bankName);
        addDetail(accountPanel, t("Bank account"), result.accountName);
        if (result.periodStart > 0 && result.periodEnd > 0) {
            addDetail(accountPanel, t("Recognized statement period"),
                    date(result.periodStart) + " – " + date(result.periodEnd));
        }
        Button editAccount = UiKit.secondaryButton(this, settings, t("Edit bank account identity"));
        editAccount.setOnClickListener(view -> editStatementAccount(result));
        accountPanel.addView(editAccount);
        accountPanel.addView(UiKit.caption(this, settings,
                t("Account identity keeps histories from different bank accounts separate and prevents duplicate imports.")));
        page.addView(accountPanel);

        if (result.entries.isEmpty()) {
            LinearLayout empty = UiKit.panel(this, settings);
            empty.addView(UiKit.heading(this, settings, t("No transaction rows recognized")));
            empty.addView(UiKit.text(this, settings,
                    t("Try a clearer image or PDF, or attach this statement to one transaction and enter its details manually."),
                    0, false));
            Button retry = UiKit.goldButton(this,
                    t(statementBatchActive ? "Skip this statement" : "Try another statement"));
            retry.setOnClickListener(view -> {
                discardStatementReview();
                if (statementBatchActive) {
                    statementBatchCompleted++;
                    processNextStatementUpload();
                } else {
                    chooseBankStatement();
                }
            });
            Button manual = UiKit.primaryButton(this, t("Enter one transaction manually"));
            manual.setOnClickListener(view -> {
                TransactionRecord record = new TransactionRecord();
                record.timestamp = System.currentTimeMillis();
                record.documentPath = statementReviewPath;
                record.documentMime = statementReviewMime;
                record.documentKind = TransactionRecord.DOCUMENT_BANK_STATEMENT;
                record.extractedText = statementReviewText.isEmpty() ? "" : "parsed locally";
                record.bankName = result.bankName;
                record.accountName = result.accountName;
                record.accountId = result.accountId;
                clearStatementReviewState();
                statementBatchManualEditor = statementBatchActive;
                showEditor(record);
            });
            Button cancel = UiKit.secondaryButton(this, settings,
                    t(statementBatchActive ? "Cancel remaining uploads" : "Cancel"));
            cancel.setOnClickListener(view -> {
                discardStatementReview();
                if (statementBatchActive) resetStatementBatch();
                buildShell("dashboard");
            });
            empty.addView(retry);
            empty.addView(manual);
            empty.addView(cancel);
            page.addView(empty);
            return;
        }

        LinearLayout summary = UiKit.panel(this, settings);
        summary.addView(UiKit.heading(this, settings, t("Proposed transactions")));
        TextView totals = UiKit.text(this, settings, statementSummary(result), 0, true);
        summary.addView(totals);
        summary.addView(UiKit.caption(this, settings,
                t("These reviewed income and expense rows will feed the local AI budget and reports.")));
        page.addView(summary);

        for (BankStatementEntry entry : result.entries) {
            LinearLayout row = UiKit.panel(this, settings);
            CheckBox selected = new CheckBox(this);
            selected.setChecked(entry.selected && !entry.duplicate);
            selected.setEnabled(!entry.duplicate);
            String amount = String.format(language.locale(), "%s%s",
                    TransactionRecord.INCOME.equals(entry.type) ? "+" : "−",
                    Money.format(entry.amountCents));
            selected.setText(String.format(language.locale(), "%1$s  •  %2$s%3$s",
                    entry.description, amount,
                    entry.duplicate ? " • " + t("Already in history") : ""));
            selected.setTextColor(settings.textColor());
            selected.setTextSize(settings.textSizeSp());
            selected.setOnCheckedChangeListener((button, checked) -> {
                entry.selected = checked;
                totals.setText(statementSummary(result));
            });
            row.addView(selected);
            row.addView(UiKit.caption(this, settings,
                    t(TransactionRecord.INCOME.equals(entry.type) ? "Income" : "Expense")
                            + " • " + language.category(entry.category) + " • " + date(entry.timestamp)
                            + (entry.excludeFromBudget ? " • " + t("Excluded from budget") : "")
                            + " • " + t("%d%% confidence", entry.confidencePercent)));
            Button edit = UiKit.secondaryButton(this, settings, t("Edit before import"));
            edit.setOnClickListener(view -> editStatementEntry(entry, result));
            row.addView(edit);
            page.addView(row);
        }

        Button importSelected = UiKit.primaryButton(this, t("Import selected transactions"));
        importSelected.setOnClickListener(view -> importStatementEntries(result));
        Button cancel = UiKit.secondaryButton(this, settings,
                t(statementBatchActive ? "Skip this statement" : "Cancel"));
        cancel.setOnClickListener(view -> {
            discardStatementReview();
            if (statementBatchActive) {
                statementBatchCompleted++;
                processNextStatementUpload();
            } else {
                buildShell("dashboard");
            }
        });
        page.addView(importSelected);
        page.addView(cancel);
        if (statementBatchActive) {
            Button cancelRemaining = UiKit.secondaryButton(this, settings, t("Cancel remaining uploads"));
            cancelRemaining.setOnClickListener(view -> {
                discardStatementReview();
                resetStatementBatch();
                buildShell("dashboard");
            });
            page.addView(cancelRemaining);
        }
    }

    private String statementSummary(BankStatementResult result) {
        result.recalculateTotals();
        int selected = 0;
        int duplicates = 0;
        for (BankStatementEntry entry : result.entries) {
            if (entry.selected && !entry.duplicate) selected++;
            if (entry.duplicate) duplicates++;
        }
        String summary = t("%1$d selected • Income %2$s • Expenses %3$s", selected,
                Money.format(result.incomeCents), Money.format(result.expenseCents));
        return duplicates == 0 ? summary : summary + " • " + t("%d duplicates skipped", duplicates);
    }

    private void editStatementEntry(BankStatementEntry entry, BankStatementResult result) {
        ScrollView scroll = new ScrollView(this);
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(UiKit.dp(this, 18), UiKit.dp(this, 4), UiKit.dp(this, 18), UiKit.dp(this, 4));
        scroll.addView(fields);

        fields.addView(UiKit.caption(this, settings, t("Merchant or income source")));
        EditText description = UiKit.input(this, settings, t("Merchant or income source"));
        description.setText(entry.description);
        fields.addView(description);
        fields.addView(UiKit.caption(this, settings, t("Amount")));
        EditText amount = UiKit.moneyInput(this, settings, "0.00");
        amount.setText(String.format(language.locale(), "%.2f", entry.amountCents / 100.0));
        fields.addView(amount);
        fields.addView(UiKit.caption(this, settings, t("Transaction type")));
        Spinner type = spinner(Arrays.asList(t("Expense"), t("Income")));
        type.setSelection(TransactionRecord.INCOME.equals(entry.type) ? 1 : 0, false);
        fields.addView(type);
        fields.addView(UiKit.caption(this, settings, t("Category")));
        Spinner category = spinner(new ArrayList<>());
        setStatementCategoryAdapter(category, TransactionRecord.INCOME.equals(entry.type), entry.category);
        fields.addView(category);
        fields.addView(UiKit.caption(this, settings, t("Date")));
        final long[] chosenDate = {entry.timestamp};
        Button dateButton = UiKit.secondaryButton(this, settings, date(entry.timestamp));
        dateButton.setOnClickListener(view -> {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(chosenDate[0]);
            DatePickerDialog picker = new DatePickerDialog(this, (dateView, year, month, day) -> {
                Calendar chosen = Calendar.getInstance();
                chosen.clear();
                chosen.set(year, month, day, 12, 0, 0);
                chosenDate[0] = chosen.getTimeInMillis();
                dateButton.setText(date(chosenDate[0]));
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
            picker.getDatePicker().setMaxDate(System.currentTimeMillis() + 86_400_000L);
            picker.show();
        });
        fields.addView(dateButton);
        CheckBox exclude = new CheckBox(this);
        exclude.setText(t("Exclude from AI budget and reports (transfer or adjustment)"));
        exclude.setTextColor(settings.textColor());
        exclude.setTextSize(settings.textSizeSp());
        exclude.setChecked(entry.excludeFromBudget);
        fields.addView(exclude);
        type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            private boolean first = true;
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (first) { first = false; return; }
                setStatementCategoryAdapter(category, position == 1,
                        position == 1 ? "Other income" : "Other");
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(t("Edit statement transaction"))
                .setView(scroll)
                .setNegativeButton(t("Cancel"), null)
                .setPositiveButton(t("Save"), null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            long cents = Money.parseCents(amount.getText().toString());
            String party = description.getText().toString().trim();
            if (party.isEmpty()) { description.setError(t("Enter the merchant or income source")); return; }
            if (cents <= 0) { amount.setError(t("Enter an amount greater than zero")); return; }
            entry.description = party;
            entry.amountCents = cents;
            entry.type = type.getSelectedItemPosition() == 1 ? TransactionRecord.INCOME : TransactionRecord.EXPENSE;
            List<String> statementCategories = categoriesFor(entry.type);
            int statementCategoryIndex = category.getSelectedItemPosition();
            entry.category = statementCategoryIndex >= 0 && statementCategoryIndex < statementCategories.size()
                    ? statementCategories.get(statementCategoryIndex)
                    : categoryStore.resolve(entry.type, TransactionRecord.INCOME.equals(entry.type)
                    ? "Other income" : "Other");
            entry.timestamp = chosenDate[0];
            entry.excludeFromBudget = exclude.isChecked();
            entry.confidencePercent = 100;
            result.refreshFingerprints();
            dialog.dismiss();
            showBankStatementReview(result, statementReviewPath, statementReviewMime, statementReviewText);
        }));
        dialog.show();
    }

    private void setStatementCategoryAdapter(Spinner spinner, boolean income, String selected) {
        String type = income ? TransactionRecord.INCOME : TransactionRecord.EXPENSE;
        List<String> categories = categoriesFor(type);
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                language.categoryList(categories)));
        int index = indexOfIgnoreCase(categories, selected);
        if (index < 0) index = indexOfIgnoreCase(categories, categoryStore.resolve(type, selected));
        spinner.setSelection(Math.max(0, index), false);
    }

    private void markStatementDuplicates(BankStatementResult result) {
        result.refreshFingerprints();
        Set<String> seen = new HashSet<>();
        for (BankStatementEntry entry : result.entries) {
            entry.duplicate = !seen.add(entry.sourceFingerprint)
                    || database.hasSourceFingerprint(entry.sourceFingerprint);
            if (entry.duplicate) entry.selected = false;
        }
    }

    private void editStatementAccount(BankStatementResult result) {
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(UiKit.dp(this, 18), UiKit.dp(this, 4),
                UiKit.dp(this, 18), UiKit.dp(this, 4));
        fields.addView(UiKit.caption(this, settings, t("Bank or institution")));
        EditText bank = UiKit.input(this, settings, t("Bank or institution"));
        bank.setText(result.bankName);
        fields.addView(bank);
        fields.addView(UiKit.caption(this, settings, t("Account name or last four digits")));
        EditText account = UiKit.input(this, settings, t("Example: Checking ••••1234"));
        account.setText(result.accountName);
        fields.addView(account);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(t("Edit bank account identity"))
                .setView(fields)
                .setNegativeButton(t("Cancel"), null)
                .setPositiveButton(t("Save"), null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    String bankValue = bank.getText().toString().trim();
                    String accountValue = account.getText().toString().trim();
                    if (bankValue.isEmpty()) { bank.setError(t("Enter the bank or institution")); return; }
                    if (accountValue.isEmpty()) { account.setError(t("Enter an account name")); return; }
                    result.setAccount(bankValue, accountValue);
                    dialog.dismiss();
                    showBankStatementReview(result, statementReviewPath,
                            statementReviewMime, statementReviewText);
                }));
        dialog.show();
    }

    private void importStatementEntries(BankStatementResult result) {
        List<TransactionRecord> records = new ArrayList<>();
        for (BankStatementEntry entry : result.entries) {
            if (!entry.selected || entry.duplicate) continue;
            TransactionRecord record = new TransactionRecord();
            record.timestamp = entry.timestamp;
            record.merchant = entry.description;
            record.type = entry.type;
            record.category = entry.category;
            record.amountCents = entry.amountCents;
            record.documentPath = statementReviewPath;
            record.documentMime = statementReviewMime;
            record.documentKind = TransactionRecord.DOCUMENT_BANK_STATEMENT;
            record.extractedText = statementReviewText.isEmpty() ? "" : "parsed locally";
            record.bankName = result.bankName;
            record.accountId = result.accountId;
            record.accountName = result.accountName;
            record.sourceFingerprint = entry.sourceFingerprint;
            record.excludeFromBudget = entry.excludeFromBudget;
            records.add(record);
        }
        if (records.isEmpty()) {
            boolean duplicates = false;
            for (BankStatementEntry entry : result.entries) if (entry.duplicate) duplicates = true;
            Toast.makeText(this, t(duplicates
                    ? "All recognized transactions are already in history."
                    : "Select at least one transaction to import."), Toast.LENGTH_LONG).show();
            return;
        }
        String path = statementReviewPath;
        String mime = statementReviewMime;
        String text = statementReviewText;
        currentScreen = "statement_importing";
        showProgress(t("Importing reviewed transactions…"),
                t("Saving income, expenses, and the encrypted source statement locally."));
        io.execute(() -> {
            try {
                BudgetDatabase.ImportSummary imported = database.saveAllDistinct(records);
                database.markAutomaticInternalTransfers();
                runOnUiThread(() -> {
                    clearStatementReviewState();
                    deleteDocumentIfUnused(path);
                    Toast.makeText(this, t("Imported %1$d transactions • %2$d duplicates skipped",
                                    imported.saved, imported.duplicates),
                            Toast.LENGTH_LONG).show();
                    if (statementBatchActive) {
                        if (imported.saved > 0) statementBatchImported++;
                        statementBatchTransactions += imported.saved;
                        statementBatchCompleted++;
                        processNextStatementUpload();
                    } else {
                        buildShell("dashboard");
                    }
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    Toast.makeText(this, t("The reviewed transactions could not be imported."),
                            Toast.LENGTH_LONG).show();
                    showBankStatementReview(result, path, mime, text);
                });
            }
        });
    }

    private void discardStatementReview() {
        String path = statementReviewPath;
        clearStatementReviewState();
        deleteDocumentIfUnused(path);
    }

    private void clearStatementReviewState() {
        statementReviewPath = "";
        statementReviewMime = "";
        statementReviewText = "";
    }

    private void deleteDocumentIfUnused(String path) {
        if (path == null || path.isEmpty()) return;
        if (database.documentReferenceCount(path) == 0) documents.deleteDocument(path);
    }

    private void showProgress(String title, String detail) {
        contentHost.removeAllViews();
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER);
        page.setPadding(UiKit.dp(this, 30), UiKit.dp(this, 30), UiKit.dp(this, 30), UiKit.dp(this, 30));
        ProgressBar progress = new ProgressBar(this);
        page.addView(progress, new LinearLayout.LayoutParams(UiKit.dp(this, 56), UiKit.dp(this, 56)));
        TextView heading = UiKit.heading(this, settings, title);
        heading.setGravity(Gravity.CENTER);
        page.addView(heading);
        TextView text = UiKit.caption(this, settings, detail);
        text.setGravity(Gravity.CENTER);
        page.addView(text);
        contentHost.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private static final class SelectedUpload {
        final Uri uri;
        final String mime;

        SelectedUpload(Uri uri, String mime) {
            this.uri = uri;
            this.mime = mime;
        }
    }

    private static final class EditorFields {
        TransactionRecord working;
        Spinner type;
        Spinner category;
        EditText merchant;
        EditText amount;
        EditText note;
        EditText bankName;
        EditText accountName;
        CheckBox excludeFromBudget;
        Button date;
        long dateMillis;
    }

    private static final class TransactionManagementUi {
        TextView status;
        Button edit;
        Button delete;
        Button selectAll;
        Button clear;
        Runnable refresh;
        final List<Long> visibleIds = new ArrayList<>();
    }

    private void renderReports(LinearLayout page) {
        page.addView(UiKit.heading(this, settings, t("Reports")));
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        Button weekly = BudgetPeriod.WEEKLY.equals(reportMode)
                ? UiKit.goldButton(this, t("Weekly")) : UiKit.secondaryButton(this, settings, t("Weekly"));
        Button monthly = BudgetPeriod.MONTHLY.equals(reportMode)
                ? UiKit.goldButton(this, t("Monthly")) : UiKit.secondaryButton(this, settings, t("Monthly"));
        Button categoryTab = "category".equals(reportMode)
                ? UiKit.goldButton(this, t("Category")) : UiKit.secondaryButton(this, settings, t("Category"));
        weekly.setLayoutParams(reportTabParams(0, 4));
        monthly.setLayoutParams(reportTabParams(4, 4));
        categoryTab.setLayoutParams(reportTabParams(4, 0));
        weekly.setOnClickListener(view -> { reportMode = BudgetPeriod.WEEKLY; showScreen("reports"); });
        monthly.setOnClickListener(view -> { reportMode = BudgetPeriod.MONTHLY; showScreen("reports"); });
        categoryTab.setOnClickListener(view -> { reportMode = "category"; showScreen("reports"); });
        tabs.addView(weekly);
        tabs.addView(monthly);
        tabs.addView(categoryTab);
        page.addView(tabs);

        boolean categoryMode = "category".equals(reportMode);
        if (categoryMode) page.addView(categoryReportControls());
        String period = categoryMode ? BudgetPeriod.normalize(categoryReportPeriod)
                : BudgetPeriod.normalize(reportMode);
        long start;
        long end;
        String title;
        if (BudgetPeriod.MONTHLY.equals(period)) {
            start = startOfMonth();
            end = startOfNextMonth();
            title = categoryMode
                    ? language.category(categoryReportCategory) + " — " + t("Monthly category report")
                    : t("Monthly report");
        } else {
            start = startOfWeek();
            end = startOfNextWeek();
            title = categoryMode
                    ? language.category(categoryReportCategory) + " — " + t("Weekly category report")
                    : t("Weekly report");
        }
        List<TransactionRecord> all = database.all("timestamp", false);
        PeriodReport report = categoryMode
                ? agent.createCategoryReport(all, start, end, title, categoryReportType, categoryReportCategory)
                : agent.createReport(all, start, end, title);
        BudgetPlan plan = categoryMode
                ? agent.createCategoryPlan(all, System.currentTimeMillis(), period,
                categoryReportType, categoryReportCategory)
                : agent.createPlan(all, System.currentTimeMillis(), period);
        ManualBudget manualBudget = manualBudgets.load(period);
        ManualBudget pdfManualBudget = categoryMode
                ? focusedManualBudget(manualBudget, categoryReportType, categoryReportCategory)
                : manualBudget;

        LinearLayout summary = UiKit.panel(this, settings);
        summary.addView(UiKit.heading(this, settings, title));
        summary.addView(UiKit.caption(this, settings, dateRange(start, end)));
        if (categoryMode) {
            addDetail(summary, t("Type"), t(TransactionRecord.INCOME.equals(categoryReportType)
                    ? "Income" : "Expense"));
            addDetail(summary, t("Category"), language.category(categoryReportCategory));
        }
        if (categoryMode) {
            addDetail(summary, t(TransactionRecord.INCOME.equals(categoryReportType)
                            ? "Recorded income" : "Recorded spending"),
                    Money.format(TransactionRecord.INCOME.equals(categoryReportType)
                            ? report.income : report.expenses));
        } else {
            addDetail(summary, t("Income"), Money.format(report.income));
            addDetail(summary, t("Expenses"), Money.format(report.expenses));
            addDetail(summary, t("Net"), Money.format(report.net));
        }
        if (report.accountCount > 0) addDetail(summary, t("Bank accounts used"),
                Integer.toString(report.accountCount));
        if (report.statementTransactionCount > 0) addDetail(summary,
                t("Statement transactions used"), Integer.toString(report.statementTransactionCount));
        if (report.excludedTransferCount > 0) addDetail(summary,
                t("Transfers or adjustments excluded"), Integer.toString(report.excludedTransferCount));
        if (!categoryMode && report.income > 0) addDetail(summary, t("Savings rate"), report.savingsRatePercent + "%");
        if (report.previousExpenses > 0) addDetail(summary, t("Spending vs prior period"),
                (report.expenseChangePercent >= 0 ? "+" : "") + report.expenseChangePercent + "%");
        page.addView(summary);

        LinearLayout chartPanel = UiKit.panel(this, settings);
        if (categoryMode && TransactionRecord.INCOME.equals(categoryReportType)) {
            chartPanel.addView(UiKit.heading(this, settings, t("Income category activity")));
            addDetail(chartPanel, language.category(categoryReportCategory), Money.format(report.income));
        } else {
            chartPanel.addView(UiKit.heading(this, settings, t(categoryMode
                    ? "Expense category activity" : "Where the money went")));
        }
        if (!(categoryMode && TransactionRecord.INCOME.equals(categoryReportType))
                && report.spendingByCategory.isEmpty()) {
            chartPanel.addView(UiKit.text(this, settings,
                    t("No expenses were recorded during this period."), 0, false));
        } else if (!(categoryMode && TransactionRecord.INCOME.equals(categoryReportType))) {
            SpendingChartView chart = new SpendingChartView(this);
            chart.setData(language.localizedCategories(report.spendingByCategory), settings.textColor());
            chartPanel.addView(chart, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        page.addView(chartPanel);

        LinearLayout observations = UiKit.panel(this, settings);
        observations.addView(UiKit.heading(this, settings, t("Agent observations")));
        if (report.insights.isEmpty() && report.anomalies.isEmpty()) {
            observations.addView(UiKit.text(this, settings, t("Add more transactions to receive comparisons and spending observations."), 0, false));
        }
        for (String insight : report.insights) observations.addView(bullet(insight));
        for (String anomaly : report.anomalies) observations.addView(bullet(t("Review: %s", anomaly)));
        page.addView(observations);

        if (categoryMode) {
            page.addView(categoryBudgetPanel(report, plan, manualBudget, period,
                    categoryReportType, categoryReportCategory));
        } else {
            page.addView(manualBudgetPanel(manualBudget, report.spendingByCategory, 8,
                    "reports", period));
        }

        LinearLayout planPanel = UiKit.panel(this, settings);
        planPanel.addView(UiKit.heading(this, settings, t(BudgetPeriod.isWeekly(period)
                ? "AI weekly budget" : "AI monthly budget")));
        if (plan.categoryLimits.isEmpty() && plan.expectedMonthlyIncome <= 0) {
            planPanel.addView(UiKit.text(this, settings,
                    t("The plan will appear after transactions are added."), 0, false));
        }
        else {
            if (!categoryMode || TransactionRecord.INCOME.equals(categoryReportType)) {
                addDetail(planPanel, t("Expected income"), Money.format(plan.expectedMonthlyIncome));
            }
            if (!categoryMode || TransactionRecord.EXPENSE.equals(categoryReportType)) {
                addDetail(planPanel, t("Category allocation"), Money.format(plan.totalAllocated()));
            }
            if (!categoryMode) addDetail(planPanel, t("Savings target"), Money.format(plan.savingsTarget));
            addDetail(planPanel, t("Confidence"), plan.confidencePercent + "%");
            if (plan.accountCount > 0) addDetail(planPanel, t("Bank accounts learned"),
                    Integer.toString(plan.accountCount));
            for (Map.Entry<String, Long> entry : plan.categoryLimits.entrySet()) {
                planPanel.addView(budgetProgress(entry.getKey(), report.spendingByCategory.getOrDefault(entry.getKey(), 0L), entry.getValue()));
            }
        }
        Button pdf = UiKit.goldButton(this, t("Create and share PDF report"));
        pdf.setOnClickListener(view -> createAndShareReport(report, plan, pdfManualBudget));
        planPanel.addView(pdf);
        page.addView(planPanel);

        LinearLayout caveat = UiKit.panel(this, settings);
        caveat.addView(UiKit.caption(this, settings,
                t("Reports and learned budgets are estimates based only on records in this app. Review scanned amounts and categories for accuracy.")));
        page.addView(caveat);
    }

    private LinearLayout.LayoutParams reportTabParams(int leftDp, int rightDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        params.setMargins(UiKit.dp(this, leftDp), 0, UiKit.dp(this, rightDp), 0);
        return params;
    }

    private View categoryReportControls() {
        LinearLayout panel = UiKit.panel(this, settings);
        panel.addView(UiKit.heading(this, settings, t("Independent category report")));
        panel.addView(UiKit.caption(this, settings,
                t("Choose one income or expense category and create a separate weekly or monthly report.")));

        panel.addView(UiKit.caption(this, settings, t("Transaction type")));
        Spinner type = spinner(Arrays.asList(t("Expense"), t("Income")));
        type.setSelection(TransactionRecord.INCOME.equals(categoryReportType) ? 1 : 0, false);
        panel.addView(type);

        List<String> initialCategories = categoriesFor(categoryReportType);
        if (indexOfIgnoreCase(initialCategories, categoryReportCategory) < 0) {
            categoryReportCategory = initialCategories.isEmpty() ? "Other" : initialCategories.get(0);
        }
        panel.addView(UiKit.caption(this, settings, t("Category")));
        Spinner category = spinner(language.categoryList(initialCategories));
        category.setSelection(Math.max(0, indexOfIgnoreCase(initialCategories, categoryReportCategory)), false);
        panel.addView(category);

        panel.addView(UiKit.caption(this, settings, t("Report period")));
        Spinner period = spinner(Arrays.asList(t("Weekly"), t("Monthly")));
        period.setSelection(BudgetPeriod.isWeekly(categoryReportPeriod) ? 0 : 1, false);
        panel.addView(period);

        type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedType = position == 1 ? TransactionRecord.INCOME : TransactionRecord.EXPENSE;
                if (selectedType.equals(categoryReportType)) return;
                categoryReportType = selectedType;
                List<String> available = categoriesFor(categoryReportType);
                category.setAdapter(new ArrayAdapter<>(MainActivity.this,
                        android.R.layout.simple_spinner_dropdown_item, language.categoryList(available)));
                categoryReportCategory = available.isEmpty()
                        ? (TransactionRecord.INCOME.equals(categoryReportType) ? "Other income" : "Other")
                        : available.get(0);
                category.setSelection(0, false);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                List<String> available = categoriesFor(categoryReportType);
                if (position >= 0 && position < available.size()) {
                    categoryReportCategory = available.get(position);
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        period.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                categoryReportPeriod = position == 0 ? BudgetPeriod.WEEKLY : BudgetPeriod.MONTHLY;
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        Button create = UiKit.primaryButton(this, t("Create category report"));
        create.setOnClickListener(view -> {
            categoryReportType = type.getSelectedItemPosition() == 1
                    ? TransactionRecord.INCOME : TransactionRecord.EXPENSE;
            List<String> available = categoriesFor(categoryReportType);
            int selectedIndex = category.getSelectedItemPosition();
            categoryReportCategory = selectedIndex >= 0 && selectedIndex < available.size()
                    ? available.get(selectedIndex)
                    : categoryStore.resolve(categoryReportType,
                    TransactionRecord.INCOME.equals(categoryReportType) ? "Other income" : "Other");
            categoryReportPeriod = period.getSelectedItemPosition() == 0
                    ? BudgetPeriod.WEEKLY : BudgetPeriod.MONTHLY;
            showScreen("reports");
        });
        panel.addView(create);
        return panel;
    }

    private View categoryBudgetPanel(PeriodReport report, BudgetPlan plan, ManualBudget manual,
                                     String period, String type, String category) {
        LinearLayout panel = UiKit.panel(this, settings);
        panel.addView(UiKit.heading(this, settings, t("Category budget comparison")));
        addDetail(panel, t(TransactionRecord.INCOME.equals(type) ? "Recorded income" : "Recorded spending"),
                Money.format(TransactionRecord.INCOME.equals(type) ? report.income : report.expenses));
        if (TransactionRecord.INCOME.equals(type)) {
            addDetail(panel, t("AI expected income"), plan.expectedMonthlyIncome > 0
                    ? Money.format(plan.expectedMonthlyIncome) : t("Not set"));
            panel.addView(UiKit.caption(this, settings,
                    t("Manual expected income is stored for the whole budget period, not divided among income categories.")));
        } else {
            long aiLimit = mapValueIgnoreCase(plan.categoryLimits, category);
            long manualLimit = mapValueIgnoreCase(manual.categoryLimits, category);
            addDetail(panel, t("AI category limit"), aiLimit > 0 ? Money.format(aiLimit) : t("Not set"));
            addDetail(panel, t("Manual category limit"), manualLimit > 0 ? Money.format(manualLimit) : t("Not set"));
        }
        Button edit = UiKit.secondaryButton(this, settings, t(BudgetPeriod.isWeekly(period)
                ? "Edit weekly manual budget" : "Edit monthly manual budget"));
        edit.setOnClickListener(view -> showManualBudgetEditor(period, "reports"));
        panel.addView(edit);
        return panel;
    }

    private ManualBudget focusedManualBudget(ManualBudget source, String type, String category) {
        ManualBudget focused = new ManualBudget();
        if (!TransactionRecord.EXPENSE.equals(type)) return focused;
        long limit = mapValueIgnoreCase(source.categoryLimits, category);
        if (limit > 0) {
            focused.categoryLimits.put(category, limit);
            focused.updatedAt = source.updatedAt;
        }
        return focused;
    }

    private static long mapValueIgnoreCase(Map<String, Long> values, String key) {
        if (values == null || key == null) return 0;
        for (Map.Entry<String, Long> entry : values.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(key)) return entry.getValue() == null ? 0 : entry.getValue();
        }
        return 0;
    }

    private void createAndShareReport(PeriodReport report, BudgetPlan plan, ManualBudget manualBudget) {
        showProgress(t("Creating your report…"), t("The PDF is generated entirely on this device."));
        io.execute(() -> {
            try {
                File file = reportGenerator.createPdf(report, plan, manualBudget);
                runOnUiThread(() -> {
                    showScreen("reports");
                    shareFile(file, "application/pdf", t("My Budget") + " " + report.title);
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    showScreen("reports");
                    Toast.makeText(this, t("The PDF report could not be created."), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void shareFile(File file, String mime, String title) {
        try {
            Uri uri = LocalFileProvider.getUriForFile(this, file);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType(mime);
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_SUBJECT, title);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, title));
        } catch (Exception error) {
            Toast.makeText(this, t("No app is available to share this file."), Toast.LENGTH_LONG).show();
        }
    }

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private void renderSettings(LinearLayout page) {
        page.addView(UiKit.heading(this, settings, t("Settings")));

        LinearLayout languagePanel = UiKit.panel(this, settings);
        languagePanel.addView(UiKit.heading(this, settings, t("Language management")));
        languagePanel.addView(UiKit.caption(this, settings, t("App language")));
        Spinner languageSpinner = spinner(LanguageManager.languageNames());
        languageSpinner.setSelection(LanguageManager.indexOf(settings.languageCode()), false);
        languageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCode = LanguageManager.codeAt(position);
                if (!selectedCode.equals(settings.languageCode())) {
                    settings.setLanguageCode(selectedCode);
                    refreshLocalization();
                    buildShell("settings");
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        languagePanel.addView(languageSpinner);
        languagePanel.addView(UiKit.caption(this, settings,
                t("Choose the language used throughout the app. Changes apply immediately.")));
        page.addView(languagePanel);

        LinearLayout sortPanel = UiKit.panel(this, settings);
        sortPanel.addView(UiKit.heading(this, settings, t("Transaction sorting")));
        sortPanel.addView(UiKit.caption(this, settings, t("Sort records by")));
        List<String> sortLabels = Arrays.asList(t("Date"), t("Amount"), t("Merchant"), t("Category"), t("Type"));
        List<String> sortValues = Arrays.asList("timestamp", "amount", "merchant", "category", "type");
        Spinner sortSpinner = spinner(sortLabels);
        sortSpinner.setSelection(Math.max(0, sortValues.indexOf(settings.sortField())), false);
        sortSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String value = sortValues.get(position);
                if (!value.equals(settings.sortField())) settings.setSortField(value);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        sortPanel.addView(sortSpinner);
        Switch ascending = new Switch(this);
        ascending.setText(t("Ascending order"));
        ascending.setTextColor(settings.textColor());
        ascending.setTextSize(settings.textSizeSp());
        ascending.setChecked(settings.sortAscending());
        ascending.setOnCheckedChangeListener((button, checked) -> settings.setSortAscending(checked));
        sortPanel.addView(ascending);
        page.addView(sortPanel);

        LinearLayout weeklyReports = UiKit.panel(this, settings);
        weeklyReports.addView(UiKit.heading(this, settings, t("Weekly report settings")));
        weeklyReports.addView(UiKit.caption(this, settings, t("Start day of the week")));
        List<String> weekDays = new ArrayList<>();
        for (DayOfWeek day : DayOfWeek.values()) {
            String label = day.getDisplayName(TextStyle.FULL, language.locale());
            weekDays.add(label.isEmpty() ? day.name() : label);
        }
        Spinner weekStart = spinner(weekDays);
        weekStart.setSelection(settings.weekStartDay() - 1, false);
        weekStart.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int selected = position + 1;
                if (selected != settings.weekStartDay()) settings.setWeekStartDay(selected);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        weeklyReports.addView(weekStart);
        weeklyReports.addView(UiKit.caption(this, settings,
                t("Weekly reports and weekly budget progress use this day as their first day.")));
        page.addView(weeklyReports);

        page.addView(categoryManagementPanel());
        page.addView(budgetPeriodTabs("settings"));
        page.addView(manualBudgetPanel(manualBudgets.load(budgetMode), new LinkedHashMap<>(),
                0, "settings", budgetMode));

        LinearLayout appearance = UiKit.panel(this, settings);
        appearance.addView(UiKit.heading(this, settings, t("Appearance")));
        appearance.addView(colorSetting(t("Background color"), settings.backgroundColor(), settings::setBackgroundColor));
        Button backgroundPhoto = UiKit.secondaryButton(this, settings,
                t(settings.backgroundPath().isEmpty() ? "Upload background photo" : "Replace background photo"));
        backgroundPhoto.setOnClickListener(view -> startImagePicker(REQUEST_BACKGROUND));
        appearance.addView(backgroundPhoto);
        if (!settings.backgroundPath().isEmpty()) {
            Button remove = UiKit.secondaryButton(this, settings, t("Remove background photo"));
            remove.setOnClickListener(view -> {
                new File(settings.backgroundPath()).delete();
                settings.setBackgroundPath("");
                buildShell("settings");
            });
            appearance.addView(remove);
        }
        appearance.addView(sliderSetting(t("Background photo opacity"), settings.backgroundOpacity(), 1, 100,
                "%", value -> settings.setBackgroundOpacity(value), true));
        appearance.addView(colorSetting(t("Text color"), settings.textColor(), settings::setTextColor));
        appearance.addView(colorSetting(t("Text-box color"), settings.boxColor(), settings::setBoxColor));
        appearance.addView(sliderSetting(t("Text-box opacity"), settings.boxOpacity(), 1, 100,
                "%", value -> settings.setBoxOpacity(value), true));
        appearance.addView(sliderSetting(t("Text size"), Math.round(settings.textSizeSp()), 12, 36,
                " sp", value -> settings.setTextSizeSp(value), true));
        Button reset = UiKit.secondaryButton(this, settings, t("Reset appearance"));
        reset.setOnClickListener(view -> {
            if (!settings.backgroundPath().isEmpty()) new File(settings.backgroundPath()).delete();
            settings.resetAppearance();
            buildShell("settings");
        });
        appearance.addView(reset);
        page.addView(appearance);

        LinearLayout avatarPanel = UiKit.panel(this, settings);
        avatarPanel.addView(UiKit.heading(this, settings, t("Avatar")));
        LinearLayout avatarRow = new LinearLayout(this);
        avatarRow.setGravity(Gravity.CENTER_VERTICAL);
        ImageView avatar = new ImageView(this);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setBackground(UiKit.roundRect(Color.rgb(201, 167, 80), 100, UiKit.dp(this, 36), 0, 0));
        avatar.setClipToOutline(true);
        String avatarPath = settings.avatarPath();
        if (!avatarPath.isEmpty() && new File(avatarPath).exists()) avatar.setImageBitmap(loadScaled(avatarPath, 512));
        else avatar.setImageResource(R.drawable.ic_launcher_foreground);
        avatarRow.addView(avatar, new LinearLayout.LayoutParams(UiKit.dp(this, 72), UiKit.dp(this, 72)));
        LinearLayout avatarButtons = new LinearLayout(this);
        avatarButtons.setOrientation(LinearLayout.VERTICAL);
        avatarButtons.setPadding(UiKit.dp(this, 14), 0, 0, 0);
        avatarButtons.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button choose = UiKit.primaryButton(this, t(avatarPath.isEmpty() ? "Upload avatar" : "Replace avatar"));
        choose.setOnClickListener(view -> startImagePicker(REQUEST_AVATAR));
        avatarButtons.addView(choose);
        if (!avatarPath.isEmpty()) {
            Button remove = UiKit.secondaryButton(this, settings, t("Use default avatar"));
            remove.setOnClickListener(view -> {
                new File(settings.avatarPath()).delete();
                settings.setAvatarPath("");
                buildShell("settings");
            });
            avatarButtons.addView(remove);
        }
        avatarRow.addView(avatarButtons);
        avatarPanel.addView(avatarRow);
        page.addView(avatarPanel);

        LinearLayout security = UiKit.panel(this, settings);
        security.addView(UiKit.heading(this, settings, t("Passcode")));
        security.addView(UiKit.text(this, settings,
                t(passcode.hasPasscode() ? "A passcode protects access to the app." : "No passcode is set. Add one to protect financial records when the app opens."), -1, false));
        Button manage = UiKit.primaryButton(this, t(passcode.hasPasscode() ? "Change or disable passcode" : "Create passcode"));
        manage.setOnClickListener(view -> managePasscode());
        security.addView(manage);
        security.addView(UiKit.caption(this, settings, t("Automatic lock after leaving the app")));
        List<Integer> lockValues = Arrays.asList(AppSettings.LOCK_MANUAL_ONLY, AppSettings.LOCK_IMMEDIATELY,
                30, 60, 300, 900, 1800);
        Spinner lockDelay = spinner(Arrays.asList(t("Manual only"), t("Immediately"), t("After 30 seconds"),
                t("After 1 minute"), t("After 5 minutes"), t("After 15 minutes"), t("After 30 minutes")));
        lockDelay.setEnabled(passcode.hasPasscode());
        int lockIndex = lockValues.indexOf(settings.lockTimeoutSeconds());
        lockDelay.setSelection(Math.max(0, lockIndex), false);
        lockDelay.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int selected = lockValues.get(position);
                if (selected != settings.lockTimeoutSeconds()) settings.setLockTimeoutSeconds(selected);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        security.addView(lockDelay);
        security.addView(UiKit.caption(this, settings,
                t("Manual only never auto-locks while the app is running. A passcode is still required when the app launches.")));
        Button lockNow = UiKit.goldButton(this, t("Lock now"));
        lockNow.setEnabled(passcode.hasPasscode());
        lockNow.setOnClickListener(view -> showUnlockDialog());
        security.addView(lockNow);
        page.addView(security);

        LinearLayout storage = UiKit.panel(this, settings);
        storage.addView(UiKit.heading(this, settings, t("Storage management")));
        addDetail(storage, t("Transactions"), t("%d records", database.count()));
        addDetail(storage, t("Encrypted financial documents"), formatBytes(documents.secureDocumentBytes()));
        addDetail(storage, t("Temporary viewing cache"), formatBytes(documents.cacheBytes()));
        addDetail(storage, t("Database"), formatBytes(getDatabasePath("my_budget.db").length()));
        Button clearCache = UiKit.secondaryButton(this, settings, t("Clear temporary document cache"));
        clearCache.setOnClickListener(view -> {
            documents.clearViewCache();
            Toast.makeText(this, t("Temporary cache cleared"), Toast.LENGTH_SHORT).show();
            showScreen("settings");
        });
        Button orphans = UiKit.secondaryButton(this, settings, t("Remove unused document files"));
        orphans.setOnClickListener(view -> {
            int removed = documents.deleteOrphans(database.documentPaths());
            Toast.makeText(this, t("Unused files removed: %d", removed), Toast.LENGTH_SHORT).show();
            showScreen("settings");
        });
        Button csv = UiKit.goldButton(this, t("Export transactions as CSV"));
        csv.setOnClickListener(view -> exportCsv());
        Button transactionPdf = UiKit.goldButton(this, t("Export transactions as PDF"));
        transactionPdf.setOnClickListener(view -> exportTransactionsPdf());
        Button clearAll = UiKit.secondaryButton(this, settings, t("Delete all transactions and documents"));
        clearAll.setTextColor(Color.rgb(150, 42, 37));
        clearAll.setOnClickListener(view -> confirmClearAll());
        storage.addView(clearCache);
        storage.addView(orphans);
        storage.addView(csv);
        storage.addView(transactionPdf);
        storage.addView(clearAll);
        page.addView(storage);

        LinearLayout license = UiKit.panel(this, settings);
        license.addView(UiKit.heading(this, settings, t("License")));
        license.addView(UiKit.caption(this, settings,
                t("My Budget is licensed under the GNU Affero General Public License, version 3 (AGPLv3).")));
        Button readLicense = UiKit.goldButton(this, t("Read full AGPLv3 license"));
        readLicense.setOnClickListener(view -> showScreen("license"));
        license.addView(readLicense);
        page.addView(license);

        LinearLayout about = UiKit.panel(this, settings);
        about.addView(UiKit.heading(this, settings, t("About My Budget")));
        about.addView(UiKit.text(this, settings, t("Version %s", BuildConfig.VERSION_NAME), -2, true));
        about.addView(UiKit.caption(this, settings,
                t("Package: com.macleanofduartenterprises.mybudget\nThe learning agent and OCR run locally. The app requests no internet permission and stores imported financial documents encrypted with the Android Keystore.")));
        page.addView(about);
    }

    private void renderLicense(LinearLayout page) {
        page.addView(UiKit.heading(this, settings, t("License")));
        Button back = UiKit.secondaryButton(this, settings, t("← Back to Settings"));
        back.setOnClickListener(view -> showScreen("settings"));
        page.addView(back);

        LinearLayout notice = UiKit.panel(this, settings);
        notice.addView(UiKit.heading(this, settings, "GNU Affero General Public License v3.0"));
        notice.addView(UiKit.text(this, settings,
                "Copyright © 2026 Maclean Of Duart Enterprises", -1, true));
        notice.addView(UiKit.text(this, settings,
                t("My Budget is free software licensed under version 3 of the GNU Affero General Public License (AGPLv3). You may redistribute and modify it under that license. It is provided without warranty to the extent permitted by law."),
                -1, false));
        notice.addView(UiKit.caption(this, settings,
                t("The complete corresponding source code is distributed with this release.")));
        page.addView(notice);

        LinearLayout fullText = UiKit.panel(this, settings);
        fullText.addView(UiKit.heading(this, settings, t("Full license text")));
        fullText.addView(UiKit.caption(this, settings,
                t("The complete license text below is the authoritative English text.")));
        TextView legalText = UiKit.text(this, settings, loadLicenseText(), -2, false);
        legalText.setTypeface(Typeface.MONOSPACE);
        legalText.setTextIsSelectable(true);
        legalText.setLineSpacing(0f, 1.08f);
        fullText.addView(legalText);
        page.addView(fullText);
    }

    private String loadLicenseText() {
        StringBuilder text = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                getAssets().open("LICENSE.txt"), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (text.length() > 0) text.append('\n');
                text.append(line);
            }
            return text.toString();
        } catch (Exception error) {
            return t("The license text could not be loaded.");
        }
    }

    private View categoryManagementPanel() {
        LinearLayout panel = UiKit.panel(this, settings);
        panel.addView(UiKit.heading(this, settings, t("Category management")));
        panel.addView(UiKit.caption(this, settings,
                t("Add, rename, reorder, or remove any income or expense category, including the original categories.")));
        addCategorySection(panel, TransactionRecord.EXPENSE);
        addCategorySection(panel, TransactionRecord.INCOME);
        return panel;
    }

    private void addCategorySection(LinearLayout panel, String type) {
        boolean income = TransactionRecord.INCOME.equals(type);
        panel.addView(UiKit.heading(this, settings, t(income ? "Income categories" : "Expense categories")));
        List<String> categories = categoryStore.categories(type);
        for (int index = 0; index < categories.size(); index++) {
            String category = categories.get(index);
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(0, UiKit.dp(this, 6), 0, UiKit.dp(this, 6));
            LinearLayout header = new LinearLayout(this);
            header.setGravity(Gravity.CENTER_VERTICAL);
            TextView name = UiKit.text(this, settings, language.category(category), -1, true);
            name.setLayoutParams(new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            Button up = compactButton("↑");
            up.setContentDescription(t("Move category up") + ": " + language.category(category));
            up.setEnabled(index > 0);
            up.setOnClickListener(view -> moveCategory(type, category, -1));
            Button down = compactButton("↓");
            down.setContentDescription(t("Move category down") + ": " + language.category(category));
            down.setEnabled(index < categories.size() - 1);
            down.setOnClickListener(view -> moveCategory(type, category, 1));
            header.addView(name);
            header.addView(up);
            header.addView(down);
            item.addView(header);

            LinearLayout editActions = new LinearLayout(this);
            editActions.setGravity(Gravity.CENTER_VERTICAL);
            Button rename = compactButton(t("Rename"));
            rename.setLayoutParams(categoryEditButtonParams());
            rename.setOnClickListener(view -> showRenameCategoryDialog(type, category));
            Button remove = compactButton(t("Remove"));
            remove.setLayoutParams(categoryEditButtonParams());
            remove.setEnabled(categories.size() > 1);
            remove.setOnClickListener(view -> confirmRemoveCategory(type, category));
            editActions.addView(rename);
            editActions.addView(remove);
            item.addView(editActions);
            panel.addView(item);
        }
        Button add = UiKit.secondaryButton(this, settings,
                t(income ? "Add income category" : "Add expense category"));
        add.setOnClickListener(view -> showAddCategoryDialog(type));
        panel.addView(add);
    }

    private Button compactButton(String label) {
        Button button = UiKit.secondaryButton(this, settings, label);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, UiKit.dp(this, 44));
        params.setMargins(UiKit.dp(this, 5), 0, 0, 0);
        button.setLayoutParams(params);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(UiKit.dp(this, 10), 0, UiKit.dp(this, 10), 0);
        button.setTextSize(Math.max(12f, settings.textSizeSp() - 2f));
        return button;
    }

    private LinearLayout.LayoutParams categoryEditButtonParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                0, UiKit.dp(this, 44), 1);
        params.setMargins(UiKit.dp(this, 5), UiKit.dp(this, 3), 0, 0);
        return params;
    }

    private void showAddCategoryDialog(String type) {
        EditText input = UiKit.input(this, settings, t("Category name"));
        int pad = UiKit.dp(this, 18);
        input.setPadding(pad, pad, pad, pad);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(t(TransactionRecord.INCOME.equals(type)
                        ? "Add income category" : "Add expense category"))
                .setView(input)
                .setNegativeButton(t("Cancel"), null)
                .setPositiveButton(t("Add"), null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    String value = input.getText().toString().trim().replaceAll("\\s+", " ");
                    if (!CategoryStore.isValidName(value)) {
                        input.setError(t("Use a category name between 1 and 48 characters."));
                        return;
                    }
                    if (categoryNameConflict(type, value, "")) {
                        input.setError(t("That category already exists."));
                        return;
                    }
                    if (!categoryStore.add(type, value)) {
                        input.setError(t("That category could not be added."));
                        return;
                    }
                    dialog.dismiss();
                    Toast.makeText(this, t("Category added"), Toast.LENGTH_SHORT).show();
                    refreshLocalization();
                    buildShell("settings");
                }));
        dialog.show();
    }

    private void showRenameCategoryDialog(String type, String oldValue) {
        String displayedOldValue = language.category(oldValue);
        EditText input = UiKit.input(this, settings, t("Category name"));
        input.setText(displayedOldValue);
        input.setSelectAllOnFocus(true);
        int pad = UiKit.dp(this, 18);
        input.setPadding(pad, pad, pad, pad);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(t("Rename category"))
                .setView(input)
                .setNegativeButton(t("Cancel"), null)
                .setPositiveButton(t("Rename"), null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    String value = input.getText().toString().trim().replaceAll("\\s+", " ");
                    if (value.equals(displayedOldValue)) {
                        dialog.dismiss();
                        return;
                    }
                    if (!CategoryStore.isValidName(value)) {
                        input.setError(t("Use a category name between 1 and 48 characters."));
                        return;
                    }
                    if (categoryNameConflict(type, value, oldValue)) {
                        input.setError(t("That category already exists."));
                        return;
                    }
                    if (!categoryStore.rename(type, oldValue, value)) {
                        input.setError(t("That category could not be renamed."));
                        return;
                    }
                    database.renameCategory(type, oldValue, value);
                    if (TransactionRecord.EXPENSE.equals(type)) manualBudgets.renameCategory(oldValue, value);
                    if (categoryReportType.equals(type) && categoryReportCategory.equalsIgnoreCase(oldValue)) {
                        categoryReportCategory = value;
                    }
                    dialog.dismiss();
                    Toast.makeText(this, t("Category renamed"), Toast.LENGTH_SHORT).show();
                    refreshLocalization();
                    buildShell("settings");
                }));
        dialog.show();
    }

    private void moveCategory(String type, String category, int direction) {
        if (!categoryStore.move(type, category, direction)) return;
        refreshLocalization();
        buildShell("settings");
    }

    private void confirmRemoveCategory(String type, String category) {
        if (categoryStore.categories(type).size() <= 1) {
            Toast.makeText(this, t("At least one category must remain in each list."),
                    Toast.LENGTH_LONG).show();
            return;
        }
        int transactionCount = database.countCategory(type, category);
        String replacement = categoryStore.removalFallback(type, category);
        if (replacement.isEmpty()) return;
        String message = transactionCount > 0
                ? t("%1$d existing transactions will be moved to %2$s. Any manual limits will also be moved.",
                transactionCount, language.category(replacement))
                : t("This removes the category from future selections. Any manual limits will be moved to %s.",
                language.category(replacement));
        new AlertDialog.Builder(this)
                .setTitle(t("Remove category?"))
                .setMessage(message)
                .setNegativeButton(t("Cancel"), null)
                .setPositiveButton(t("Remove"), (dialog, which) -> {
                    if (!categoryStore.remove(type, category, replacement)) return;
                    database.renameCategory(type, category, replacement);
                    if (TransactionRecord.EXPENSE.equals(type)) manualBudgets.moveCategory(category, replacement);
                    if (categoryReportType.equals(type) && categoryReportCategory.equalsIgnoreCase(category)) {
                        categoryReportCategory = replacement;
                    }
                    Toast.makeText(this, t("Category removed"), Toast.LENGTH_SHORT).show();
                    refreshLocalization();
                    buildShell("settings");
                }).show();
    }

    private boolean categoryNameConflict(String type, String candidate, String ignored) {
        for (String existing : categoryStore.categories(type)) {
            if (existing.equalsIgnoreCase(ignored)) continue;
            if (existing.equalsIgnoreCase(candidate)
                    || language.category(existing).equalsIgnoreCase(candidate)) return true;
        }
        return false;
    }

    private View colorSetting(String label, int color, IntSetting setter) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, UiKit.dp(this, 5), 0, UiKit.dp(this, 5));
        TextView text = UiKit.text(this, settings, label, -1, false);
        text.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        View swatch = new View(this);
        swatch.setBackground(UiKit.roundRect(color, 100, UiKit.dp(this, 12), UiKit.withAlpha(settings.textColor(), 40), UiKit.dp(this, 1)));
        swatch.setContentDescription(t("%s color", label));
        swatch.setOnClickListener(view -> showColorDialog(label, color, setter));
        row.addView(text);
        row.addView(swatch, new LinearLayout.LayoutParams(UiKit.dp(this, 72), UiKit.dp(this, 42)));
        return row;
    }

    private View sliderSetting(String label, int current, int minimum, int maximum, String suffix,
                               IntSetting setter, boolean rebuild) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, UiKit.dp(this, 8), 0, UiKit.dp(this, 8));
        TextView value = UiKit.text(this, settings, t("%1$s: %2$d%3$s", label, current, suffix), -2, false);
        SeekBar seek = new SeekBar(this);
        seek.setMin(minimum);
        seek.setMax(maximum);
        seek.setProgress(current);
        seek.setProgressTintList(ColorStateList.valueOf(Color.rgb(201, 167, 80)));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                value.setText(t("%1$s: %2$d%3$s", label, progress, suffix));
                if (fromUser) setter.set(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) { if (rebuild) buildShell("settings"); }
        });
        wrap.addView(value);
        wrap.addView(seek);
        return wrap;
    }

    private void showColorDialog(String label, int current, IntSetting setter) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = UiKit.dp(this, 18);
        content.setPadding(pad, pad, pad, 0);
        EditText hex = new EditText(this);
        hex.setSingleLine(true);
        hex.setInputType(InputType.TYPE_CLASS_TEXT);
        hex.setText(String.format(Locale.US, "#%06X", 0xFFFFFF & current));
        content.addView(hex);
        TextView note = new TextView(this);
        note.setText(t("Enter a six-digit hex color or choose a palette color."));
        note.setTextSize(12);
        content.addView(note);
        LinearLayout palette = new LinearLayout(this);
        palette.setGravity(Gravity.CENTER);
        int[] colors = {Color.rgb(22, 56, 46), Color.rgb(201, 167, 80), Color.rgb(246, 241, 230),
                Color.WHITE, Color.rgb(19, 32, 27), Color.rgb(86, 145, 176), Color.rgb(128, 128, 128)};
        for (int color : colors) {
            View swatch = new View(this);
            swatch.setBackground(UiKit.roundRect(color, 100, UiKit.dp(this, 16), Color.DKGRAY, UiKit.dp(this, 1)));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, UiKit.dp(this, 48), 1);
            params.setMargins(UiKit.dp(this, 2), UiKit.dp(this, 10), UiKit.dp(this, 2), 0);
            swatch.setLayoutParams(params);
            swatch.setOnClickListener(view -> hex.setText(String.format(Locale.US, "#%06X", 0xFFFFFF & color)));
            palette.addView(swatch);
        }
        content.addView(palette);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(label)
                .setView(content)
                .setNegativeButton(t("Cancel"), null)
                .setPositiveButton(t("Apply"), null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            try {
                int color = Color.parseColor(hex.getText().toString().trim());
                setter.set(color);
                dialog.dismiss();
                buildShell("settings");
            } catch (Exception error) {
                hex.setError(t("Use a color such as #16382E"));
            }
        }));
        dialog.show();
    }

    private void startImagePicker(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, requestCode);
    }

    private void processAppearanceImage(Uri uri, boolean background) {
        showProgress(t("Saving image…"), t(background ? "Applying your custom background." : "Applying your avatar."));
        io.execute(() -> {
            try {
                String oldPath = background ? settings.backgroundPath() : settings.avatarPath();
                String path = documents.copyAppearanceImage(uri, background ? "background" : "avatar");
                if (!oldPath.isEmpty() && !oldPath.equals(path)) new File(oldPath).delete();
                if (background) settings.setBackgroundPath(path); else settings.setAvatarPath(path);
                runOnUiThread(() -> buildShell("settings"));
            } catch (Exception error) {
                runOnUiThread(() -> {
                    Toast.makeText(this, t("Unable to use that image."), Toast.LENGTH_LONG).show();
                    buildShell("settings");
                });
            }
        });
    }

    private void exportCsv() {
        showProgress(t("Preparing CSV export…"), t("Your export will contain transaction details but not attached financial documents."));
        io.execute(() -> {
            try {
                File file = reportGenerator.exportCsv(database.all("timestamp", true));
                runOnUiThread(() -> { showScreen("settings"); shareFile(file, "text/csv", t("My Budget transactions")); });
            } catch (Exception error) {
                runOnUiThread(() -> { showScreen("settings"); Toast.makeText(this, t("The CSV could not be created."), Toast.LENGTH_LONG).show(); });
            }
        });
    }

    private void exportTransactionsPdf() {
        showProgress(t("Preparing PDF export…"), t("Your export will contain transaction details but not attached financial documents."));
        io.execute(() -> {
            try {
                File file = reportGenerator.exportPdf(database.all("timestamp", true));
                runOnUiThread(() -> {
                    showScreen("settings");
                    shareFile(file, "application/pdf", t("My Budget transactions"));
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    showScreen("settings");
                    Toast.makeText(this, t("The transaction PDF could not be created."), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void confirmClearAll() {
        new AlertDialog.Builder(this)
                .setTitle(t("Delete all budget data?"))
                .setMessage(t("Every transaction and encrypted financial document will be permanently deleted from this device. Appearance and passcode settings will remain."))
                .setNegativeButton(t("Cancel"), null)
                .setPositiveButton(t("Delete all"), (dialog, which) -> {
                    for (String path : database.documentPaths()) documents.deleteDocument(path);
                    database.clearAll();
                    documents.clearViewCache();
                    Toast.makeText(this, t("All transactions and documents deleted"), Toast.LENGTH_LONG).show();
                    buildShell("dashboard");
                }).show();
    }

    private void managePasscode() {
        if (!passcode.hasPasscode()) showPasscodeEditor(false);
        else new AlertDialog.Builder(this)
                .setTitle(t("Passcode management"))
                .setItems(new String[]{t("Change passcode"), t("Disable passcode")}, (dialog, which) -> {
                    if (which == 0) showPasscodeEditor(true); else showDisablePasscode();
                }).show();
    }

    private void showPasscodeEditor(boolean changing) {
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        int padding = UiKit.dp(this, 20);
        fields.setPadding(padding, padding, padding, 0);
        EditText oldCode = secureNumberInput(changing ? t("Current passcode") : "");
        EditText newCode = secureNumberInput(t("New passcode (4–12 digits)"));
        EditText confirm = secureNumberInput(t("Confirm new passcode"));
        if (changing) fields.addView(oldCode);
        fields.addView(newCode);
        fields.addView(confirm);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(t(changing ? "Change passcode" : "Create passcode"))
                .setView(fields)
                .setNegativeButton(t("Cancel"), null)
                .setPositiveButton(t("Save"), null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            if (changing && !passcode.verify(oldCode.getText().toString())) {
                oldCode.setError(t("Current passcode is incorrect")); return;
            }
            String value = newCode.getText().toString();
            if (!PasscodeManager.isValid(value)) { newCode.setError(t("Use 4–12 digits")); return; }
            if (!value.equals(confirm.getText().toString())) { confirm.setError(t("Passcodes do not match")); return; }
            if (!passcode.setPasscode(value)) { newCode.setError(t("Passcode could not be saved")); return; }
            dialog.dismiss();
            Toast.makeText(this, t("Passcode saved"), Toast.LENGTH_SHORT).show();
            showScreen("settings");
        }));
        dialog.show();
    }

    private void showDisablePasscode() {
        EditText code = secureNumberInput(t("Current passcode"));
        int pad = UiKit.dp(this, 20);
        code.setPadding(pad, pad, pad, pad);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(t("Disable passcode?"))
                .setMessage(t("Financial records will open without a passcode."))
                .setView(code)
                .setNegativeButton(t("Cancel"), null)
                .setPositiveButton(t("Disable"), null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
            if (!passcode.verify(code.getText().toString())) { code.setError(t("Passcode is incorrect")); return; }
            passcode.disable();
            settings.setLockTimeoutSeconds(AppSettings.LOCK_MANUAL_ONLY);
            dialog.dismiss();
            Toast.makeText(this, t("Passcode disabled"), Toast.LENGTH_SHORT).show();
            showScreen("settings");
        }));
        dialog.show();
    }

    private EditText secureNumberInput(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        input.setSingleLine(true);
        input.setPadding(UiKit.dp(this, 12), UiKit.dp(this, 8), UiKit.dp(this, 12), UiKit.dp(this, 8));
        return input;
    }

    private interface IntSetting { void set(int value); }

    private void showUnlockDialog() {
        if (lockShown || !passcode.hasPasscode() || isFinishing()) return;
        lockShown = true;
        EditText code = secureNumberInput(t("Passcode"));
        int padding = UiKit.dp(this, 20);
        code.setPadding(padding, padding, padding, padding);
        final int[] attempts = {0};
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(t("Unlock My Budget"))
                .setMessage(t("Enter your passcode to view local financial records."))
                .setView(code)
                .setNegativeButton(t("Exit"), (d, which) -> finishAndRemoveTask())
                .setPositiveButton(t("Unlock"), null)
                .create();
        dialog.setCancelable(false);
        dialog.setOnShowListener(ignored -> {
            code.requestFocus();
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
                if (passcode.verify(code.getText().toString())) {
                    lockShown = false;
                    pausedAt = 0;
                    dialog.dismiss();
                } else {
                    attempts[0]++;
                    code.setText("");
                    code.setError(t(attempts[0] >= 5 ? "Too many attempts. Wait 30 seconds." : "Incorrect passcode"));
                    if (attempts[0] >= 5) {
                        Button unlock = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                        unlock.setEnabled(false);
                        unlock.postDelayed(() -> { attempts[0] = 0; unlock.setEnabled(true); code.setError(null); }, 30_000);
                    }
                }
            });
        });
        dialog.setOnDismissListener(ignored -> { if (!isFinishing()) lockShown = false; });
        dialog.show();
    }

    private TextView bullet(String value) {
        TextView text = UiKit.text(this, settings, "• " + value, -2, false);
        text.setPadding(UiKit.dp(this, 4), UiKit.dp(this, 5), UiKit.dp(this, 2), UiKit.dp(this, 5));
        return text;
    }

    private List<String> categoriesFor(String type) {
        String safeType = TransactionRecord.INCOME.equals(type)
                ? TransactionRecord.INCOME : TransactionRecord.EXPENSE;
        List<String> result = categoryStore.categories(safeType);
        for (TransactionRecord record : database.all("category", true)) {
            if (safeType.equals(record.type)) addIfMissing(result, record.category);
        }
        if (TransactionRecord.EXPENSE.equals(safeType)) {
            for (String category : manualBudgets.load(BudgetPeriod.WEEKLY).categoryLimits.keySet()) {
                addIfMissing(result, category);
            }
            for (String category : manualBudgets.load(BudgetPeriod.MONTHLY).categoryLimits.keySet()) {
                addIfMissing(result, category);
            }
        }
        return result;
    }

    private static void addIfMissing(List<String> values, String candidate) {
        if (candidate == null || candidate.trim().isEmpty()) return;
        if (indexOfIgnoreCase(values, candidate) < 0) values.add(candidate.trim());
    }

    private static int indexOfIgnoreCase(List<String> values, String candidate) {
        if (values == null || candidate == null) return -1;
        for (int index = 0; index < values.size(); index++) {
            if (values.get(index).equalsIgnoreCase(candidate)) return index;
        }
        return -1;
    }

    private String friendlySort(String value) {
        switch (value) {
            case "amount": return t("amount");
            case "merchant": return t("merchant");
            case "category": return t("category");
            case "type": return t("type");
            default: return t("date");
        }
    }

    private String date(long timestamp) {
        return new SimpleDateFormat("d MMM yyyy", language.locale()).format(new Date(timestamp));
    }

    private String dateRange(long start, long end) {
        return date(start) + " – " + date(Math.max(start, end - 1));
    }

    private String t(String english, Object... args) { return language.t(english, args); }

    private void refreshLocalization() {
        language = new LanguageManager(settings.languageCode());
        agent = new BudgetAgent(language, categoryStore.essentialExpenseCategories());
        reportGenerator = new ReportGenerator(this, language);
    }

    private static long startOfMonth() {
        return LocalDate.now().withDayOfMonth(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    private static long startOfNextMonth() {
        return LocalDate.now().withDayOfMonth(1).plusMonths(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    private long startOfWeek() {
        return ReportPeriod.weekStart(LocalDate.now(), settings.weekStartDay(), ZoneId.systemDefault());
    }

    private long startOfNextWeek() {
        return ReportPeriod.weekEnd(LocalDate.now(), settings.weekStartDay(), ZoneId.systemDefault());
    }

    private static Bitmap loadScaled(String path, int maximumDimension) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, bounds);
            int sample = 1;
            while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > maximumDimension) sample *= 2;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = Math.max(1, sample);
            return BitmapFactory.decodeFile(path, options);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L * 1024) return String.format(Locale.US, "%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024));
        return String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }
}
