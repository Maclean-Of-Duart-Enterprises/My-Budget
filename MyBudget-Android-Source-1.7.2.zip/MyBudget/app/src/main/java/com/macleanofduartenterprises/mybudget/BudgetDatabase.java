package com.macleanofduartenterprises.mybudget;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class BudgetDatabase extends SQLiteOpenHelper {
    private static final String DATABASE = "my_budget.db";
    private static final int VERSION = 3;

    public static final class ImportSummary {
        public int saved;
        public int duplicates;
    }

    public BudgetDatabase(Context context) {
        super(context, DATABASE, null, VERSION);
        setWriteAheadLoggingEnabled(true);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE transactions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "timestamp INTEGER NOT NULL," +
                "merchant TEXT NOT NULL DEFAULT ''," +
                "category TEXT NOT NULL," +
                "type TEXT NOT NULL CHECK(type IN ('INCOME','EXPENSE'))," +
                "amount_cents INTEGER NOT NULL CHECK(amount_cents >= 0)," +
                "note TEXT NOT NULL DEFAULT ''," +
                "document_path TEXT NOT NULL DEFAULT ''," +
                "document_mime TEXT NOT NULL DEFAULT ''," +
                "document_kind TEXT NOT NULL DEFAULT ''," +
                "extracted_text TEXT NOT NULL DEFAULT ''," +
                "bank_name TEXT NOT NULL DEFAULT ''," +
                "account_id TEXT NOT NULL DEFAULT ''," +
                "account_name TEXT NOT NULL DEFAULT ''," +
                "source_fingerprint TEXT NOT NULL DEFAULT ''," +
                "exclude_from_budget INTEGER NOT NULL DEFAULT 0," +
                "created_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_transactions_timestamp ON transactions(timestamp)");
        db.execSQL("CREATE INDEX idx_transactions_category ON transactions(category)");
        db.execSQL("CREATE INDEX idx_transactions_account ON transactions(account_id)");
        db.execSQL("CREATE UNIQUE INDEX idx_transactions_source ON transactions(source_fingerprint) WHERE source_fingerprint<>''");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE transactions ADD COLUMN document_kind TEXT NOT NULL DEFAULT ''");
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE transactions ADD COLUMN bank_name TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE transactions ADD COLUMN account_id TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE transactions ADD COLUMN account_name TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE transactions ADD COLUMN source_fingerprint TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE transactions ADD COLUMN exclude_from_budget INTEGER NOT NULL DEFAULT 0");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_transactions_account ON transactions(account_id)");
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_transactions_source ON transactions(source_fingerprint) WHERE source_fingerprint<>''");
        }
    }

    public long save(TransactionRecord record) {
        ContentValues values = values(record);
        if (record.id == 0) {
            record.createdAt = System.currentTimeMillis();
            values.put("created_at", record.createdAt);
            record.id = getWritableDatabase().insertOrThrow("transactions", null, values);
        } else {
            getWritableDatabase().update("transactions", values, "id=?", new String[]{Long.toString(record.id)});
        }
        return record.id;
    }

    public void saveAll(List<TransactionRecord> records) {
        saveAllDistinct(records);
    }

    public ImportSummary saveAllDistinct(List<TransactionRecord> records) {
        ImportSummary summary = new ImportSummary();
        if (records == null || records.isEmpty()) return summary;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            long now = System.currentTimeMillis();
            for (TransactionRecord record : records) {
                if (record == null) continue;
                if (record.id == 0) {
                    record.createdAt = now;
                    ContentValues values = values(record);
                    values.put("created_at", record.createdAt);
                    record.id = db.insertWithOnConflict("transactions", null, values,
                            SQLiteDatabase.CONFLICT_IGNORE);
                    if (record.id == -1) {
                        record.id = 0;
                        summary.duplicates++;
                    } else {
                        summary.saved++;
                    }
                } else {
                    db.update("transactions", values(record), "id=?",
                            new String[]{Long.toString(record.id)});
                    summary.saved++;
                }
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return summary;
    }

    public boolean hasSourceFingerprint(String fingerprint) {
        if (fingerprint == null || fingerprint.isEmpty()) return false;
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT 1 FROM transactions WHERE source_fingerprint=? LIMIT 1",
                new String[]{fingerprint})) {
            return cursor.moveToFirst();
        }
    }

    public int markAutomaticInternalTransfers() {
        Set<Long> ids = new TransactionHistoryAnalyzer().automaticInternalTransferIds(
                all("timestamp", true));
        if (ids.isEmpty()) return 0;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        int updated = 0;
        try {
            ContentValues values = new ContentValues();
            values.put("exclude_from_budget", 1);
            for (long id : ids) updated += db.update("transactions", values, "id=?",
                    new String[]{Long.toString(id)});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return updated;
    }

    public TransactionRecord byId(long id) {
        try (Cursor cursor = getReadableDatabase().query("transactions", null, "id=?",
                new String[]{Long.toString(id)}, null, null, null, "1")) {
            return cursor.moveToFirst() ? read(cursor) : null;
        }
    }

    public List<TransactionRecord> all(String requestedSort, boolean ascending) {
        String sort = sortColumn(requestedSort) + (ascending ? " ASC" : " DESC");
        List<TransactionRecord> records = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("transactions", null, null, null, null, null, sort)) {
            while (cursor.moveToNext()) records.add(read(cursor));
        }
        return records;
    }

    public List<TransactionRecord> between(long startInclusive, long endExclusive) {
        List<TransactionRecord> records = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("transactions", null,
                "timestamp>=? AND timestamp<?", new String[]{Long.toString(startInclusive), Long.toString(endExclusive)},
                null, null, "timestamp DESC")) {
            while (cursor.moveToNext()) records.add(read(cursor));
        }
        return records;
    }

    public void delete(long id) {
        getWritableDatabase().delete("transactions", "id=?", new String[]{Long.toString(id)});
    }

    public int countCategory(String type, String category) {
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM transactions WHERE type=? AND category=? COLLATE NOCASE",
                new String[]{safeType(type), safe(category)})) {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        }
    }

    /** Renames or moves a category without changing amounts, dates, or attachments. */
    public int renameCategory(String type, String oldCategory, String newCategory) {
        ContentValues values = new ContentValues();
        values.put("category", safe(newCategory));
        return getWritableDatabase().update("transactions", values,
                "type=? AND category=? COLLATE NOCASE",
                new String[]{safeType(type), safe(oldCategory)});
    }

    public int deleteAll(Set<Long> ids) {
        if (ids == null || ids.isEmpty()) return 0;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        int deleted = 0;
        try {
            for (Long id : ids) {
                if (id == null || id <= 0) continue;
                deleted += db.delete("transactions", "id=?", new String[]{Long.toString(id)});
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return deleted;
    }

    public int updateAll(Set<Long> ids, TransactionBulkEdit edit) {
        if (ids == null || ids.isEmpty() || edit == null || !edit.hasChanges()) return 0;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        int updated = 0;
        try {
            for (Long id : ids) {
                if (id == null || id <= 0) continue;
                TransactionRecord record = null;
                try (Cursor cursor = db.query("transactions", null, "id=?",
                        new String[]{Long.toString(id)}, null, null, null, "1")) {
                    if (cursor.moveToFirst()) record = read(cursor);
                }
                if (record == null) continue;
                edit.apply(record);
                updated += db.update("transactions", values(record), "id=?",
                        new String[]{Long.toString(id)});
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return updated;
    }

    public int count() {
        try (Cursor cursor = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM transactions", null)) {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        }
    }

    public Set<String> documentPaths() {
        Set<String> result = new HashSet<>();
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT document_path FROM transactions WHERE document_path<>''", null)) {
            while (cursor.moveToNext()) result.add(cursor.getString(0));
        }
        return result;
    }

    public int documentReferenceCount(String path) {
        if (path == null || path.isEmpty()) return 0;
        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM transactions WHERE document_path=?", new String[]{path})) {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        }
    }

    public void clearAll() { getWritableDatabase().delete("transactions", null, null); }

    private static ContentValues values(TransactionRecord record) {
        ContentValues values = new ContentValues();
        values.put("timestamp", record.timestamp);
        values.put("merchant", safe(record.merchant));
        values.put("category", safe(record.category));
        values.put("type", TransactionRecord.INCOME.equals(record.type) ? TransactionRecord.INCOME : TransactionRecord.EXPENSE);
        values.put("amount_cents", Math.max(0, record.amountCents));
        values.put("note", safe(record.note));
        values.put("document_path", safe(record.documentPath));
        values.put("document_mime", safe(record.documentMime));
        values.put("document_kind", safe(record.documentKind));
        values.put("extracted_text", safe(record.extractedText));
        values.put("bank_name", safe(record.bankName));
        values.put("account_id", safe(record.accountId));
        values.put("account_name", safe(record.accountName));
        values.put("source_fingerprint", safe(record.sourceFingerprint));
        values.put("exclude_from_budget", record.excludeFromBudget ? 1 : 0);
        values.put("created_at", record.createdAt == 0 ? System.currentTimeMillis() : record.createdAt);
        return values;
    }

    private static TransactionRecord read(Cursor cursor) {
        TransactionRecord record = new TransactionRecord();
        record.id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));
        record.timestamp = cursor.getLong(cursor.getColumnIndexOrThrow("timestamp"));
        record.merchant = cursor.getString(cursor.getColumnIndexOrThrow("merchant"));
        record.category = cursor.getString(cursor.getColumnIndexOrThrow("category"));
        record.type = cursor.getString(cursor.getColumnIndexOrThrow("type"));
        record.amountCents = cursor.getLong(cursor.getColumnIndexOrThrow("amount_cents"));
        record.note = cursor.getString(cursor.getColumnIndexOrThrow("note"));
        record.documentPath = cursor.getString(cursor.getColumnIndexOrThrow("document_path"));
        record.documentMime = cursor.getString(cursor.getColumnIndexOrThrow("document_mime"));
        record.documentKind = cursor.getString(cursor.getColumnIndexOrThrow("document_kind"));
        record.extractedText = cursor.getString(cursor.getColumnIndexOrThrow("extracted_text"));
        record.bankName = cursor.getString(cursor.getColumnIndexOrThrow("bank_name"));
        record.accountId = cursor.getString(cursor.getColumnIndexOrThrow("account_id"));
        record.accountName = cursor.getString(cursor.getColumnIndexOrThrow("account_name"));
        record.sourceFingerprint = cursor.getString(cursor.getColumnIndexOrThrow("source_fingerprint"));
        record.excludeFromBudget = cursor.getInt(cursor.getColumnIndexOrThrow("exclude_from_budget")) != 0;
        record.createdAt = cursor.getLong(cursor.getColumnIndexOrThrow("created_at"));
        return record;
    }

    private static String sortColumn(String requested) {
        if ("amount".equals(requested)) return "amount_cents";
        if ("merchant".equals(requested)) return "merchant COLLATE NOCASE";
        if ("category".equals(requested)) return "category COLLATE NOCASE";
        if ("type".equals(requested)) return "type";
        return "timestamp";
    }

    private static String safe(String value) { return value == null ? "" : value; }
    private static String safeType(String value) {
        return TransactionRecord.INCOME.equals(value) ? TransactionRecord.INCOME : TransactionRecord.EXPENSE;
    }
}
