package com.macleanofduartenterprises.mybudget;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class DocumentViewerActivity extends Activity {
    public static final String EXTRA_PATH = "document_path";
    public static final String EXTRA_MIME = "document_mime";
    public static final String EXTRA_TITLE = "document_title";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private LanguageManager language;
    private ImageView image;
    private TextView pageLabel;
    private Button previous;
    private Button next;
    private File clearFile;
    private ParcelFileDescriptor descriptor;
    private PdfRenderer renderer;
    private int pageIndex;
    private Bitmap bitmap;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        language = new LanguageManager(new AppSettings(this).languageCode());
        getWindow().setStatusBarColor(Color.rgb(13, 38, 31));
        buildUi();
        String path = getIntent().getStringExtra(EXTRA_PATH);
        String mime = getIntent().getStringExtra(EXTRA_MIME);
        if (path == null || path.isEmpty()) { finish(); return; }
        executor.execute(() -> {
            try {
                clearFile = new SecureDocumentStore(this).decryptToCache(path, mime);
                runOnUiThread(() -> showFile(mime));
            } catch (Exception error) {
                runOnUiThread(() -> { Toast.makeText(this, language.t("Unable to open this document."), Toast.LENGTH_LONG).show(); finish(); });
            }
        });
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18, 27, 24));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(UiKit.dp(this, 8), UiKit.dp(this, 8), UiKit.dp(this, 8), UiKit.dp(this, 8));
        toolbar.setBackgroundColor(Color.rgb(22, 56, 46));
        Button close = UiKit.goldButton(this, language.t("Close"));
        close.setLayoutParams(new LinearLayout.LayoutParams(UiKit.dp(this, 90), ViewGroup.LayoutParams.WRAP_CONTENT));
        close.setOnClickListener(view -> finish());
        TextView title = new TextView(this);
        title.setText(getIntent().getStringExtra(EXTRA_TITLE) == null ? language.t("Document") : getIntent().getStringExtra(EXTRA_TITLE));
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        toolbar.addView(close);
        toolbar.addView(title);
        root.addView(toolbar);

        FrameLayout stage = new FrameLayout(this);
        stage.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setAdjustViewBounds(true);
        stage.addView(image, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ProgressBar progress = new ProgressBar(this);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(UiKit.dp(this, 48), UiKit.dp(this, 48), Gravity.CENTER);
        stage.addView(progress, progressParams);
        progress.setTag("progress");
        root.addView(stage);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(UiKit.dp(this, 8), UiKit.dp(this, 5), UiKit.dp(this, 8), UiKit.dp(this, 5));
        previous = UiKit.goldButton(this, language.t("Previous"));
        next = UiKit.goldButton(this, language.t("Next"));
        pageLabel = new TextView(this);
        pageLabel.setTextColor(Color.WHITE);
        pageLabel.setGravity(Gravity.CENTER);
        previous.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        pageLabel.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        next.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        previous.setOnClickListener(view -> renderPage(pageIndex - 1));
        next.setOnClickListener(view -> renderPage(pageIndex + 1));
        controls.addView(previous);
        controls.addView(pageLabel);
        controls.addView(next);
        controls.setVisibility(LinearLayout.GONE);
        controls.setTag("controls");
        root.addView(controls);
        setContentView(root);
    }

    private void showFile(String mime) {
        FrameLayout stage = (FrameLayout) image.getParent();
        for (int i = 0; i < stage.getChildCount(); i++) if ("progress".equals(stage.getChildAt(i).getTag())) stage.getChildAt(i).setVisibility(ProgressBar.GONE);
        try {
            if ("application/pdf".equals(mime)) {
                descriptor = ParcelFileDescriptor.open(clearFile, ParcelFileDescriptor.MODE_READ_ONLY);
                renderer = new PdfRenderer(descriptor);
                ((LinearLayout) stage.getParent()).findViewWithTag("controls").setVisibility(LinearLayout.VISIBLE);
                renderPage(0);
            } else {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(clearFile.getAbsolutePath(), bounds);
                int sample = 1;
                while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > 3000) sample *= 2;
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = sample;
                bitmap = BitmapFactory.decodeFile(clearFile.getAbsolutePath(), options);
                image.setImageBitmap(bitmap);
            }
        } catch (Exception error) {
            Toast.makeText(this, language.t("Unable to display this document."), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void renderPage(int requested) {
        if (renderer == null || requested < 0 || requested >= renderer.getPageCount()) return;
        pageIndex = requested;
        if (bitmap != null) bitmap.recycle();
        try (PdfRenderer.Page page = renderer.openPage(pageIndex)) {
            int width = Math.min(2000, Math.max(1200, page.getWidth() * 2));
            int height = Math.round(width * page.getHeight() / (float) page.getWidth());
            bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            bitmap.eraseColor(Color.WHITE);
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            image.setImageBitmap(bitmap);
        }
        pageLabel.setText(String.format(Locale.getDefault(), "%d / %d",
                pageIndex + 1, renderer.getPageCount()));
        previous.setEnabled(pageIndex > 0);
        next.setEnabled(pageIndex + 1 < renderer.getPageCount());
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
        if (bitmap != null) bitmap.recycle();
        try { if (renderer != null) renderer.close(); } catch (Exception ignored) {}
        try { if (descriptor != null) descriptor.close(); } catch (Exception ignored) {}
        if (clearFile != null) clearFile.delete();
    }
}
