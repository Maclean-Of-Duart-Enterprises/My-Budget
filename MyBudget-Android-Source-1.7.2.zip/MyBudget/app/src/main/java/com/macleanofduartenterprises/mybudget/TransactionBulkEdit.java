package com.macleanofduartenterprises.mybudget;

/** A user-approved set of field replacements that can be applied to one or many transactions. */
public final class TransactionBulkEdit {
    public boolean replaceMerchant;
    public String merchant = "";
    public boolean replaceAmount;
    public long amountCents;
    public boolean replaceTypeAndCategory;
    public String type = TransactionRecord.EXPENSE;
    public String category = "Other";
    public boolean replaceTimestamp;
    public long timestamp;
    public boolean replaceNote;
    public String note = "";
    public boolean replaceAccount;
    public String bankName = "";
    public String accountName = "";
    public boolean replaceBudgetInclusion;
    public boolean excludeFromBudget;

    public boolean hasChanges() {
        return replaceMerchant || replaceAmount || replaceTypeAndCategory || replaceTimestamp
                || replaceNote || replaceAccount || replaceBudgetInclusion;
    }

    public void apply(TransactionRecord record) {
        if (record == null) return;
        if (replaceMerchant) record.merchant = clean(merchant);
        if (replaceAmount) record.amountCents = Math.max(0, amountCents);
        if (replaceTypeAndCategory) {
            record.type = TransactionRecord.INCOME.equals(type)
                    ? TransactionRecord.INCOME : TransactionRecord.EXPENSE;
            record.category = clean(category);
            if (record.category.isEmpty()) record.category = TransactionRecord.INCOME.equals(record.type)
                    ? "Other income" : "Other";
        }
        if (replaceTimestamp) record.timestamp = timestamp;
        if (replaceNote) record.note = clean(note);
        if (replaceAccount) {
            record.bankName = clean(bankName);
            record.accountName = clean(accountName);
            record.accountId = record.bankName.isEmpty() && record.accountName.isEmpty()
                    ? "" : BankAccountIdentity.stableId(record.bankName, record.accountName);
        }
        if (replaceBudgetInclusion) record.excludeFromBudget = excludeFromBudget;
    }

    private static String clean(String value) {
        return value == null ? "" : value.trim();
    }
}
