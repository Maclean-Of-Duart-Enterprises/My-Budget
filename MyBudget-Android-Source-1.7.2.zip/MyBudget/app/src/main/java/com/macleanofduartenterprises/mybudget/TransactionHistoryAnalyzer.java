package com.macleanofduartenterprises.mybudget;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Creates a canonical history and removes duplicates/internal transfers from budget math. */
public final class TransactionHistoryAnalyzer {
    private static final long THREE_DAYS = 3L * 86_400_000L;

    public static final class Result {
        public final List<TransactionRecord> canonicalRecords = new ArrayList<>();
        public final List<TransactionRecord> analysisRecords = new ArrayList<>();
        public final Set<Long> excludedRecordIds = new HashSet<>();
        public final Set<TransactionRecord> excludedRecords = new HashSet<>();
        public int duplicateCount;
        public int excludedRecordCount;
        public int accountCount;
    }

    public Result analyze(List<TransactionRecord> input) {
        Result result = new Result();
        Map<String, TransactionRecord> fingerprints = new LinkedHashMap<>();
        Set<String> accounts = new HashSet<>();
        int sequence = 0;
        if (input != null) {
            for (TransactionRecord record : input) {
                if (record == null) continue;
                String fingerprint = safe(record.sourceFingerprint);
                String key = fingerprint.isEmpty() ? "record_" + (sequence++) : fingerprint;
                if (fingerprints.containsKey(key)) {
                    result.duplicateCount++;
                    continue;
                }
                fingerprints.put(key, record);
                result.canonicalRecords.add(record);
                if (!safe(record.accountId).isEmpty()) accounts.add(record.accountId);
            }
        }
        result.accountCount = accounts.size();

        boolean[] excluded = new boolean[result.canonicalRecords.size()];
        for (int index = 0; index < result.canonicalRecords.size(); index++) {
            if (result.canonicalRecords.get(index).excludeFromBudget) excluded[index] = true;
        }
        for (int left = 0; left < result.canonicalRecords.size(); left++) {
            if (excluded[left]) continue;
            TransactionRecord first = result.canonicalRecords.get(left);
            if (!isTransferLike(first) || safe(first.accountId).isEmpty()) continue;
            for (int right = left + 1; right < result.canonicalRecords.size(); right++) {
                if (excluded[right]) continue;
                TransactionRecord second = result.canonicalRecords.get(right);
                if (!isTransferLike(second) || safe(second.accountId).isEmpty()
                        || first.accountId.equals(second.accountId)
                        || first.amountCents != second.amountCents
                        || first.type.equals(second.type)
                        || Math.abs(first.timestamp - second.timestamp) > THREE_DAYS) continue;
                excluded[left] = true;
                excluded[right] = true;
                break;
            }
        }
        for (int index = 0; index < result.canonicalRecords.size(); index++) {
            TransactionRecord record = result.canonicalRecords.get(index);
            if (excluded[index]) {
                result.excludedRecordCount++;
                result.excludedRecords.add(record);
                if (record.id != 0) result.excludedRecordIds.add(record.id);
            } else {
                result.analysisRecords.add(record);
            }
        }
        return result;
    }

    public Set<Long> automaticInternalTransferIds(List<TransactionRecord> input) {
        Result result = analyze(input);
        Set<Long> automatic = new HashSet<>();
        for (TransactionRecord record : result.canonicalRecords) {
            if (!record.excludeFromBudget && result.excludedRecordIds.contains(record.id)) automatic.add(record.id);
        }
        return automatic;
    }

    public static boolean isTransferLike(TransactionRecord record) {
        String value = (safe(record.merchant) + " " + safe(record.note)).toLowerCase(Locale.ROOT);
        if (containsAny(value, "transfer", "xfer", "between account", "account to account",
                "перевод", "переказ", "аудар", "transferencia", "traspaso")) return true;
        return value.contains("payment") && containsAny(value, "card", "account", "loan");
    }

    private static boolean containsAny(String value, String... needles) {
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }

    private static String safe(String value) { return value == null ? "" : value; }
}
