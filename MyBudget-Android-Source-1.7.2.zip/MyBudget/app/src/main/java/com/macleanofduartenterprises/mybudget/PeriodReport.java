package com.macleanofduartenterprises.mybudget;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class PeriodReport {
    public String title = "";
    public String filterType = "";
    public String filterCategory = "";
    public long start;
    public long end;
    public long income;
    public long expenses;
    public long net;
    public long previousExpenses;
    public int expenseChangePercent;
    public int savingsRatePercent;
    public int transactionCount;
    public int accountCount;
    public int statementTransactionCount;
    public int excludedTransferCount;
    public int duplicateCount;
    public final Map<String, Long> spendingByCategory = new LinkedHashMap<>();
    public final List<String> insights = new ArrayList<>();
    public final List<String> anomalies = new ArrayList<>();
}
