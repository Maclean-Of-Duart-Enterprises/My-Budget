package com.macleanofduartenterprises.mybudget;

/** Pure timeout policy shared by the activity and local tests. */
public final class LockPolicy {
    public static final int MANUAL_ONLY = 0;
    public static final int IMMEDIATELY = -1;

    private LockPolicy() {}

    public static boolean shouldLock(int timeoutSeconds, long awayForMillis) {
        if (awayForMillis < 0) return false;
        if (timeoutSeconds == IMMEDIATELY) return true;
        return timeoutSeconds > 0 && awayForMillis >= timeoutSeconds * 1_000L;
    }
}
