package com.macleanofduartenterprises.mybudget;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Detects a locally stable, privacy-preserving bank-account identity from statement headers. */
public final class BankAccountIdentity {
    private static final Pattern ACCOUNT_CONTEXT = Pattern.compile(
            "(?iu)(?:account(?: number)?|acct|a/c|card(?: number)?|сч[её]т|рахунок|шот|счет|cuenta|tarjeta)[^\\r\\n]{0,64}");
    private static final Pattern MASKED_ENDING = Pattern.compile("(?:[*xX•·]{2,}|ending|ends in|last 4|последние|останні|соңғы|terminada? en)\\s*[-:#№]?\\s*(\\d{3,6})",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern TRANSACTION_ROW_START = Pattern.compile(
            "(?iu)^\\s*(?:[0-9OIlSB]{1,4}[-/.][0-9OIlSB]{1,2}[-/.][0-9OIlSB]{1,4}|"
                    + "[\\p{L}.]{3,12}\\s+[0-9OIlSB]{1,2}(?:,|\\s)|"
                    + "[0-9OIlSB]{1,2}\\s+[\\p{L}.]{3,12}(?:\\s|,))");
    private static final String[] KNOWN_BANKS = {
            "Bank of America", "Wells Fargo", "JPMorgan Chase", "Chase", "Citibank", "Citi",
            "Capital One", "PNC Bank", "Truist", "TD Bank", "USAA", "Navy Federal",
            "Santander", "Citizens Bank", "Fulton Bank", "M&T Bank", "Discover",
            "American Express", "Ally Bank", "SoFi", "Sberbank", "Сбербанк", "ПриватБанк",
            "Kaspi Bank", "Halyk Bank", "BBVA", "Banco Santander"
    };

    public String bankName = "Bank";
    public String accountName = "Imported account";
    public String accountId = stableId(bankName, accountName);
    public String lastFour = "";
    public String accountType = "Account";

    public static BankAccountIdentity detect(String text) {
        BankAccountIdentity identity = new BankAccountIdentity();
        String source = text == null ? "" : text;
        String header = statementHeader(source);
        identity.bankName = detectBank(header);
        identity.lastFour = detectLastFour(header);
        identity.accountType = detectType(header);
        identity.accountName = identity.accountType
                + (identity.lastFour.isEmpty() ? "" : " ••••" + identity.lastFour);
        identity.accountId = stableId(identity.bankName, identity.accountName);
        return identity;
    }

    private static String statementHeader(String source) {
        StringBuilder header = new StringBuilder();
        int lines = 0;
        for (String raw : source.split("\\R")) {
            String line = raw == null ? "" : raw.replaceAll("\\s+", " ").trim();
            if (TRANSACTION_ROW_START.matcher(line).find()) break;
            if (!line.isEmpty()) {
                if (header.length() > 0) header.append('\n');
                header.append(line);
                if (++lines == 40) break;
            }
        }
        return header.toString();
    }

    public void update(String bank, String account) {
        bankName = cleanLabel(bank, "Bank");
        accountName = cleanLabel(account, "Imported account");
        accountId = stableId(bankName, accountName);
    }

    public static String stableId(String bank, String account) {
        return "acct_" + shortHash(normalize(bank) + "|" + normalize(account));
    }

    public static String transactionFingerprint(String accountId, long timestamp, String type,
                                                long amountCents, String description) {
        String normalizedDescription = normalize(description)
                .replaceAll("\\b\\d{5,}\\b", " ")
                .replaceAll("\\s+", " ").trim();
        return "stmt_" + shortHash(normalize(accountId) + "|" + timestamp + "|"
                + normalize(type) + "|" + amountCents + "|" + normalizedDescription);
    }

    private static String detectBank(String source) {
        String lower = source.toLowerCase(Locale.ROOT);
        for (String known : KNOWN_BANKS) {
            if (lower.contains(known.toLowerCase(Locale.ROOT))) return known;
        }
        int inspected = 0;
        for (String raw : source.split("\\R")) {
            if (inspected++ > 30) break;
            String line = raw == null ? "" : raw.replaceAll("\\s+", " ").trim();
            String lineLower = line.toLowerCase(Locale.ROOT);
            if (line.length() >= 3 && line.length() <= 72
                    && line.matches(".*\\p{L}.*")
                    && !isGenericStatementHeading(lineLower)
                    && containsAny(lineLower, " bank", "bank ", "credit union", "банк",
                    "banco", "caja de", "cooperativa")) {
                return cleanLabel(line, "Bank");
            }
        }
        return "Bank";
    }

    private static String detectLastFour(String source) {
        Matcher masked = MASKED_ENDING.matcher(source);
        if (masked.find()) return lastFour(masked.group(1));
        Matcher account = ACCOUNT_CONTEXT.matcher(source);
        while (account.find()) {
            String digits = account.group().replaceAll("\\D", "");
            if (digits.length() >= 4) return digits.substring(digits.length() - 4);
        }
        return "";
    }

    private static String detectType(String source) {
        String lower = source.toLowerCase(Locale.ROOT);
        if (containsAny(lower, "credit card", "card statement", "кредитная карт", "кредитна карт",
                "несие карт", "tarjeta de crédito", "tarjeta de credito")) return "Credit card";
        if (containsAny(lower, "savings", "money market", "сберег", "ощад", "жинақ",
                "ahorros", "cuenta de ahorro")) return "Savings";
        if (containsAny(lower, "checking", "current account", "расчетн", "расчётн", "поточн",
                "ағымдағы", "cuenta corriente")) return "Checking";
        return "Account";
    }

    private static boolean isGenericStatementHeading(String value) {
        String words = value.replaceAll("[^\\p{L}]+", " ").replaceAll("\\s+", " ").trim();
        return words.equals("bank statement") || words.equals("banking statement")
                || words.equals("account statement") || words.equals("monthly bank statement")
                || words.equals("credit card statement") || words.equals("банковская выписка")
                || words.equals("банківська виписка") || words.equals("выписка банка")
                || words.equals("виписка банку") || words.equals("банктік көшірме")
                || words.equals("estado de cuenta") || words.equals("extracto bancario");
    }

    private static String cleanLabel(String value, String fallback) {
        String cleaned = value == null ? "" : value.replaceAll("[\\p{Cntrl}]", " ")
                .replaceAll("\\s+", " ").trim();
        if (cleaned.length() > 72) cleaned = cleaned.substring(0, 72).trim();
        return cleaned.isEmpty() ? fallback : cleaned;
    }

    private static String normalize(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT)
                .replaceAll("[^\\p{L}\\d]+", " ").replaceAll("\\s+", " ").trim();
    }

    private static String lastFour(String digits) {
        if (digits == null) return "";
        String clean = digits.replaceAll("\\D", "");
        return clean.length() <= 4 ? clean : clean.substring(clean.length() - 4);
    }

    private static String shortHash(String value) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder output = new StringBuilder();
            for (int index = 0; index < 12; index++) output.append(String.format(Locale.US, "%02x", hash[index]));
            return output.toString();
        } catch (Exception impossible) {
            return Integer.toHexString(value.hashCode());
        }
    }

    private static boolean containsAny(String value, String... needles) {
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }
}
