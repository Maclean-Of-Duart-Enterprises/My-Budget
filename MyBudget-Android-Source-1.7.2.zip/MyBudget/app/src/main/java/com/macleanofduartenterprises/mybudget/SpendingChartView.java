package com.macleanofduartenterprises.mybudget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class SpendingChartView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Map.Entry<String, Long>> entries = new ArrayList<>();
    private int textColor = Color.DKGRAY;

    public SpendingChartView(Context context) { super(context); setMinimumHeight(UiKit.dp(context, 180)); }

    public void setData(Map<String, Long> values, int color) {
        entries.clear();
        int count = 0;
        for (Map.Entry<String, Long> entry : values.entrySet()) {
            entries.add(entry);
            if (++count == 5) break;
        }
        textColor = color;
        invalidate();
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        setMeasuredDimension(width, Math.max(UiKit.dp(getContext(), 180), entries.size() * UiKit.dp(getContext(), 36) + UiKit.dp(getContext(), 22)));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (entries.isEmpty()) return;
        long max = 1;
        for (Map.Entry<String, Long> entry : entries) max = Math.max(max, entry.getValue());
        float labelWidth = getWidth() * 0.34f;
        float barMax = getWidth() - labelWidth - UiKit.dp(getContext(), 78);
        float y = UiKit.dp(getContext(), 26);
        paint.setTextSize(UiKit.dp(getContext(), 12));
        paint.setTypeface(Typeface.DEFAULT);
        for (Map.Entry<String, Long> entry : entries) {
            paint.setColor(textColor);
            String label = entry.getKey().length() > 15 ? entry.getKey().substring(0, 14) + "…" : entry.getKey();
            canvas.drawText(label, 0, y, paint);
            float length = Math.max(UiKit.dp(getContext(), 3), barMax * entry.getValue() / (float) max);
            paint.setColor(Color.rgb(201, 167, 80));
            canvas.drawRoundRect(labelWidth, y - UiKit.dp(getContext(), 13), labelWidth + length, y + UiKit.dp(getContext(), 2), 8, 8, paint);
            paint.setColor(textColor);
            paint.setTextSize(UiKit.dp(getContext(), 10));
            canvas.drawText(Money.format(entry.getValue()), labelWidth + length + UiKit.dp(getContext(), 6), y, paint);
            paint.setTextSize(UiKit.dp(getContext(), 12));
            y += UiKit.dp(getContext(), 36);
        }
    }
}
