package com.macleanofduartenterprises.mybudget;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;

/** Calendar-safe weekly boundaries, including daylight-saving transitions. */
public final class ReportPeriod {
    private ReportPeriod() {}

    public static long weekStart(LocalDate date, int isoStartDay, ZoneId zone) {
        LocalDate safeDate = date == null ? LocalDate.now() : date;
        ZoneId safeZone = zone == null ? ZoneId.systemDefault() : zone;
        int safeDay = Math.max(1, Math.min(7, isoStartDay));
        return safeDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.of(safeDay)))
                .atStartOfDay(safeZone).toInstant().toEpochMilli();
    }

    public static long weekEnd(LocalDate date, int isoStartDay, ZoneId zone) {
        LocalDate safeDate = date == null ? LocalDate.now() : date;
        ZoneId safeZone = zone == null ? ZoneId.systemDefault() : zone;
        int safeDay = Math.max(1, Math.min(7, isoStartDay));
        return safeDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.of(safeDay)))
                .plusWeeks(1).atStartOfDay(safeZone).toInstant().toEpochMilli();
    }
}
