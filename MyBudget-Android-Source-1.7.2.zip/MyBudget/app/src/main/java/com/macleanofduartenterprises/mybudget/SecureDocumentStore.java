package com.macleanofduartenterprises.mybudget;

import android.content.Context;
import android.net.Uri;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyStore;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public final class SecureDocumentStore {
    private static final String KEY_ALIAS = "my_budget_document_key_v1";
    private static final int MAGIC = 0x4D425531; // MBU1
    private final Context context;
    private final File documentsDir;
    private final File viewCacheDir;

    public SecureDocumentStore(Context context) {
        this.context = context.getApplicationContext();
        documentsDir = new File(context.getFilesDir(), "secure_documents");
        viewCacheDir = new File(context.getCacheDir(), "view");
        if (!documentsDir.exists()) documentsDir.mkdirs();
        if (!viewCacheDir.exists()) viewCacheDir.mkdirs();
    }

    public String importDocument(Uri uri) throws Exception {
        File target = new File(documentsDir, UUID.randomUUID() + ".mbdoc");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        try (InputStream input = new BufferedInputStream(context.getContentResolver().openInputStream(uri));
             DataOutputStream header = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(target)))) {
            if (input == null) throw new IllegalArgumentException("The selected document cannot be opened.");
            header.writeInt(MAGIC);
            byte[] iv = cipher.getIV();
            header.writeInt(iv.length);
            header.write(iv);
            header.flush();
            try (CipherOutputStream encrypted = new CipherOutputStream(header, cipher)) {
                copy(input, encrypted);
            }
        } catch (Exception error) {
            target.delete();
            throw error;
        }
        return target.getAbsolutePath();
    }

    public File decryptToCache(String encryptedPath, String mimeType) throws Exception {
        File encrypted = new File(encryptedPath);
        if (!encrypted.exists() || !encrypted.getCanonicalPath().startsWith(documentsDir.getCanonicalPath())) {
            throw new IllegalArgumentException("Document is unavailable.");
        }
        String extension = extensionFor(mimeType);
        File plain = new File(viewCacheDir, encrypted.getName().replace(".mbdoc", "") + extension);
        try (DataInputStream input = new DataInputStream(new BufferedInputStream(new FileInputStream(encrypted)))) {
            if (input.readInt() != MAGIC) throw new IllegalArgumentException("Invalid document format.");
            int ivLength = input.readInt();
            if (ivLength < 12 || ivLength > 32) throw new IllegalArgumentException("Invalid document header.");
            byte[] iv = new byte[ivLength];
            input.readFully(iv);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new javax.crypto.spec.GCMParameterSpec(128, iv));
            try (CipherInputStream clear = new CipherInputStream(input, cipher);
                 OutputStream output = new BufferedOutputStream(new FileOutputStream(plain))) {
                copy(clear, output);
            }
        } catch (Exception error) {
            plain.delete();
            throw error;
        }
        return plain;
    }

    public String copyAppearanceImage(Uri uri, String name) throws Exception {
        File directory = new File(context.getFilesDir(), "appearance");
        if (!directory.exists()) directory.mkdirs();
        File target = new File(directory, name + ".img");
        try (InputStream input = context.getContentResolver().openInputStream(uri);
             OutputStream output = new BufferedOutputStream(new FileOutputStream(target))) {
            if (input == null) throw new IllegalArgumentException("The selected image cannot be opened.");
            copy(input, output);
        }
        return target.getAbsolutePath();
    }

    public void clearViewCache() { deleteTreeContents(viewCacheDir); }

    public long secureDocumentBytes() { return bytes(documentsDir); }
    public long cacheBytes() { return bytes(viewCacheDir); }

    public int deleteOrphans(Set<String> inUse) {
        Set<String> canonicalInUse = new HashSet<>();
        for (String path : inUse) {
            try { canonicalInUse.add(new File(path).getCanonicalPath()); } catch (Exception ignored) {}
        }
        int count = 0;
        File[] files = documentsDir.listFiles();
        if (files != null) {
            for (File file : files) {
                try {
                    if (!canonicalInUse.contains(file.getCanonicalPath()) && file.delete()) count++;
                } catch (Exception ignored) {}
            }
        }
        return count;
    }

    public boolean deleteDocument(String path) {
        if (path == null || path.isEmpty()) return true;
        try {
            File file = new File(path);
            return file.getCanonicalPath().startsWith(documentsDir.getCanonicalPath()) && (!file.exists() || file.delete());
        } catch (Exception ignored) {
            return false;
        }
    }

    public File documentsDirectory() { return documentsDir; }

    private SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (store.containsAlias(KEY_ALIAS)) return ((KeyStore.SecretKeyEntry) store.getEntry(KEY_ALIAS, null)).getSecretKey();
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    private static String extensionFor(String mime) {
        if (mime == null) return ".bin";
        if (mime.equals("application/pdf")) return ".pdf";
        if (mime.contains("png")) return ".png";
        if (mime.contains("webp")) return ".webp";
        return ".jpg";
    }

    private static void copy(InputStream input, OutputStream output) throws Exception {
        byte[] buffer = new byte[32 * 1024];
        int read;
        while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
    }

    private static long bytes(File file) {
        if (file == null || !file.exists()) return 0;
        if (file.isFile()) return file.length();
        long total = 0;
        File[] files = file.listFiles();
        if (files != null) for (File child : files) total += bytes(child);
        return total;
    }

    private static void deleteTreeContents(File directory) {
        File[] files = directory.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (file.isDirectory()) deleteTreeContents(file);
            file.delete();
        }
    }
}
