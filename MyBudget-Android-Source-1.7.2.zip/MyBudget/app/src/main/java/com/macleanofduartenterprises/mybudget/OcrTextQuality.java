package com.macleanofduartenterprises.mybudget;

import java.util.regex.Pattern;

/** Scores competing local OCR passes with extra weight for statement-like date/amount rows. */
public final class OcrTextQuality {
    private static final Pattern DATE = Pattern.compile(
            "(?iu)(?:\\b\\d{1,4}[-/.]\\d{1,2}[-/.]\\d{1,4}\\b|"
                    + "\\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|ene|abr|ago|dic|"
                    + "янв|фев|мар|апр|май|июн|июл|авг|сен|окт|ноя|дек|"
                    + "січ|лют|бер|квіт|трав|чер|лип|серп|вер|жовт|лист|груд|"
                    + "қаң|ақп|наур|сәу|мам|мау|шіл|там|қыр|қаз|қар|жел)"
                    + "[\\p{L}.]*\\s+\\d{1,2}\\b|"
                    + "\\b\\d{1,2}\\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|"
                    + "ene|abr|ago|dic|янв|фев|мар|апр|май|июн|июл|авг|сен|окт|ноя|дек|"
                    + "січ|лют|бер|квіт|трав|чер|лип|серп|вер|жовт|лист|груд|"
                    + "қаң|ақп|наур|сәу|мам|мау|шіл|там|қыр|қаз|қар|жел)[\\p{L}.]*\\b)");
    private static final Pattern MONEY = Pattern.compile(
            "(?<!\\d)[$€₸₴₽£]?\\s*\\d{1,3}(?:[ ,.'’\\u00A0]\\d{3})*[.,]\\d{2}(?!\\d)");

    private OcrTextQuality() {}

    public static String choose(String first, String second) {
        String left = first == null ? "" : first;
        String right = second == null ? "" : second;
        return score(right) > score(left) ? right : left;
    }

    public static int score(String text) {
        if (text == null || text.trim().isEmpty()) return 0;
        int score = 0;
        for (String line : text.split("\\R")) {
            boolean date = DATE.matcher(line).find();
            boolean money = MONEY.matcher(line).find();
            if (date && money) score += 30;
            else if (date) score += 6;
            else if (money) score += 5;
            int letters = 0;
            int digits = 0;
            for (int index = 0; index < line.length(); index++) {
                char value = line.charAt(index);
                if (Character.isLetter(value)) letters++;
                else if (Character.isDigit(value)) digits++;
            }
            score += Math.min(8, letters / 8) + Math.min(5, digits / 3);
            if (line.indexOf('\uFFFD') >= 0) score -= 10;
        }
        return Math.max(0, score);
    }
}
