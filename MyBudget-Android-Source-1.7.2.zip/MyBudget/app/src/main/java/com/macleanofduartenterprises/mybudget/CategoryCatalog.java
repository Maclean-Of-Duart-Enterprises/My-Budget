package com.macleanofduartenterprises.mybudget;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Pure category-list logic kept separate from Android persistence for reliable migration tests. */
final class CategoryCatalog {
    private static final int MAXIMUM_NAME_LENGTH = 48;
    private final List<String> defaults = new ArrayList<>();
    private final List<String> values = new ArrayList<>();
    private final Map<String, String> aliases = new LinkedHashMap<>();

    CategoryCatalog(List<String> defaultValues, List<String> storedOrder,
                    List<String> legacyCustom, Map<String, String> storedAliases) {
        addUnique(defaults, defaultValues);
        if (storedOrder != null) {
            addUnique(values, storedOrder);
        } else {
            addUnique(values, defaults);
            List<String> legacy = new ArrayList<>();
            addUnique(legacy, legacyCustom);
            legacy.sort(String.CASE_INSENSITIVE_ORDER);
            addUnique(values, legacy);
        }
        if (values.isEmpty()) addUnique(values, defaults);

        for (String original : defaults) {
            String target = find(values, aliasValue(storedAliases, original));
            if (target == null) target = find(values, original);
            if (target == null && !values.isEmpty()) target = values.get(0);
            if (target != null) aliases.put(original, target);
        }
    }

    List<String> categories() { return new ArrayList<>(values); }

    Map<String, String> aliases() { return new LinkedHashMap<>(aliases); }

    boolean add(String value) {
        String clean = clean(value);
        if (!isValidName(clean) || find(values, clean) != null) return false;
        values.add(clean);
        linkRestoredDefault(clean);
        return true;
    }

    boolean rename(String oldValue, String newValue) {
        String oldActual = find(values, clean(oldValue));
        String cleanNew = clean(newValue);
        if (oldActual == null || !isValidName(cleanNew)) return false;
        String conflict = find(values, cleanNew);
        if (conflict != null && !conflict.equalsIgnoreCase(oldActual)) return false;

        int index = values.indexOf(oldActual);
        values.set(index, cleanNew);
        for (Map.Entry<String, String> alias : aliases.entrySet()) {
            if (alias.getValue().equalsIgnoreCase(oldActual)) alias.setValue(cleanNew);
        }
        linkRestoredDefault(cleanNew);
        return true;
    }

    boolean remove(String value, String replacement) {
        if (values.size() <= 1) return false;
        String actual = find(values, clean(value));
        String replacementActual = find(values, clean(replacement));
        if (actual == null || replacementActual == null
                || actual.equalsIgnoreCase(replacementActual)) return false;
        values.remove(actual);
        for (Map.Entry<String, String> alias : aliases.entrySet()) {
            if (alias.getValue().equalsIgnoreCase(actual)) alias.setValue(replacementActual);
        }
        return true;
    }

    boolean move(String value, int direction) {
        if (direction != -1 && direction != 1) return false;
        String actual = find(values, clean(value));
        if (actual == null) return false;
        int from = values.indexOf(actual);
        int to = from + direction;
        if (to < 0 || to >= values.size()) return false;
        values.set(from, values.get(to));
        values.set(to, actual);
        return true;
    }

    String resolve(String suggested) {
        String direct = find(values, clean(suggested));
        if (direct != null) return direct;
        String mapped = find(values, aliasValue(aliases, clean(suggested)));
        return mapped == null ? fallbackFor("") : mapped;
    }

    String fallbackFor(String valueBeingRemoved) {
        if (values.isEmpty()) return "";
        String removed = find(values, clean(valueBeingRemoved));
        if (removed != null && values.size() <= 1) return "";
        List<String> remaining = new ArrayList<>();
        for (String value : values) {
            if (removed == null || !value.equalsIgnoreCase(removed)) remaining.add(value);
        }
        if (remaining.isEmpty()) return "";

        String generalOriginal = defaults.isEmpty() ? "" : defaults.get(defaults.size() - 1);
        String general = find(remaining, aliasValue(aliases, generalOriginal));
        return general == null ? remaining.get(0) : general;
    }

    Set<String> mappedCategories(List<String> originals) {
        Set<String> result = new LinkedHashSet<>();
        if (originals == null) return result;
        for (String original : originals) {
            String mapped = resolve(original);
            if (!mapped.isEmpty()) result.add(mapped);
        }
        return result;
    }

    private void linkRestoredDefault(String value) {
        for (String original : defaults) {
            if (original.equalsIgnoreCase(value)) aliases.put(original, value);
        }
    }

    private static String aliasValue(Map<String, String> source, String key) {
        if (source == null || key == null) return "";
        for (Map.Entry<String, String> entry : source.entrySet()) {
            if (entry.getKey() != null && entry.getKey().equalsIgnoreCase(key)) {
                return clean(entry.getValue());
            }
        }
        return "";
    }

    private static void addUnique(List<String> target, List<String> source) {
        if (source == null) return;
        for (String value : source) {
            String clean = clean(value);
            if (isValidName(clean) && find(target, clean) == null) target.add(clean);
        }
    }

    private static String find(List<String> source, String candidate) {
        if (source == null || candidate == null || candidate.isEmpty()) return null;
        for (String value : source) if (value.equalsIgnoreCase(candidate)) return value;
        return null;
    }

    private static String clean(String value) {
        return value == null ? "" : value.trim().replaceAll("\\s+", " ");
    }

    private static boolean isValidName(String value) {
        return !value.isEmpty() && value.length() <= MAXIMUM_NAME_LENGTH
                && value.indexOf('\n') < 0 && value.indexOf('\r') < 0;
    }
}
