package com.macleanofduartenterprises.mybudget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.os.Environment;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ReportGenerator {
    private static final int WIDTH = 595;
    private static final int HEIGHT = 842;
    private final Context context;
    private final LanguageManager language;

    public ReportGenerator(Context context) { this(context, new LanguageManager(LanguageManager.ENGLISH)); }

    public ReportGenerator(Context context, LanguageManager language) {
        this.context = context.getApplicationContext();
        this.language = language == null ? new LanguageManager(LanguageManager.ENGLISH) : language;
    }

    public File createPdf(PeriodReport report, BudgetPlan plan) throws Exception {
        return createPdf(report, plan, new ManualBudget());
    }

    public File createPdf(PeriodReport report, BudgetPlan plan, ManualBudget manualBudget) throws Exception {
        File directory = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        if (directory == null) directory = new File(context.getFilesDir(), "reports");
        if (!directory.exists()) directory.mkdirs();
        File target = new File(directory, "my-budget-report-" + System.currentTimeMillis() + ".pdf");
        PdfDocument document = new PdfDocument();
        PdfWriter writer = new PdfWriter(document, language);
        writer.title(language.t("My Budget") + " — " + report.title);
        writer.text(dateRange(report.start, report.end));
        writer.gap(8);
        writer.heading(language.t("Period summary"));
        if (report.filterCategory.isEmpty()) {
            writer.keyValue(language.t("Income"), Money.format(report.income));
            writer.keyValue(language.t("Expenses"), Money.format(report.expenses));
            writer.keyValue(language.t("Net"), Money.format(report.net));
        } else {
            writer.keyValue(language.t(TransactionRecord.INCOME.equals(report.filterType)
                    ? "Recorded income" : "Recorded spending"),
                    Money.format(TransactionRecord.INCOME.equals(report.filterType)
                            ? report.income : report.expenses));
        }
        writer.keyValue(language.t("Transactions"), Integer.toString(report.transactionCount));
        if (!report.filterCategory.isEmpty()) {
            writer.keyValue(language.t("Type"), language.t(TransactionRecord.INCOME.equals(report.filterType)
                    ? "Income" : "Expense"));
            writer.keyValue(language.t("Category"), language.category(report.filterCategory));
        }
        if (report.accountCount > 0) writer.keyValue(language.t("Bank accounts used"),
                Integer.toString(report.accountCount));
        if (report.statementTransactionCount > 0) writer.keyValue(language.t("Statement transactions used"),
                Integer.toString(report.statementTransactionCount));
        if (report.excludedTransferCount > 0) writer.keyValue(language.t("Transfers or adjustments excluded"),
                Integer.toString(report.excludedTransferCount));
        if (report.filterCategory.isEmpty()) {
            writer.keyValue(language.t("Savings rate"), report.income > 0
                    ? report.savingsRatePercent + "%" : language.t("Not available"));
        }
        writer.gap(8);
        if (TransactionRecord.INCOME.equals(report.filterType) && !report.filterCategory.isEmpty()) {
            writer.heading(language.t("Income category activity"));
            writer.keyValue(language.category(report.filterCategory), Money.format(report.income));
        } else {
            writer.heading(language.t(report.filterCategory.isEmpty()
                    ? "Spending by category" : "Expense category activity"));
            if (report.spendingByCategory.isEmpty()) writer.text(language.t("No expense transactions in this period."));
            for (Map.Entry<String, Long> entry : report.spendingByCategory.entrySet()) {
                writer.keyValue(language.category(entry.getKey()), Money.format(entry.getValue()));
            }
        }
        writer.gap(8);
        writer.heading(language.t("Local agent observations"));
        for (String insight : report.insights) writer.bullet(insight);
        for (String anomaly : report.anomalies) writer.bullet(language.t("Review: %s", anomaly));
        writer.gap(8);
        writer.heading(language.t(BudgetPeriod.isWeekly(plan.period)
                ? "AI weekly budget" : "AI monthly budget"));
        if (report.filterCategory.isEmpty() || TransactionRecord.INCOME.equals(report.filterType)) {
            writer.keyValue(language.t("Expected income"), Money.format(plan.expectedMonthlyIncome));
        }
        if (report.filterCategory.isEmpty()) {
            writer.keyValue(language.t("Savings target"), Money.format(plan.savingsTarget));
        }
        writer.keyValue(language.t("Confidence"), plan.confidencePercent + "%");
        if (plan.statementTransactionCount > 0) {
            writer.keyValue(language.t("Bank-statement transactions used"),
                    Integer.toString(plan.statementTransactionCount));
        }
        if (plan.accountCount > 0) {
            writer.keyValue(language.t("Bank accounts learned"), Integer.toString(plan.accountCount));
        }
        for (Map.Entry<String, Long> entry : plan.categoryLimits.entrySet()) {
            writer.keyValue(language.category(entry.getKey()), Money.format(entry.getValue()));
        }
        if (manualBudget != null && manualBudget.isConfigured()) {
            writer.gap(8);
            writer.heading(language.t(BudgetPeriod.isWeekly(plan.period)
                    ? "Manual weekly budget" : "Manual monthly budget"));
            if (report.filterCategory.isEmpty()) {
                writer.keyValue(language.t("Expected income"), Money.format(manualBudget.expectedMonthlyIncome));
                writer.keyValue(language.t("Category allocation"), Money.format(manualBudget.totalAllocated()));
                writer.keyValue(language.t("Savings target"), Money.format(manualBudget.savingsTarget));
            }
            for (Map.Entry<String, Long> entry : manualBudget.categoryLimits.entrySet()) {
                writer.keyValue(language.category(entry.getKey()), Money.format(entry.getValue()));
            }
        }
        writer.gap(8);
        writer.small(language.t("Generated locally by My Budget. Estimates are based only on transactions recorded on this device and should be reviewed before financial decisions."));
        writer.finish();
        try (FileOutputStream output = new FileOutputStream(target)) { document.writeTo(output); }
        document.close();
        return target;
    }

    public File exportPdf(List<TransactionRecord> records) throws Exception {
        File directory = new File(context.getFilesDir(), "exports");
        if (!directory.exists()) directory.mkdirs();
        File target = new File(directory, "my-budget-transactions-" + System.currentTimeMillis() + ".pdf");
        List<TransactionRecord> safeRecords = records == null ? java.util.Collections.emptyList() : records;
        SimpleDateFormat date = new SimpleDateFormat("d MMM yyyy", language.locale());
        SimpleDateFormat generated = new SimpleDateFormat("d MMM yyyy, HH:mm", language.locale());
        PdfDocument document = new PdfDocument();
        PdfWriter writer = new PdfWriter(document, language);
        writer.title(language.t("Transaction export"));
        writer.keyValue(language.t("Generated"), generated.format(new Date()));
        writer.keyValue(language.t("Transactions"), Integer.toString(safeRecords.size()));
        writer.gap(8);
        writer.heading(language.t("Transaction details"));
        if (safeRecords.isEmpty()) writer.text(language.t("No transactions yet."));
        for (TransactionRecord record : safeRecords) {
            String party = record.merchant == null || record.merchant.trim().isEmpty()
                    ? language.category(record.category) : record.merchant.trim();
            String signedAmount = (TransactionRecord.INCOME.equals(record.type) ? "+" : "−")
                    + Money.format(record.amountCents);
            writer.recordHeading(date.format(new Date(record.timestamp)) + " • " + party, signedAmount,
                    TransactionRecord.INCOME.equals(record.type));
            writer.keyValue(language.t("Type"), language.t(TransactionRecord.INCOME.equals(record.type) ? "Income" : "Expense"));
            writer.keyValue(language.t("Category"), language.category(record.category));
            if (record.bankName != null && !record.bankName.isEmpty()) {
                writer.keyValue(language.t("Bank or institution"), record.bankName);
            }
            if (record.accountName != null && !record.accountName.isEmpty()) {
                writer.keyValue(language.t("Bank account"), record.accountName);
            }
            writer.keyValue(language.t("AI budget and reports"), language.t(record.excludeFromBudget
                    ? "Excluded as a transfer or adjustment" : "Included"));
            if (record.note != null && !record.note.trim().isEmpty()) {
                writer.text(language.t("Note") + ": " + record.note.trim());
            }
            writer.keyValue(language.t("Has document"), language.t(record.documentPath == null || record.documentPath.isEmpty() ? "No" : "Yes"));
            if (record.documentPath != null && !record.documentPath.isEmpty()) {
                writer.keyValue(language.t("Document type"), language.t(
                        TransactionRecord.DOCUMENT_BANK_STATEMENT.equals(record.documentKind)
                                ? "Bank statement" : "Receipt or paystub"));
            }
            writer.gap(5);
        }
        writer.gap(6);
        writer.small(language.t("Created locally. Attached financial documents are not included in this transaction export."));
        writer.finish();
        try (FileOutputStream output = new FileOutputStream(target)) { document.writeTo(output); }
        document.close();
        return target;
    }

    public File exportCsv(List<TransactionRecord> records) throws Exception {
        File directory = new File(context.getFilesDir(), "exports");
        if (!directory.exists()) directory.mkdirs();
        File target = new File(directory, "my-budget-transactions-" + System.currentTimeMillis() + ".csv");
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", language.locale());
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(target))) {
            writer.write(csv(language.t("Date")) + "," + csv(language.t("Type")) + ","
                    + csv(language.t("Merchant or employer")) + "," + csv(language.t("Category")) + ","
                    + csv(language.t("Amount")) + "," + csv(language.t("Note")) + ","
                    + csv(language.t("Bank or institution")) + "," + csv(language.t("Bank account")) + ","
                    + csv(language.t("AI budget and reports")) + ","
                    + csv(language.t("Has document")) + "," + csv(language.t("Document type")) + "\n");
            for (TransactionRecord record : records) {
                writer.write(csv(format.format(new Date(record.timestamp))) + "," + csv(language.t(TransactionRecord.INCOME.equals(record.type) ? "Income" : "Expense")) + ","
                        + csv(record.merchant) + "," + csv(language.category(record.category)) + ","
                        + csv(String.format(Locale.US, "%.2f", record.amountCents / 100.0)) + ","
                        + csv(record.note) + "," + csv(record.bankName) + "," + csv(record.accountName) + ","
                        + csv(language.t(record.excludeFromBudget
                        ? "Excluded as a transfer or adjustment" : "Included")) + ","
                        + csv(language.t(record.documentPath.isEmpty() ? "No" : "Yes")) + ","
                        + csv(record.documentPath.isEmpty() ? "" : language.t(
                        TransactionRecord.DOCUMENT_BANK_STATEMENT.equals(record.documentKind)
                                ? "Bank statement" : "Receipt or paystub")) + "\n");
            }
        }
        return target;
    }

    private static String csv(String value) { return "\"" + (value == null ? "" : value.replace("\"", "\"\"")) + "\""; }
    private String dateRange(long start, long end) {
        SimpleDateFormat format = new SimpleDateFormat("d MMM yyyy", language.locale());
        return format.format(new Date(start)) + " – " + format.format(new Date(Math.max(start, end - 1)));
    }

    private static final class PdfWriter {
        private final PdfDocument document;
        private PdfDocument.Page page;
        private Canvas canvas;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final LanguageManager language;
        private int pageNumber;
        private float y;

        PdfWriter(PdfDocument document, LanguageManager language) {
            this.document = document;
            this.language = language;
            newPage();
        }

        void title(String value) {
            paint.setColor(Color.rgb(22, 56, 46));
            paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            paint.setTextSize(23);
            line(value, 30);
        }

        void heading(String value) {
            ensure(30);
            paint.setColor(Color.rgb(22, 56, 46));
            paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            paint.setTextSize(15);
            line(value, 23);
            paint.setColor(Color.rgb(201, 167, 80));
            canvas.drawRect(42, y - 5, WIDTH - 42, y - 3, paint);
            y += 5;
        }

        void text(String value) { wrapped(value, 11, 15, Color.rgb(30, 38, 34), 0); }
        void small(String value) { wrapped(value, 8.5f, 12, Color.DKGRAY, 0); }
        void bullet(String value) { wrapped("• " + value, 10.5f, 15, Color.rgb(30, 38, 34), 12); }

        void keyValue(String key, String value) {
            ensure(18);
            paint.setTextSize(10.5f);
            paint.setColor(Color.rgb(30, 38, 34));
            paint.setTypeface(Typeface.DEFAULT);
            canvas.drawText(key, 45, y, paint);
            paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            float width = paint.measureText(value);
            canvas.drawText(value, WIDTH - 45 - width, y, paint);
            y += 17;
        }

        void recordHeading(String value, String amount, boolean income) {
            ensure(24);
            paint.setTextSize(11);
            paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            paint.setColor(Color.rgb(30, 38, 34));
            float amountWidth = paint.measureText(amount);
            float maximum = WIDTH - 105 - amountWidth;
            canvas.drawText(ellipsize(value, maximum), 45, y, paint);
            paint.setColor(income ? Color.rgb(22, 111, 78) : Color.rgb(155, 60, 52));
            canvas.drawText(amount, WIDTH - 45 - amountWidth, y, paint);
            y += 18;
        }

        void gap(float amount) { y += amount; }

        void finish() { if (page != null) document.finishPage(page); page = null; }

        private void wrapped(String value, float size, float leading, int color, float hangingIndent) {
            paint.setTextSize(size);
            paint.setColor(color);
            paint.setTypeface(Typeface.DEFAULT);
            String[] words = value.split("\\s+");
            StringBuilder line = new StringBuilder();
            boolean first = true;
            float available = WIDTH - 90;
            for (String word : words) {
                String candidate = line.length() == 0 ? word : line + " " + word;
                if (paint.measureText(candidate) > available - (first ? 0 : hangingIndent) && line.length() > 0) {
                    ensure(leading);
                    canvas.drawText(line.toString(), 45 + (first ? 0 : hangingIndent), y, paint);
                    y += leading;
                    first = false;
                    line = new StringBuilder(word);
                } else line = new StringBuilder(candidate);
            }
            if (line.length() > 0) {
                ensure(leading);
                canvas.drawText(line.toString(), 45 + (first ? 0 : hangingIndent), y, paint);
                y += leading;
            }
        }

        private void line(String value, float leading) {
            ensure(leading);
            canvas.drawText(value, 42, y, paint);
            y += leading;
        }

        private String ellipsize(String value, float maximumWidth) {
            String result = value == null ? "" : value;
            if (paint.measureText(result) <= maximumWidth) return result;
            String suffix = "…";
            while (result.length() > 1 && paint.measureText(result + suffix) > maximumWidth) {
                result = result.substring(0, result.length() - 1);
            }
            return result + suffix;
        }

        private void ensure(float required) { if (y + required > HEIGHT - 48) newPage(); }

        private void newPage() {
            if (page != null) document.finishPage(page);
            pageNumber++;
            page = document.startPage(new PdfDocument.PageInfo.Builder(WIDTH, HEIGHT, pageNumber).create());
            canvas = page.getCanvas();
            canvas.drawColor(Color.WHITE);
            paint.setColor(Color.rgb(22, 56, 46));
            paint.setTextSize(8);
            paint.setTypeface(Typeface.DEFAULT);
            canvas.drawText(language.t("MY BUDGET • LOCAL REPORT"), 42, 28, paint);
            String pageText = language.t("Page %d", pageNumber);
            canvas.drawText(pageText, WIDTH - 42 - paint.measureText(pageText), HEIGHT - 24, paint);
            y = 58;
        }
    }
}
