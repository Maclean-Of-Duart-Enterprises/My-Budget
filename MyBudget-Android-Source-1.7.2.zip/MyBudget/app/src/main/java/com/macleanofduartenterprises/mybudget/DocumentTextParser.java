package com.macleanofduartenterprises.mybudget;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class DocumentTextParser {
    private static final Pattern MONEY = Pattern.compile("(?:[$€₸₴₽£]\\s*)?([0-9]{1,3}(?:[ ,.'’\\u00A0][0-9]{3})*(?:[.,][0-9]{2})|[0-9]+[.,][0-9]{2})");
    private static final Pattern DATE = Pattern.compile("\\b(0?[1-9]|[12][0-9]|3[01])[/.-](0?[1-9]|[12][0-9]|3[01])[/.-]((?:19|20)?[0-9]{2})\\b");
    private static final Pattern ISO_DATE = Pattern.compile("\\b((?:19|20)[0-9]{2})[/.-](0?[1-9]|1[0-2])[/.-](0?[1-9]|[12][0-9]|3[01])\\b");
    private static final List<String> TOTAL_LABELS = Arrays.asList(
            "grand total", "amount due", "balance due", "total due", "total",
            "итого", "всего", "к оплате", "сума", "разом", "до сплати",
            "барлығы", "жалпы", "төлеуге", "төлем сомасы",
            "importe total", "total a pagar", "a pagar");
    private static final List<String> NET_PAY_LABELS = Arrays.asList(
            "net pay", "net amount", "take home", "direct deposit",
            "чистая зарплата", "чистый доход", "к выдаче", "на руки",
            "чиста зарплата", "до виплати", "чистий дохід",
            "таза жалақы", "таза табыс", "төленетін сома",
            "salario neto", "pago neto", "sueldo neto", "líquido a percibir", "neto");

    public ParsedDocument parse(String text, long fallbackDate) {
        return parse(text, fallbackDate, LanguageManager.ENGLISH);
    }

    public ParsedDocument parse(String text, long fallbackDate, String languageCode) {
        ParsedDocument parsed = new ParsedDocument();
        parsed.rawText = text == null ? "" : text.trim();
        parsed.dateMillis = findDate(parsed.rawText, fallbackDate, languageCode);
        String lower = parsed.rawText.toLowerCase(Locale.ROOT);
        boolean paystub = containsAny(lower,
                "pay stub", "paystub", "gross pay", "net pay", "earnings statement", "ytd earnings",
                "расчётный лист", "расчетный лист", "заработная плата", "начислено", "удержано",
                "розрахунковий лист", "заробітна плата", "нараховано", "утримано",
                "жалақы парағы", "еңбекақы", "есептелді", "ұсталды",
                "nómina", "nomina", "salario bruto", "sueldo bruto", "devengos", "deducciones");
        if (paystub) parsePaystub(parsed);
        else parseReceipt(parsed);
        if (parsed.amountCents <= 0) parsed.warnings.add("Amount was not found; review it before saving.");
        if (parsed.party.isEmpty()) parsed.warnings.add("Merchant or employer was not identified.");
        int confidence = 25;
        if (parsed.amountCents > 0) confidence += 35;
        if (!parsed.party.isEmpty()) confidence += 20;
        if (parsed.dateMillis != fallbackDate) confidence += 10;
        if (paystub) confidence += 5;
        parsed.confidencePercent = Math.min(95, confidence);
        return parsed;
    }

    private void parsePaystub(ParsedDocument parsed) {
        parsed.kind = ParsedDocument.PAYSTUB;
        parsed.transactionType = TransactionRecord.INCOME;
        parsed.category = "Paycheck";
        parsed.amountCents = labeledAmount(parsed.rawText, NET_PAY_LABELS, true);
        if (parsed.amountCents == 0) parsed.amountCents = labeledAmount(parsed.rawText, Arrays.asList(
                "current pay", "pay amount", "к выплате", "выплачено", "до виплати", "виплачено",
                "төлеуге", "төленді", "a percibir", "importe neto"), true);
        parsed.party = firstMeaningfulLine(parsed.rawText, true);
    }

    private void parseReceipt(ParsedDocument parsed) {
        parsed.kind = ParsedDocument.RECEIPT;
        parsed.transactionType = TransactionRecord.EXPENSE;
        parsed.amountCents = labeledAmount(parsed.rawText, TOTAL_LABELS, false);
        parsed.party = firstMeaningfulLine(parsed.rawText, false);
        parsed.category = inferCategory(parsed.rawText);
    }

    private static long labeledAmount(String text, List<String> labels, boolean allowAnyPosition) {
        String[] lines = text.split("\\R");
        for (String label : labels) {
            for (int i = lines.length - 1; i >= 0; i--) {
                String lower = lines[i].toLowerCase(Locale.ROOT);
                if (!lower.contains(label)) continue;
                if (!allowAnyPosition && containsAny(lower, "subtotal", "tax total", "подытог", "налог",
                        "проміжний підсумок", "податок", "аралық жиынтық", "салық", "impuestos")) continue;
                Matcher matcher = MONEY.matcher(lines[i]);
                long last = 0;
                while (matcher.find()) last = Money.parseCents(matcher.group(1));
                if (last > 0) return last;
                if (i + 1 < lines.length) {
                    matcher = MONEY.matcher(lines[i + 1]);
                    if (matcher.find()) return Money.parseCents(matcher.group(1));
                }
            }
        }
        // OCR sometimes drops the word TOTAL. The largest currency value near the bottom is the safest fallback.
        long largest = 0;
        int start = Math.max(0, lines.length - 8);
        for (int i = start; i < lines.length; i++) {
            String lower = lines[i].toLowerCase(Locale.ROOT);
            if (containsAny(lower, "change", "cash tender", "ytd", "сдача", "наличные", "решта",
                    "готівка", "қайтарым", "қолма-қол", "cambio", "efectivo", "acumulado")) continue;
            Matcher matcher = MONEY.matcher(lines[i]);
            while (matcher.find()) largest = Math.max(largest, Money.parseCents(matcher.group(1)));
        }
        return largest;
    }

    private static String firstMeaningfulLine(String text, boolean paystub) {
        String[] lines = text.split("\\R");
        for (int i = 0; i < Math.min(lines.length, 8); i++) {
            String line = lines[i].trim().replaceAll("\\s+", " ");
            String lower = line.toLowerCase(Locale.ROOT);
            if (line.length() < 3 || line.length() > 60) continue;
            if (MONEY.matcher(line).find() || DATE.matcher(line).find()) continue;
            if (containsAny(lower, "receipt", "invoice", "paystub", "pay stub", "earnings statement",
                    "чек", "квитанция", "расчётный лист", "рахунок", "розрахунковий лист",
                    "түбіртек", "жалақы парағы", "recibo", "factura", "nómina", "nomina")) continue;
            if (containsAny(lower, "www.", "http", "phone", "tel:", "store #", "employee id",
                    "телефон", "магазин №", "табельный номер", "працівник", "қызметкер", "empleado")) continue;
            if (line.matches(".*\\p{L}.*")) return titleCaseIfAllCaps(line);
        }
        return "";
    }

    private static long findDate(String text, long fallback, String languageCode) {
        Matcher iso = ISO_DATE.matcher(text);
        if (iso.find()) return dateValue(Integer.parseInt(iso.group(1)), Integer.parseInt(iso.group(2)),
                Integer.parseInt(iso.group(3)), fallback);
        Matcher matcher = DATE.matcher(text);
        if (!matcher.find()) return fallback;
        int first = Integer.parseInt(matcher.group(1));
        int second = Integer.parseInt(matcher.group(2));
        boolean monthFirst = LanguageManager.ENGLISH.equals(languageCode) && first <= 12;
        int day = monthFirst ? second : first;
        int month = monthFirst ? first : second;
        int year = Integer.parseInt(matcher.group(3));
        if (year < 100) year += year >= 70 ? 1900 : 2000;
        return dateValue(year, month, day, fallback);
    }

    private static long dateValue(int year, int month, int day, long fallback) {
        try {
            return LocalDate.of(year, month, day).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static String inferCategory(String text) {
        String lower = text.toLowerCase(Locale.ROOT);
        if (containsAny(lower, "grocery", "market", "supermarket", "produce", "food store", "продукты",
                "супермаркет", "продукти", "азық-түлік", "дүкен", "supermercado", "alimentación")) return "Groceries";
        if (containsAny(lower, "restaurant", "cafe", "coffee", "pizza", "grill", "diner", "ресторан",
                "кафе", "кофе", "мейрамхана", "дәмхана", "restaurante", "cafetería")) return "Dining";
        if (containsAny(lower, "gasoline", "fuel", "service station", "auto parts", "parking", "бензин",
                "топливо", "парковка", "пальне", "бензин", "жанармай", "тұрақ", "gasolina", "combustible", "aparcamiento")) return "Transportation";
        if (containsAny(lower, "pharmacy", "medical", "clinic", "hospital", "dental", "аптека", "клиника",
                "больница", "лікарня", "дәріхана", "емхана", "farmacia", "clínica", "hospital")) return "Healthcare";
        if (containsAny(lower, "electric", "water bill", "utility", "internet", "wireless", "telephone",
                "электроэнергия", "вода", "коммунальные", "електроенергія", "комунальні", "жарық",
                "су төлемі", "коммуналдық", "electricidad", "agua", "internet", "teléfono")) return "Utilities";
        if (containsAny(lower, "hardware", "lumber", "home improvement", "household", "хозтовары", "дом",
                "господарські", "дім", "үй тауарлары", "ferretería", "hogar")) return "Household";
        if (containsAny(lower, "tuition", "school", "books", "education", "обучение", "школа", "книги",
                "навчання", "мектеп", "кітап", "matrícula", "escuela", "libros")) return "Education";
        if (containsAny(lower, "donation", "church", "charity", "tithe", "пожертвование", "благотворительность",
                "пожертва", "қайырымдылық", "donación", "caridad")) return "Giving";
        return "Other";
    }

    private static boolean containsAny(String value, String... needles) {
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }

    private static String titleCaseIfAllCaps(String value) {
        if (!value.equals(value.toUpperCase(Locale.ROOT))) return value;
        StringBuilder result = new StringBuilder();
        for (String word : value.toLowerCase(Locale.ROOT).split(" ")) {
            if (word.isEmpty()) continue;
            if (result.length() > 0) result.append(' ');
            result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return result.toString();
    }
}
