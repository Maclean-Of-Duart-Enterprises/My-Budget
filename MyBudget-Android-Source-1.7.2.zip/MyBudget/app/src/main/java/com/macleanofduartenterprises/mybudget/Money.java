package com.macleanofduartenterprises.mybudget;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

public final class Money {
    private Money() {}

    public static String format(long cents) {
        return NumberFormat.getCurrencyInstance(Locale.getDefault()).format(cents / 100.0);
    }

    public static long parseCents(String value) {
        if (value == null) return 0;
        String clean = value.trim().replaceAll("[^0-9,.'’\u00A0 -]", "")
                .replace(" ", "").replace("\u00A0", "").replace("'", "").replace("’", "");
        if (clean.isEmpty() || clean.equals("-") || clean.equals(".")) return 0;
        int comma = clean.lastIndexOf(',');
        int dot = clean.lastIndexOf('.');
        if (comma >= 0 && dot >= 0) {
            char decimal = comma > dot ? ',' : '.';
            char grouping = decimal == ',' ? '.' : ',';
            clean = clean.replace(String.valueOf(grouping), "");
            if (decimal == ',') clean = clean.replace(',', '.');
        } else if (comma >= 0) {
            int decimals = clean.length() - comma - 1;
            clean = decimals == 2 ? clean.replace(',', '.') : clean.replace(",", "");
        } else if (dot >= 0 && clean.length() - dot - 1 != 2) {
            clean = clean.replace(".", "");
        }
        try {
            return new BigDecimal(clean).multiply(new BigDecimal("100"))
                    .setScale(0, RoundingMode.HALF_UP).longValueExact();
        } catch (Exception ignored) {
            return 0;
        }
    }
}
