package com.macleanofduartenterprises.mybudget;

/** Canonical period names shared by manual and local-agent budgets. */
public final class BudgetPeriod {
    public static final String WEEKLY = "weekly";
    public static final String MONTHLY = "monthly";

    private BudgetPeriod() {}

    public static String normalize(String value) {
        return WEEKLY.equals(value) ? WEEKLY : MONTHLY;
    }

    public static boolean isWeekly(String value) {
        return WEEKLY.equals(normalize(value));
    }
}
