package com.macleanofduartenterprises.mybudget;

import java.util.Arrays;
import java.util.List;

public final class TransactionRecord {
    public static final String INCOME = "INCOME";
    public static final String EXPENSE = "EXPENSE";
    public static final String DOCUMENT_RECEIPT_PAYSTUB = "RECEIPT_PAYSTUB";
    public static final String DOCUMENT_BANK_STATEMENT = "BANK_STATEMENT";

    public static final List<String> EXPENSE_CATEGORIES = Arrays.asList(
            "Housing", "Utilities", "Groceries", "Transportation", "Healthcare",
            "Insurance", "Debt", "Childcare", "Household", "Dining", "Shopping",
            "Entertainment", "Giving", "Education", "Business", "Other"
    );

    public static final List<String> INCOME_CATEGORIES = Arrays.asList(
            "Paycheck", "Business income", "Benefits", "Reimbursement", "Gift", "Other income"
    );

    public long id;
    public long timestamp;
    public String merchant = "";
    public String category = "Other";
    public String type = EXPENSE;
    public long amountCents;
    public String note = "";
    public String documentPath = "";
    public String documentMime = "";
    public String documentKind = "";
    public String extractedText = "";
    public String bankName = "";
    public String accountId = "";
    public String accountName = "";
    public String sourceFingerprint = "";
    public boolean excludeFromBudget;
    public long createdAt;

    public TransactionRecord copy() {
        TransactionRecord copy = new TransactionRecord();
        copy.id = id;
        copy.timestamp = timestamp;
        copy.merchant = merchant;
        copy.category = category;
        copy.type = type;
        copy.amountCents = amountCents;
        copy.note = note;
        copy.documentPath = documentPath;
        copy.documentMime = documentMime;
        copy.documentKind = documentKind;
        copy.extractedText = extractedText;
        copy.bankName = bankName;
        copy.accountId = accountId;
        copy.accountName = accountName;
        copy.sourceFingerprint = sourceFingerprint;
        copy.excludeFromBudget = excludeFromBudget;
        copy.createdAt = createdAt;
        return copy;
    }
}
