package com.macleanofduartenterprises.mybudget;

import java.util.ArrayList;
import java.util.List;

public final class ParsedDocument {
    public static final String RECEIPT = "RECEIPT";
    public static final String PAYSTUB = "PAYSTUB";

    public String kind = RECEIPT;
    public String party = "";
    public String category = "Other";
    public String transactionType = TransactionRecord.EXPENSE;
    public long amountCents;
    public long dateMillis;
    public int confidencePercent;
    public String rawText = "";
    public final List<String> warnings = new ArrayList<>();
}
