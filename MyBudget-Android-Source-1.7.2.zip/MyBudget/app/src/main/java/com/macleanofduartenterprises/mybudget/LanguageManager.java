package com.macleanofduartenterprises.mybudget;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Small, offline localization catalog used by the programmatic UI and generated reports.
 * Canonical database values stay in English so users can change languages without changing data.
 */
public final class LanguageManager {
    public static final String ENGLISH = "en";
    public static final String RUSSIAN = "ru";
    public static final String UKRAINIAN = "uk";
    public static final String KAZAKH = "kk";
    public static final String SPANISH = "es";

    private static final List<String> CODES = Arrays.asList(ENGLISH, RUSSIAN, UKRAINIAN, KAZAKH, SPANISH);
    private static final List<String> NAMES = Arrays.asList("English", "Русский", "Українська", "Қазақша", "Español");
    private static final Map<String, Map<String, String>> TRANSLATIONS = new LinkedHashMap<>();

    static {
        TRANSLATIONS.put(ENGLISH, new LinkedHashMap<>());
        Map<String, String> ru = new LinkedHashMap<>();
        Map<String, String> uk = new LinkedHashMap<>();
        Map<String, String> kk = new LinkedHashMap<>();
        Map<String, String> es = new LinkedHashMap<>();
        TRANSLATIONS.put(RUSSIAN, ru);
        TRANSLATIONS.put(UKRAINIAN, uk);
        TRANSLATIONS.put(KAZAKH, kk);
        TRANSLATIONS.put(SPANISH, es);

        add(ru, "My Budget", "Мой бюджет");
        add(uk, "My Budget", "Мій бюджет");
        add(kk, "My Budget", "Менің бюджетім");
        add(es, "My Budget", "Mi presupuesto");
        add(ru, "Private • Offline • On this device", "Конфиденциально • Офлайн • На этом устройстве");
        add(uk, "Private • Offline • On this device", "Приватно • Офлайн • На цьому пристрої");
        add(kk, "Private • Offline • On this device", "Құпия • Офлайн • Осы құрылғыда");
        add(es, "Private • Offline • On this device", "Privado • Sin conexión • En este dispositivo");

        phrase("Custom background", "Пользовательский фон", "Власне тло", "Жеке фон", "Fondo personalizado", ru, uk, kk, es);
        phrase("Budget avatar", "Аватар бюджета", "Аватар бюджету", "Бюджет аватары", "Avatar del presupuesto", ru, uk, kk, es);
        phrase("+ Add", "+ Добавить", "+ Додати", "+ Қосу", "+ Añadir", ru, uk, kk, es);
        phrase("Home", "Главная", "Головна", "Басты", "Inicio", ru, uk, kk, es);
        phrase("Transactions", "Операции", "Операції", "Транзакциялар", "Transacciones", ru, uk, kk, es);
        phrase("Scan", "Сканировать", "Сканувати", "Сканерлеу", "Escanear", ru, uk, kk, es);
        phrase("Reports", "Отчёты", "Звіти", "Есептер", "Informes", ru, uk, kk, es);
        phrase("Settings", "Настройки", "Налаштування", "Баптаулар", "Ajustes", ru, uk, kk, es);

        phrase("This month", "Этот месяц", "Цей місяць", "Осы ай", "Este mes", ru, uk, kk, es);
        phrase("Your budget at a glance", "Ваш бюджет в одном месте", "Ваш бюджет в одному місці", "Бюджетіңіз бір көріністе", "Tu presupuesto de un vistazo", ru, uk, kk, es);
        phrase("Scan receipt or paystub", "Сканировать чек или расчётный лист", "Сканувати чек або розрахунковий лист", "Түбіртекті немесе жалақы парағын сканерлеу", "Escanear recibo o nómina", ru, uk, kk, es);
        phrase("Enter manually", "Ввести вручную", "Ввести вручну", "Қолмен енгізу", "Introducir manualmente", ru, uk, kk, es);
        phrase("Income", "Доход", "Дохід", "Кіріс", "Ingresos", ru, uk, kk, es);
        phrase("Spent", "Расходы", "Витрачено", "Жұмсалды", "Gastado", ru, uk, kk, es);
        phrase("Expenses", "Расходы", "Витрати", "Шығыстар", "Gastos", ru, uk, kk, es);
        phrase("Expense", "Расход", "Витрата", "Шығыс", "Gasto", ru, uk, kk, es);
        phrase("Net", "Итог", "Баланс", "Қалдық", "Neto", ru, uk, kk, es);
        phrase("Local budget agent", "Локальный бюджетный помощник", "Локальний бюджетний помічник", "Жергілікті бюджет көмекшісі", "Agente de presupuesto local", ru, uk, kk, es);
        phrase("Waiting for spending history", "Ожидание истории расходов", "Очікування історії витрат", "Шығындар тарихы күтілуде", "Esperando el historial de gastos", ru, uk, kk, es);
        phrase("Learned-plan confidence: %1$d%% from %2$d days", "Надёжность рассчитанного плана: %1$d%% по данным за %2$d дн.", "Надійність розрахованого плану: %1$d%% за даними %2$d дн.", "Үйренген жоспар сенімділігі: %1$d%%, %2$d күн дерегі", "Confianza del plan aprendido: %1$d%% con %2$d días", ru, uk, kk, es);
        phrase("Recent transactions", "Недавние операции", "Останні операції", "Соңғы транзакциялар", "Transacciones recientes", ru, uk, kk, es);
        phrase("No transactions yet. Scan a document or enter one manually.", "Операций пока нет. Отсканируйте документ или добавьте операцию вручную.", "Операцій ще немає. Скануйте документ або додайте операцію вручну.", "Транзакциялар әлі жоқ. Құжатты сканерлеңіз немесе қолмен енгізіңіз.", "Aún no hay transacciones. Escanea un documento o introduce una manualmente.", ru, uk, kk, es);
        phrase("View all transactions", "Показать все операции", "Переглянути всі операції", "Барлық транзакцияны көру", "Ver todas las transacciones", ru, uk, kk, es);

        phrase("Sorted by %1$s • %2$s. Change this in Settings.", "Сортировка: %1$s • %2$s. Изменить можно в настройках.", "Сортування: %1$s • %2$s. Змінити можна в налаштуваннях.", "Сұрыптау: %1$s • %2$s. Баптаулардан өзгертуге болады.", "Ordenado por %1$s • %2$s. Cámbialo en Ajustes.", ru, uk, kk, es);
        phrase("ascending", "по возрастанию", "за зростанням", "өсу ретімен", "ascendente", ru, uk, kk, es);
        phrase("descending", "по убыванию", "за спаданням", "кему ретімен", "descendente", ru, uk, kk, es);
        phrase("date", "дате", "датою", "күні", "fecha", ru, uk, kk, es);
        phrase("amount", "сумме", "сумою", "сомасы", "importe", ru, uk, kk, es);
        phrase("merchant", "продавцу", "продавцем", "сатушы", "comercio", ru, uk, kk, es);
        phrase("category", "категории", "категорією", "санат", "categoría", ru, uk, kk, es);
        phrase("type", "типу", "типом", "түрі", "tipo", ru, uk, kk, es);
        phrase("Search merchant, category, or note", "Поиск по продавцу, категории или заметке", "Пошук за продавцем, категорією або нотаткою", "Сатушы, санат немесе жазба бойынша іздеу", "Buscar comercio, categoría o nota", ru, uk, kk, es);
        phrase("No transactions yet.", "Операций пока нет.", "Операцій ще немає.", "Транзакциялар әлі жоқ.", "Aún no hay transacciones.", ru, uk, kk, es);
        phrase("No transactions match your search.", "По вашему запросу ничего не найдено.", "За вашим запитом нічого не знайдено.", "Іздеуіңізге сәйкес транзакция табылмады.", "Ninguna transacción coincide con la búsqueda.", ru, uk, kk, es);
        phrase("Add a transaction", "Добавить операцию", "Додати операцію", "Транзакция қосу", "Añadir una transacción", ru, uk, kk, es);
        phrase("%1$s %2$s at %3$s", "%1$s %2$s, продавец: %3$s", "%1$s %2$s, продавець: %3$s", "%1$s %2$s, сатушы: %3$s", "%1$s de %2$s en %3$s", ru, uk, kk, es);
        phrase("Manage transactions", "Управлять операциями", "Керувати операціями", "Транзакцияларды басқару", "Gestionar transacciones", ru, uk, kk, es);
        phrase("Transaction management", "Управление операциями", "Керування операціями", "Транзакцияларды басқару", "Gestión de transacciones", ru, uk, kk, es);
        phrase("Select one transaction for full editing, or select several to replace checked fields or delete them together.", "Выберите одну операцию для полного редактирования или несколько, чтобы заменить отмеченные поля либо удалить их вместе.", "Виберіть одну операцію для повного редагування або кілька, щоб замінити позначені поля чи видалити їх разом.", "Толық өңдеу үшін бір транзакцияны немесе белгіленген өрістерді ауыстыру не бірге жою үшін бірнешеуін таңдаңыз.", "Selecciona una transacción para editarla por completo o varias para reemplazar los campos marcados o eliminarlas juntas.", ru, uk, kk, es);
        phrase("Select all shown", "Выбрать все показанные", "Вибрати всі показані", "Көрсетілгендердің бәрін таңдау", "Seleccionar todas las mostradas", ru, uk, kk, es);
        phrase("Clear selection", "Снять выделение", "Очистити вибір", "Таңдауды тазалау", "Borrar selección", ru, uk, kk, es);
        phrase("Edit or replace selected", "Изменить или заменить выбранные", "Редагувати або замінити вибрані", "Таңдалғандарды өңдеу немесе ауыстыру", "Editar o reemplazar seleccionadas", ru, uk, kk, es);
        phrase("Delete selected", "Удалить выбранные", "Видалити вибрані", "Таңдалғандарды жою", "Eliminar seleccionadas", ru, uk, kk, es);
        phrase("Done managing", "Завершить управление", "Завершити керування", "Басқаруды аяқтау", "Finalizar gestión", ru, uk, kk, es);
        phrase("Select transaction: %s", "Выбрать операцию: %s", "Вибрати операцію: %s", "Транзакцияны таңдау: %s", "Seleccionar transacción: %s", ru, uk, kk, es);
        phrase("%1$d selected • %2$d shown", "Выбрано: %1$d • показано: %2$d", "Вибрано: %1$d • показано: %2$d", "Таңдалды: %1$d • көрсетілді: %2$d", "%1$d seleccionadas • %2$d mostradas", ru, uk, kk, es);
        phrase("Edit or replace selected transaction", "Изменить или заменить выбранную операцию", "Редагувати або замінити вибрану операцію", "Таңдалған транзакцияны өңдеу немесе ауыстыру", "Editar o reemplazar la transacción seleccionada", ru, uk, kk, es);
        phrase("Replace fields in %d selected transactions", "Заменить поля в %d выбранных операциях", "Замінити поля у %d вибраних операціях", "%d таңдалған транзакциядағы өрістерді ауыстыру", "Reemplazar campos en %d transacciones seleccionadas", ru, uk, kk, es);
        phrase("Delete selected transaction", "Удалить выбранную операцию", "Видалити вибрану операцію", "Таңдалған транзакцияны жою", "Eliminar la transacción seleccionada", ru, uk, kk, es);
        phrase("Delete %d selected transactions", "Удалить %d выбранных операций", "Видалити %d вибраних операцій", "%d таңдалған транзакцияны жою", "Eliminar %d transacciones seleccionadas", ru, uk, kk, es);

        phrase("← Back to transactions", "← Назад к операциям", "← Назад до операцій", "← Транзакцияларға оралу", "← Volver a transacciones", ru, uk, kk, es);
        phrase("Amount", "Сумма", "Сума", "Сома", "Importe", ru, uk, kk, es);
        phrase("Merchant", "Продавец", "Продавець", "Сатушы", "Comercio", ru, uk, kk, es);
        phrase("Type", "Тип", "Тип", "Түрі", "Tipo", ru, uk, kk, es);
        phrase("Category", "Категория", "Категорія", "Санат", "Categoría", ru, uk, kk, es);
        phrase("Date", "Дата", "Дата", "Күні", "Fecha", ru, uk, kk, es);
        phrase("Note", "Заметка", "Нотатка", "Жазба", "Nota", ru, uk, kk, es);
        phrase("View document", "Открыть документ", "Відкрити документ", "Құжатты ашу", "Ver documento", ru, uk, kk, es);
        phrase("View receipt or paystub", "Открыть чек или расчётный лист", "Відкрити чек або розрахунковий лист", "Түбіртекті немесе жалақы парағын ашу", "Ver recibo o nómina", ru, uk, kk, es);
        phrase("View bank statement", "Открыть банковскую выписку", "Відкрити банківську виписку", "Банк көшірмесін ашу", "Ver extracto bancario", ru, uk, kk, es);
        phrase("Edit transaction", "Изменить операцию", "Редагувати операцію", "Транзакцияны өңдеу", "Editar transacción", ru, uk, kk, es);
        phrase("Edit or replace transaction", "Изменить или заменить операцию", "Редагувати або замінити операцію", "Транзакцияны өңдеу немесе ауыстыру", "Editar o reemplazar transacción", ru, uk, kk, es);
        phrase("Delete transaction", "Удалить операцию", "Видалити операцію", "Транзакцияны жою", "Eliminar transacción", ru, uk, kk, es);
        phrase("Delete this transaction?", "Удалить эту операцию?", "Видалити цю операцію?", "Бұл транзакция жойылсын ба?", "¿Eliminar esta transacción?", ru, uk, kk, es);
        phrase("This cannot be undone.", "Это действие нельзя отменить.", "Цю дію неможливо скасувати.", "Бұл әрекетті қайтару мүмкін емес.", "Esta acción no se puede deshacer.", ru, uk, kk, es);
        phrase("The attached receipt or paystub will also be deleted from the app.", "Прикреплённый чек или расчётный лист также будет удалён из приложения.", "Прикріплений чек або розрахунковий лист також буде видалено з застосунку.", "Тіркелген түбіртек немесе жалақы парағы да қолданбадан жойылады.", "El recibo o la nómina adjuntos también se eliminarán de la aplicación.", ru, uk, kk, es);
        phrase("The attached document will also be deleted from the app.", "Прикреплённый документ также будет удалён из приложения.", "Прикріплений документ також буде видалено із застосунку.", "Тіркелген құжат та қолданбадан жойылады.", "El documento adjunto también se eliminará de la aplicación.", ru, uk, kk, es);
        phrase("The source bank statement will remain available from its other imported transactions.", "Исходная банковская выписка останется доступной из других импортированных операций.", "Вихідна банківська виписка залишиться доступною з інших імпортованих операцій.", "Бастапқы банк көшірмесі басқа импортталған транзакциялардан қолжетімді болып қалады.", "El extracto bancario original seguirá disponible desde las otras transacciones importadas.", ru, uk, kk, es);
        phrase("Cancel", "Отмена", "Скасувати", "Бас тарту", "Cancelar", ru, uk, kk, es);
        phrase("Delete", "Удалить", "Видалити", "Жою", "Eliminar", ru, uk, kk, es);
        phrase("Transaction deleted", "Операция удалена", "Операцію видалено", "Транзакция жойылды", "Transacción eliminada", ru, uk, kk, es);
        phrase("Delete %d selected transactions?", "Удалить %d выбранных операций?", "Видалити %d вибраних операцій?", "%d таңдалған транзакция жойылсын ба?", "¿Eliminar %d transacciones seleccionadas?", ru, uk, kk, es);
        phrase("Attached financial documents no longer used by another transaction will also be deleted. This cannot be undone.", "Прикреплённые финансовые документы, которые больше не используются другими операциями, также будут удалены. Это действие нельзя отменить.", "Прикріплені фінансові документи, які більше не використовуються іншими операціями, також буде видалено. Цю дію неможливо скасувати.", "Басқа транзакция пайдаланбайтын тіркелген қаржылық құжаттар да жойылады. Бұл әрекетті қайтару мүмкін емес.", "También se eliminarán los documentos financieros adjuntos que ya no use otra transacción. Esta acción no se puede deshacer.", ru, uk, kk, es);
        phrase("Deleting selected transactions…", "Удаление выбранных операций…", "Видалення вибраних операцій…", "Таңдалған транзакциялар жойылуда…", "Eliminando transacciones seleccionadas…", ru, uk, kk, es);
        phrase("Updating the local history and encrypted document storage.", "Обновление локальной истории и зашифрованного хранилища документов.", "Оновлення локальної історії та зашифрованого сховища документів.", "Жергілікті тарих пен шифрланған құжат қоймасы жаңартылуда.", "Actualizando el historial local y el almacenamiento cifrado de documentos.", ru, uk, kk, es);
        phrase("Deleted %d transactions", "Удалено операций: %d", "Видалено операцій: %d", "%d транзакция жойылды", "Se eliminaron %d transacciones", ru, uk, kk, es);
        phrase("The selected transactions could not be deleted.", "Не удалось удалить выбранные операции.", "Не вдалося видалити вибрані операції.", "Таңдалған транзакцияларды жою мүмкін болмады.", "No se pudieron eliminar las transacciones seleccionadas.", ru, uk, kk, es);
        phrase("Only checked fields will be replaced. Attachments and original import fingerprints will remain unchanged.", "Будут заменены только отмеченные поля. Вложения и исходные идентификаторы импорта останутся без изменений.", "Буде замінено лише позначені поля. Вкладення та вихідні ідентифікатори імпорту залишаться без змін.", "Тек белгіленген өрістер ауыстырылады. Тіркемелер мен бастапқы импорт белгілері өзгермейді.", "Solo se reemplazarán los campos marcados. Los adjuntos y las huellas de importación originales no cambiarán.", ru, uk, kk, es);
        phrase("Replace merchant or income source", "Заменить продавца или источник дохода", "Замінити продавця або джерело доходу", "Сатушыны немесе кіріс көзін ауыстыру", "Reemplazar comercio o fuente de ingresos", ru, uk, kk, es);
        phrase("New merchant or income source", "Новый продавец или источник дохода", "Новий продавець або джерело доходу", "Жаңа сатушы немесе кіріс көзі", "Nuevo comercio o fuente de ingresos", ru, uk, kk, es);
        phrase("Replace amount", "Заменить сумму", "Замінити суму", "Соманы ауыстыру", "Reemplazar importe", ru, uk, kk, es);
        phrase("Replace transaction type and category", "Заменить тип и категорию операции", "Замінити тип і категорію операції", "Транзакция түрі мен санатын ауыстыру", "Reemplazar tipo y categoría", ru, uk, kk, es);
        phrase("Replace date", "Заменить дату", "Замінити дату", "Күнді ауыстыру", "Reemplazar fecha", ru, uk, kk, es);
        phrase("Replace or clear note", "Заменить или очистить заметку", "Замінити або очистити нотатку", "Жазбаны ауыстыру немесе тазалау", "Reemplazar o borrar nota", ru, uk, kk, es);
        phrase("New note; leave blank to clear", "Новая заметка; оставьте пустой для удаления", "Нова нотатка; залиште порожньою для видалення", "Жаңа жазба; тазалау үшін бос қалдырыңыз", "Nueva nota; déjala en blanco para borrarla", ru, uk, kk, es);
        phrase("Replace or clear bank account association", "Заменить или удалить связь с банковским счётом", "Замінити або видалити зв’язок із банківським рахунком", "Банк шотымен байланысты ауыстыру немесе тазалау", "Reemplazar o borrar asociación bancaria", ru, uk, kk, es);
        phrase("Enter both values, or leave both blank to remove the bank account association.", "Введите оба значения или оставьте оба пустыми, чтобы удалить связь с банковским счётом.", "Введіть обидва значення або залиште обидва порожніми, щоб видалити зв’язок із банківським рахунком.", "Екі мәнді де енгізіңіз немесе банк шотымен байланысты жою үшін екеуін де бос қалдырыңыз.", "Introduce ambos valores o deja ambos en blanco para quitar la asociación bancaria.", ru, uk, kk, es);
        phrase("Replace AI budget and report treatment", "Заменить порядок учёта в бюджете ИИ и отчётах", "Замінити порядок обліку в бюджеті ШІ та звітах", "ЖИ бюджеті мен есептерінде есепке алуды ауыстыру", "Reemplazar tratamiento en presupuesto e informes de IA", ru, uk, kk, es);
        phrase("Include in AI budget and reports", "Включать в бюджет ИИ и отчёты", "Включати до бюджету ШІ та звітів", "ЖИ бюджеті мен есептеріне қосу", "Incluir en presupuesto e informes de IA", ru, uk, kk, es);
        phrase("Exclude from AI budget and reports", "Исключать из бюджета ИИ и отчётов", "Виключати з бюджету ШІ та звітів", "ЖИ бюджеті мен есептерінен алып тастау", "Excluir del presupuesto e informes de IA", ru, uk, kk, es);
        phrase("Apply replacements", "Применить замены", "Застосувати заміни", "Ауыстыруларды қолдану", "Aplicar reemplazos", ru, uk, kk, es);
        phrase("Choose at least one field to replace.", "Выберите хотя бы одно поле для замены.", "Виберіть принаймні одне поле для заміни.", "Ауыстыру үшін кемінде бір өрісті таңдаңыз.", "Elige al menos un campo para reemplazar.", ru, uk, kk, es);
        phrase("Updating selected transactions…", "Обновление выбранных операций…", "Оновлення вибраних операцій…", "Таңдалған транзакциялар жаңартылуда…", "Actualizando transacciones seleccionadas…", ru, uk, kk, es);
        phrase("Applying only the checked replacements to local transaction history.", "К локальной истории операций применяются только отмеченные замены.", "До локальної історії операцій застосовуються лише позначені заміни.", "Жергілікті транзакциялар тарихына тек белгіленген ауыстырулар қолданылуда.", "Aplicando solo los reemplazos marcados al historial local.", ru, uk, kk, es);
        phrase("Updated %d transactions", "Обновлено операций: %d", "Оновлено операцій: %d", "%d транзакция жаңартылды", "Se actualizaron %d transacciones", ru, uk, kk, es);
        phrase("The selected transactions could not be updated.", "Не удалось обновить выбранные операции.", "Не вдалося оновити вибрані операції.", "Таңдалған транзакцияларды жаңарту мүмкін болмады.", "No se pudieron actualizar las transacciones seleccionadas.", ru, uk, kk, es);
        phrase("Please wait while the local transaction task finishes.", "Подождите, пока завершится локальная обработка операций.", "Зачекайте, поки завершиться локальна обробка операцій.", "Транзакцияларды жергілікті өңдеу аяқталғанша күтіңіз.", "Espera mientras finaliza la tarea local de transacciones.", ru, uk, kk, es);

        phrase("Add transaction", "Добавить операцию", "Додати операцію", "Транзакция қосу", "Añadir transacción", ru, uk, kk, es);
        phrase("Transaction type", "Тип операции", "Тип операції", "Транзакция түрі", "Tipo de transacción", ru, uk, kk, es);
        phrase("Merchant or employer", "Продавец или работодатель", "Продавець або роботодавець", "Сатушы немесе жұмыс беруші", "Comercio o empleador", ru, uk, kk, es);
        phrase("Note (optional)", "Заметка (необязательно)", "Нотатка (необов’язково)", "Жазба (міндетті емес)", "Nota (opcional)", ru, uk, kk, es);
        phrase("Bank account association (optional)", "Связь с банковским счётом (необязательно)", "Зв’язок із банківським рахунком (необов’язково)", "Банк шотымен байланыс (міндетті емес)", "Asociación bancaria (opcional)", ru, uk, kk, es);
        phrase("Enter both values, or leave both blank for no bank account association.", "Введите оба значения или оставьте оба пустыми, чтобы не связывать операцию с банковским счётом.", "Введіть обидва значення або залиште обидва порожніми, щоб не пов’язувати операцію з банківським рахунком.", "Екі мәнді де енгізіңіз немесе банк шотымен байланыстырмау үшін екеуін де бос қалдырыңыз.", "Introduce ambos valores o deja ambos en blanco para no asociar una cuenta bancaria.", ru, uk, kk, es);
        phrase("No receipt or paystub attached", "Чек или расчётный лист не прикреплён", "Чек або розрахунковий лист не прикріплено", "Түбіртек немесе жалақы парағы тіркелмеген", "No hay recibo ni nómina adjuntos", ru, uk, kk, es);
        phrase("No financial document attached", "Финансовый документ не прикреплён", "Фінансовий документ не прикріплено", "Қаржылық құжат тіркелмеген", "No hay ningún documento financiero adjunto", ru, uk, kk, es);
        phrase("Receipt/paystub attached securely", "Чек/расчётный лист надёжно прикреплён", "Чек/розрахунковий лист безпечно прикріплено", "Түбіртек/жалақы парағы қауіпсіз тіркелді", "Recibo/nómina adjunto de forma segura", ru, uk, kk, es);
        phrase("Bank statement attached securely", "Банковская выписка надёжно прикреплена", "Банківську виписку безпечно прикріплено", "Банк көшірмесі қауіпсіз тіркелді", "Extracto bancario adjunto de forma segura", ru, uk, kk, es);
        phrase("text read locally", "текст распознан локально", "текст розпізнано локально", "мәтін жергілікті оқылды", "texto leído localmente", ru, uk, kk, es);
        phrase("Scan or upload document", "Сканировать или загрузить документ", "Сканувати або завантажити документ", "Құжатты сканерлеу немесе жүктеу", "Escanear o subir documento", ru, uk, kk, es);
        phrase("Replace or remove document", "Заменить или удалить документ", "Замінити або видалити документ", "Құжатты ауыстыру немесе жою", "Reemplazar o quitar documento", ru, uk, kk, es);
        phrase("Save transaction", "Сохранить операцию", "Зберегти операцію", "Транзакцияны сақтау", "Guardar transacción", ru, uk, kk, es);
        phrase("Enter an amount greater than zero", "Введите сумму больше нуля", "Введіть суму, більшу за нуль", "Нөлден үлкен соманы енгізіңіз", "Introduce un importe mayor que cero", ru, uk, kk, es);
        phrase("Enter the employer or income source", "Укажите работодателя или источник дохода", "Укажіть роботодавця або джерело доходу", "Жұмыс берушіні немесе кіріс көзін енгізіңіз", "Introduce el empleador o la fuente de ingresos", ru, uk, kk, es);
        phrase("Enter the merchant", "Укажите продавца", "Укажіть продавця", "Сатушыны енгізіңіз", "Introduce el comercio", ru, uk, kk, es);
        phrase("Transaction saved", "Операция сохранена", "Операцію збережено", "Транзакция сақталды", "Transacción guardada", ru, uk, kk, es);

        phrase("Add to My Budget", "Добавить в «Мой бюджет»", "Додати до «Мого бюджету»", "«Менің бюджетіме» қосу", "Añadir a Mi presupuesto", ru, uk, kk, es);
        phrase("Add document or statement", "Добавить документ или выписку", "Додати документ або виписку", "Құжат немесе көшірме қосу", "Añadir documento o extracto", ru, uk, kk, es);
        phrase("Take a receipt/paystub photo", "Сфотографировать чек/расчётный лист", "Сфотографувати чек/розрахунковий лист", "Түбіртекті/жалақы парағын суретке түсіру", "Hacer foto de recibo/nómina", ru, uk, kk, es);
        phrase("Upload image or PDF", "Загрузить изображение или PDF", "Завантажити зображення або PDF", "Кескінді немесе PDF жүктеу", "Subir imagen o PDF", ru, uk, kk, es);
        phrase("Upload receipt/paystub image or PDF", "Загрузить изображение или PDF чека/расчётного листа", "Завантажити зображення або PDF чека/розрахункового листа", "Түбіртек/жалақы парағы кескінін немесе PDF файлын жүктеу", "Subir imagen o PDF de recibo/nómina", ru, uk, kk, es);
        phrase("Upload bank statement", "Загрузить банковскую выписку", "Завантажити банківську виписку", "Банк көшірмесін жүктеу", "Subir extracto bancario", ru, uk, kk, es);
        phrase("Upload receipt/paystub photos or PDFs", "Загрузить фото или PDF чеков/расчётных листов", "Завантажити фото або PDF чеків/розрахункових листів", "Түбіртектердің/жалақы парақтарының фотоларын немесе PDF файлдарын жүктеу", "Subir fotos o PDF de recibos/nóminas", ru, uk, kk, es);
        phrase("Upload bank statements", "Загрузить банковские выписки", "Завантажити банківські виписки", "Банк көшірмелерін жүктеу", "Subir extractos bancarios", ru, uk, kk, es);
        phrase("Selected %d files", "Выбрано файлов: %d", "Вибрано файлів: %d", "%d файл таңдалды", "%d archivos seleccionados", ru, uk, kk, es);
        phrase("%1$s (%2$d of %3$d)", "%1$s (%2$d из %3$d)", "%1$s (%2$d із %3$d)", "%1$s (%2$d/%3$d)", "%1$s (%2$d de %3$d)", ru, uk, kk, es);
        phrase("Batch complete • %1$d saved • %2$d skipped • %3$d failed", "Пакет завершён • сохранено: %1$d • пропущено: %2$d • ошибок: %3$d", "Пакет завершено • збережено: %1$d • пропущено: %2$d • помилок: %3$d", "Топтама аяқталды • сақталды: %1$d • өткізілді: %2$d • қате: %3$d", "Lote completado • %1$d guardados • %2$d omitidos • %3$d fallidos", ru, uk, kk, es);
        phrase("Statements complete • %1$d imported • %2$d transactions • %3$d skipped • %4$d failed", "Выписки обработаны • импортировано: %1$d • операций: %2$d • пропущено: %3$d • ошибок: %4$d", "Виписки оброблено • імпортовано: %1$d • операцій: %2$d • пропущено: %3$d • помилок: %4$d", "Көшірмелер өңделді • импортталды: %1$d • транзакция: %2$d • өткізілді: %3$d • қате: %4$d", "Extractos completados • %1$d importados • %2$d transacciones • %3$d omitidos • %4$d fallidos", ru, uk, kk, es);
        phrase("Take a photo", "Сфотографировать", "Сфотографувати", "Суретке түсіру", "Hacer una foto", ru, uk, kk, es);
        phrase("Remove attachment", "Удалить вложение", "Видалити вкладення", "Тіркемені жою", "Quitar adjunto", ru, uk, kk, es);
        phrase("Receipt or paystub", "Чек или расчётный лист", "Чек або розрахунковий лист", "Түбіртек немесе жалақы парағы", "Recibo o nómina", ru, uk, kk, es);
        phrase("No document picker is available.", "Приложение для выбора документов недоступно.", "Застосунок для вибору документів недоступний.", "Құжат таңдау қолданбасы қолжетімсіз.", "No hay un selector de documentos disponible.", ru, uk, kk, es);
        phrase("Finish or skip the current upload before leaving this screen.", "Завершите или пропустите текущую загрузку перед выходом с этого экрана.", "Завершіть або пропустіть поточне завантаження, перш ніж залишити цей екран.", "Бұл экраннан шықпас бұрын ағымдағы жүктеуді аяқтаңыз немесе өткізіп жіберіңіз.", "Finaliza u omite la carga actual antes de salir de esta pantalla.", ru, uk, kk, es);
        phrase("Please wait while the local document task finishes.", "Подождите, пока завершится локальная обработка документа.", "Зачекайте, доки завершиться локальна обробка документа.", "Құжатты жергілікті өңдеу аяқталғанша күтіңіз.", "Espera a que finalice el procesamiento local del documento.", ru, uk, kk, es);
        phrase("A camera app is not available.", "Приложение камеры недоступно.", "Застосунок камери недоступний.", "Камера қолданбасы қолжетімсіз.", "No hay una aplicación de cámara disponible.", ru, uk, kk, es);
        phrase("Securing and reading the document…", "Защита и чтение документа…", "Захист і читання документа…", "Құжат қорғалып, оқылуда…", "Protegiendo y leyendo el documento…", ru, uk, kk, es);
        phrase("OCR runs locally; financial documents are not uploaded.", "Распознавание выполняется локально; финансовые документы не загружаются.", "Розпізнавання виконується локально; фінансові документи не завантажуються.", "Мәтінді тану жергілікті орындалады; қаржылық құжаттар жүктелмейді.", "El OCR funciona localmente; los documentos financieros no se suben.", ru, uk, kk, es);
        phrase("Document read locally • %d%% extraction confidence", "Документ распознан локально • точность извлечения %d%%", "Документ розпізнано локально • точність вилучення %d%%", "Құжат жергілікті оқылды • шығару сенімділігі %d%%", "Documento leído localmente • %d%% de confianza", ru, uk, kk, es);
        phrase("The document is attached, but its text could not be read. Enter the details manually.", "Документ прикреплён, но текст распознать не удалось. Введите данные вручную.", "Документ прикріплено, але текст розпізнати не вдалося. Введіть дані вручну.", "Құжат тіркелді, бірақ мәтін оқылмады. Мәліметтерді қолмен енгізіңіз.", "El documento está adjunto, pero no se pudo leer el texto. Introduce los datos manualmente.", ru, uk, kk, es);
        phrase("Unable to import that document.", "Не удалось импортировать документ.", "Не вдалося імпортувати документ.", "Құжатты импорттау мүмкін болмады.", "No se pudo importar ese documento.", ru, uk, kk, es);
        phrase("Securing and reading the bank statement…", "Защита и чтение банковской выписки…", "Захист і читання банківської виписки…", "Банк көшірмесі қорғалып, оқылуда…", "Protegiendo y leyendo el extracto bancario…", ru, uk, kk, es);
        phrase("Up to 12 PDF pages are read locally. Nothing is imported until you review it.", "До 12 страниц PDF распознаются локально. До вашей проверки ничего не импортируется.", "До 12 сторінок PDF розпізнаються локально. До вашої перевірки нічого не імпортується.", "PDF файлының 12 бетіне дейін жергілікті оқылады. Сіз тексермейінше ештеңе импортталмайды.", "Se leen localmente hasta 12 páginas del PDF. No se importa nada hasta que lo revises.", ru, uk, kk, es);
        phrase("Unable to import that bank statement.", "Не удалось импортировать банковскую выписку.", "Не вдалося імпортувати банківську виписку.", "Банк көшірмесін импорттау мүмкін болмады.", "No se pudo importar ese extracto bancario.", ru, uk, kk, es);
        phrase("Review bank statement", "Проверка банковской выписки", "Перевірка банківської виписки", "Банк көшірмесін тексеру", "Revisar extracto bancario", ru, uk, kk, es);
        phrase("Check every amount, type, category, and date. Only selected rows will be imported.", "Проверьте каждую сумму, тип, категорию и дату. Будут импортированы только выбранные строки.", "Перевірте кожну суму, тип, категорію та дату. Будуть імпортовані лише вибрані рядки.", "Әр соманы, түрді, санатты және күнді тексеріңіз. Тек таңдалған жолдар импортталады.", "Comprueba cada importe, tipo, categoría y fecha. Solo se importarán las filas seleccionadas.", ru, uk, kk, es);
        phrase("Some summary or unreadable rows may have been skipped. Compare this list with the statement.", "Некоторые итоговые или неразборчивые строки могли быть пропущены. Сверьте список с выпиской.", "Деякі підсумкові або нерозбірливі рядки могли бути пропущені. Звірте список із випискою.", "Кейбір қорытынды немесе оқылмайтын жолдар өткізілуі мүмкін. Тізімді көшірмемен салыстырыңыз.", "Es posible que se hayan omitido filas de resumen o ilegibles. Compara esta lista con el extracto.", ru, uk, kk, es);
        phrase("No transaction rows recognized", "Строки операций не распознаны", "Рядки операцій не розпізнано", "Транзакция жолдары танылмады", "No se reconocieron filas de transacciones", ru, uk, kk, es);
        phrase("Try a clearer image or PDF, or attach this statement to one transaction and enter its details manually.", "Попробуйте более чёткое изображение или PDF либо прикрепите выписку к одной операции и введите данные вручную.", "Спробуйте чіткіше зображення чи PDF або прикріпіть виписку до однієї операції та введіть дані вручну.", "Анығырақ кескінді не PDF файлын қолданып көріңіз немесе көшірмені бір транзакцияға тіркеп, мәліметтерін қолмен енгізіңіз.", "Prueba con una imagen o PDF más claro, o adjunta este extracto a una transacción e introduce sus datos manualmente.", ru, uk, kk, es);
        phrase("Try another statement", "Выбрать другую выписку", "Вибрати іншу виписку", "Басқа көшірмені таңдау", "Probar otro extracto", ru, uk, kk, es);
        phrase("Skip this statement", "Пропустить эту выписку", "Пропустити цю виписку", "Бұл көшірмені өткізіп жіберу", "Omitir este extracto", ru, uk, kk, es);
        phrase("Skip this upload", "Пропустить эту загрузку", "Пропустити це завантаження", "Бұл жүктеуді өткізіп жіберу", "Omitir esta carga", ru, uk, kk, es);
        phrase("Cancel remaining uploads", "Отменить оставшиеся загрузки", "Скасувати решту завантажень", "Қалған жүктеулерден бас тарту", "Cancelar las cargas restantes", ru, uk, kk, es);
        phrase("Enter one transaction manually", "Ввести одну операцию вручную", "Ввести одну операцію вручну", "Бір транзакцияны қолмен енгізу", "Introducir una transacción manualmente", ru, uk, kk, es);
        phrase("Proposed transactions", "Предлагаемые операции", "Запропоновані операції", "Ұсынылған транзакциялар", "Transacciones propuestas", ru, uk, kk, es);
        phrase("These reviewed income and expense rows will feed the local AI budget and reports.", "Проверенные строки доходов и расходов будут использоваться локальным ИИ для бюджета и отчётов.", "Перевірені рядки доходів і витрат використовуватимуться локальним ШІ для бюджету та звітів.", "Тексерілген кіріс пен шығыс жолдарын жергілікті ЖИ бюджет пен есептерде пайдаланады.", "Estas filas revisadas de ingresos y gastos alimentarán el presupuesto y los informes de la IA local.", ru, uk, kk, es);
        phrase("%d%% confidence", "надёжность %d%%", "надійність %d%%", "сенімділік %d%%", "%d%% de confianza", ru, uk, kk, es);
        phrase("Edit before import", "Изменить перед импортом", "Змінити перед імпортом", "Импорт алдында өңдеу", "Editar antes de importar", ru, uk, kk, es);
        phrase("Import selected transactions", "Импортировать выбранные операции", "Імпортувати вибрані операції", "Таңдалған транзакцияларды импорттау", "Importar transacciones seleccionadas", ru, uk, kk, es);
        phrase("%1$d selected • Income %2$s • Expenses %3$s", "Выбрано: %1$d • Доходы: %2$s • Расходы: %3$s", "Вибрано: %1$d • Доходи: %2$s • Витрати: %3$s", "Таңдалды: %1$d • Кіріс: %2$s • Шығыс: %3$s", "%1$d seleccionadas • Ingresos: %2$s • Gastos: %3$s", ru, uk, kk, es);
        phrase("Merchant or income source", "Продавец или источник дохода", "Продавець або джерело доходу", "Сатушы немесе кіріс көзі", "Comercio o fuente de ingresos", ru, uk, kk, es);
        phrase("Edit statement transaction", "Изменить операцию из выписки", "Змінити операцію з виписки", "Көшірмедегі транзакцияны өңдеу", "Editar transacción del extracto", ru, uk, kk, es);
        phrase("Enter the merchant or income source", "Укажите продавца или источник дохода", "Укажіть продавця або джерело доходу", "Сатушыны немесе кіріс көзін енгізіңіз", "Introduce el comercio o la fuente de ingresos", ru, uk, kk, es);
        phrase("Select at least one transaction to import.", "Выберите хотя бы одну операцию для импорта.", "Виберіть принаймні одну операцію для імпорту.", "Импорттау үшін кемінде бір транзакцияны таңдаңыз.", "Selecciona al menos una transacción para importar.", ru, uk, kk, es);
        phrase("Importing reviewed transactions…", "Импорт проверенных операций…", "Імпорт перевірених операцій…", "Тексерілген транзакциялар импортталуда…", "Importando transacciones revisadas…", ru, uk, kk, es);
        phrase("Saving income, expenses, and the encrypted source statement locally.", "Доходы, расходы и зашифрованная исходная выписка сохраняются локально.", "Доходи, витрати та зашифрована вихідна виписка зберігаються локально.", "Кіріс, шығыс және шифрланған бастапқы көшірме жергілікті сақталуда.", "Guardando localmente los ingresos, gastos y el extracto original cifrado.", ru, uk, kk, es);
        phrase("Imported %d bank-statement transactions", "Импортировано операций из выписки: %d", "Імпортовано операцій із виписки: %d", "Көшірмеден %d транзакция импортталды", "Se importaron %d transacciones del extracto bancario", ru, uk, kk, es);
        phrase("The reviewed transactions could not be imported.", "Не удалось импортировать проверенные операции.", "Не вдалося імпортувати перевірені операції.", "Тексерілген транзакцияларды импорттау мүмкін болмады.", "No se pudieron importar las transacciones revisadas.", ru, uk, kk, es);
        phrase("Review upload %1$d of %2$d. Save or skip this transaction to continue.", "Проверка загрузки %1$d из %2$d. Сохраните или пропустите эту операцию, чтобы продолжить.", "Перевірка завантаження %1$d із %2$d. Збережіть або пропустіть цю операцію, щоб продовжити.", "%2$d жүктеудің %1$d-жүктеуін тексеру. Жалғастыру үшін осы транзакцияны сақтаңыз немесе өткізіп жіберіңіз.", "Revisión de la carga %1$d de %2$d. Guarda u omite esta transacción para continuar.", ru, uk, kk, es);
        phrase("Save or skip this transaction to continue with the remaining statements.", "Сохраните или пропустите эту операцию, чтобы перейти к оставшимся выпискам.", "Збережіть або пропустіть цю операцію, щоб перейти до решти виписок.", "Қалған көшірмелерге өту үшін осы транзакцияны сақтаңыз немесе өткізіп жіберіңіз.", "Guarda u omite esta transacción para continuar con los extractos restantes.", ru, uk, kk, es);
        phrase("Please wait while the local statement task finishes.", "Подождите, пока завершится локальная обработка выписки.", "Зачекайте, поки завершиться локальна обробка виписки.", "Көшірмені жергілікті өңдеу аяқталғанша күтіңіз.", "Espera mientras finaliza la tarea local del extracto.", ru, uk, kk, es);
        phrase("Statement bank account", "Счёт банковской выписки", "Рахунок банківської виписки", "Банк көшірмесінің шоты", "Cuenta del extracto bancario", ru, uk, kk, es);
        phrase("Bank or institution", "Банк или финансовое учреждение", "Банк або фінансова установа", "Банк немесе қаржы мекемесі", "Banco o institución", ru, uk, kk, es);
        phrase("Bank account", "Банковский счёт", "Банківський рахунок", "Банк шоты", "Cuenta bancaria", ru, uk, kk, es);
        phrase("Recognized statement period", "Распознанный период выписки", "Розпізнаний період виписки", "Танылған көшірме кезеңі", "Periodo reconocido del extracto", ru, uk, kk, es);
        phrase("Edit bank account identity", "Изменить данные банковского счёта", "Змінити дані банківського рахунку", "Банк шотының деректерін өзгерту", "Editar identidad de la cuenta bancaria", ru, uk, kk, es);
        phrase("Account identity keeps histories from different bank accounts separate and prevents duplicate imports.", "Данные счёта разделяют историю разных банковских счетов и предотвращают повторный импорт.", "Дані рахунку розділяють історію різних банківських рахунків і запобігають повторному імпорту.", "Шот деректері әртүрлі банк шоттарының тарихын бөлек сақтап, қайталама импортты болдырмайды.", "La identidad de la cuenta mantiene separados los historiales de distintas cuentas y evita importaciones duplicadas.", ru, uk, kk, es);
        phrase("Account name or last four digits", "Название счёта или последние четыре цифры", "Назва рахунку або останні чотири цифри", "Шот атауы немесе соңғы төрт сан", "Nombre de la cuenta o últimos cuatro dígitos", ru, uk, kk, es);
        phrase("Example: Checking ••••1234", "Пример: Текущий ••••1234", "Приклад: Поточний ••••1234", "Мысал: Ағымдағы ••••1234", "Ejemplo: Corriente ••••1234", ru, uk, kk, es);
        phrase("Enter the bank or institution", "Укажите банк или финансовое учреждение", "Укажіть банк або фінансову установу", "Банкті немесе қаржы мекемесін енгізіңіз", "Introduce el banco o la institución", ru, uk, kk, es);
        phrase("Enter an account name", "Укажите название счёта", "Укажіть назву рахунку", "Шот атауын енгізіңіз", "Introduce un nombre de cuenta", ru, uk, kk, es);
        phrase("Already in history", "Уже есть в истории", "Уже є в історії", "Тарихта бар", "Ya está en el historial", ru, uk, kk, es);
        phrase("%d duplicates skipped", "Пропущено дубликатов: %d", "Пропущено дублікатів: %d", "%d қайталама жазба өткізілді", "%d duplicados omitidos", ru, uk, kk, es);
        phrase("All recognized transactions are already in history.", "Все распознанные операции уже есть в истории.", "Усі розпізнані операції вже є в історії.", "Барлық танылған транзакция тарихта бар.", "Todas las transacciones reconocidas ya están en el historial.", ru, uk, kk, es);
        phrase("Imported %1$d transactions • %2$d duplicates skipped", "Импортировано: %1$d • пропущено дубликатов: %2$d", "Імпортовано: %1$d • пропущено дублікатів: %2$d", "Импортталды: %1$d • қайталама жазба өткізілді: %2$d", "Se importaron %1$d transacciones • %2$d duplicados omitidos", ru, uk, kk, es);
        phrase("Exclude from AI budget and reports (transfer or adjustment)", "Исключить из бюджета ИИ и отчётов (перевод или корректировка)", "Виключити з бюджету ШІ та звітів (переказ або коригування)", "ЖИ бюджеті мен есептерінен алып тастау (аударым немесе түзету)", "Excluir del presupuesto de IA y los informes (transferencia o ajuste)", ru, uk, kk, es);
        phrase("Excluded from budget", "Исключено из бюджета", "Виключено з бюджету", "Бюджеттен алып тасталды", "Excluido del presupuesto", ru, uk, kk, es);
        phrase("AI budget and reports", "Бюджет ИИ и отчёты", "Бюджет ШІ та звіти", "ЖИ бюджеті және есептер", "Presupuesto de IA e informes", ru, uk, kk, es);
        phrase("Excluded as a transfer or adjustment", "Исключено как перевод или корректировка", "Виключено як переказ або коригування", "Аударым немесе түзету ретінде алып тасталды", "Excluido como transferencia o ajuste", ru, uk, kk, es);
        phrase("Included", "Включено", "Включено", "Қосылған", "Incluido", ru, uk, kk, es);
        phrase("Combined history • %1$d bank accounts • %2$d transactions", "Объединённая история • банковских счетов: %1$d • операций: %2$d", "Об’єднана історія • банківських рахунків: %1$d • операцій: %2$d", "Біріктірілген тарих • банк шоты: %1$d • транзакция: %2$d", "Historial combinado • %1$d cuentas bancarias • %2$d transacciones", ru, uk, kk, es);
        phrase("Imported account", "Импортированный счёт", "Імпортований рахунок", "Импортталған шот", "Cuenta importada", ru, uk, kk, es);
        phrase("All bank accounts", "Все банковские счета", "Усі банківські рахунки", "Барлық банк шоттары", "Todas las cuentas bancarias", ru, uk, kk, es);

        phrase("Weekly", "За неделю", "За тиждень", "Апталық", "Semanal", ru, uk, kk, es);
        phrase("Monthly", "За месяц", "За місяць", "Айлық", "Mensual", ru, uk, kk, es);
        phrase("Weekly report", "Недельный отчёт", "Тижневий звіт", "Апталық есеп", "Informe semanal", ru, uk, kk, es);
        phrase("Monthly report", "Месячный отчёт", "Місячний звіт", "Айлық есеп", "Informe mensual", ru, uk, kk, es);
        phrase("Savings rate", "Доля сбережений", "Частка заощаджень", "Жинақ үлесі", "Tasa de ahorro", ru, uk, kk, es);
        phrase("Spending vs prior period", "Расходы к прошлому периоду", "Витрати до попереднього періоду", "Алдыңғы кезеңмен салыстырғандағы шығыс", "Gasto frente al periodo anterior", ru, uk, kk, es);
        phrase("Where the money went", "Распределение расходов", "Куди пішли гроші", "Ақша қайда жұмсалды", "En qué se gastó el dinero", ru, uk, kk, es);
        phrase("No expenses were recorded during this period.", "За этот период расходов не зарегистрировано.", "За цей період витрат не зафіксовано.", "Бұл кезеңде шығыстар тіркелмеді.", "No se registraron gastos durante este periodo.", ru, uk, kk, es);
        phrase("Agent observations", "Наблюдения помощника", "Спостереження помічника", "Көмекші бақылаулары", "Observaciones del agente", ru, uk, kk, es);
        phrase("Add more transactions to receive comparisons and spending observations.", "Добавьте больше операций, чтобы получать сравнения и наблюдения о расходах.", "Додайте більше операцій, щоб отримувати порівняння та спостереження за витратами.", "Салыстырулар мен шығыс бақылауларын алу үшін көбірек транзакция қосыңыз.", "Añade más transacciones para recibir comparaciones y observaciones de gasto.", ru, uk, kk, es);
        phrase("Review: %s", "Проверьте: %s", "Перевірте: %s", "Тексеріңіз: %s", "Revisar: %s", ru, uk, kk, es);
        phrase("Learned monthly plan", "Рассчитанный месячный план", "Розрахований місячний план", "Үйренген айлық жоспар", "Plan mensual aprendido", ru, uk, kk, es);
        phrase("The plan will appear after transactions are added.", "План появится после добавления операций.", "План з’явиться після додавання операцій.", "Транзакциялар қосылғаннан кейін жоспар пайда болады.", "El plan aparecerá después de añadir transacciones.", ru, uk, kk, es);
        phrase("Expected income", "Ожидаемый доход", "Очікуваний дохід", "Күтілетін кіріс", "Ingresos previstos", ru, uk, kk, es);
        phrase("Category allocation", "Распределение по категориям", "Розподіл за категоріями", "Санаттар бойынша бөлу", "Asignación por categoría", ru, uk, kk, es);
        phrase("Savings target", "Цель сбережений", "Ціль заощаджень", "Жинақ мақсаты", "Objetivo de ahorro", ru, uk, kk, es);
        phrase("Confidence", "Надёжность", "Надійність", "Сенімділік", "Confianza", ru, uk, kk, es);
        phrase("Bank accounts used", "Использовано банковских счетов", "Використано банківських рахунків", "Пайдаланылған банк шоттары", "Cuentas bancarias utilizadas", ru, uk, kk, es);
        phrase("Statement transactions used", "Использовано операций из выписок", "Використано операцій із виписок", "Көшірмеден пайдаланылған транзакциялар", "Transacciones de extractos utilizadas", ru, uk, kk, es);
        phrase("Transfers or adjustments excluded", "Исключено переводов или корректировок", "Виключено переказів або коригувань", "Алып тасталған аударымдар немесе түзетулер", "Transferencias o ajustes excluidos", ru, uk, kk, es);
        phrase("Bank accounts learned", "Изучено банковских счетов", "Вивчено банківських рахунків", "Үйренілген банк шоттары", "Cuentas bancarias aprendidas", ru, uk, kk, es);
        phrase("The agent combined transaction history from %d bank accounts.", "Помощник объединил историю операций из %d банковских счетов.", "Помічник об’єднав історію операцій із %d банківських рахунків.", "Көмекші %d банк шотының транзакция тарихын біріктірді.", "El agente combinó el historial de transacciones de %d cuentas bancarias.", ru, uk, kk, es);
        phrase("%d internal-transfer or excluded entries were left out of income and expense calculations.", "%d внутренних переводов или исключённых записей не учитывались при расчёте доходов и расходов.", "%d внутрішніх переказів або виключених записів не враховувалися в розрахунку доходів і витрат.", "%d ішкі аударым немесе алып тасталған жазба кіріс пен шығыс есебіне қосылмады.", "%d transferencias internas o entradas excluidas no se contaron en los cálculos de ingresos y gastos.", ru, uk, kk, es);
        phrase("%d duplicate statement entries were ignored.", "Проигнорировано дубликатов из выписок: %d.", "Проігноровано дублікатів із виписок: %d.", "Көшірмедегі %d қайталама жазба еленбеді.", "Se ignoraron %d entradas duplicadas de extractos.", ru, uk, kk, es);
        phrase("This report combines activity from %d bank accounts.", "Этот отчёт объединяет операции из %d банковских счетов.", "Цей звіт об’єднує операції з %d банківських рахунків.", "Бұл есеп %d банк шотының әрекетін біріктіреді.", "Este informe combina la actividad de %d cuentas bancarias.", ru, uk, kk, es);
        phrase("%d internal-transfer or excluded entries were not counted as income or expenses.", "%d внутренних переводов или исключённых записей не были учтены как доходы или расходы.", "%d внутрішніх переказів або виключених записів не були враховані як доходи чи витрати.", "%d ішкі аударым немесе алып тасталған жазба кіріс не шығыс ретінде есептелмеді.", "%d transferencias internas o entradas excluidas no se contaron como ingresos ni gastos.", ru, uk, kk, es);
        phrase("Create and share PDF report", "Создать и отправить PDF-отчёт", "Створити й надіслати PDF-звіт", "PDF есебін жасау және бөлісу", "Crear y compartir informe PDF", ru, uk, kk, es);
        phrase("Reports and learned budgets are estimates based only on records in this app. Review scanned amounts and categories for accuracy.", "Отчёты и рассчитанные бюджеты — это оценки только по данным приложения. Проверяйте распознанные суммы и категории.", "Звіти й розраховані бюджети є оцінками лише за даними застосунку. Перевіряйте розпізнані суми та категорії.", "Есептер мен үйренген бюджеттер тек осы қолданбадағы жазбаларға негізделген болжамдар. Сканерленген сомалар мен санаттарды тексеріңіз.", "Los informes y presupuestos aprendidos son estimaciones basadas solo en los registros de la aplicación. Revisa los importes y categorías escaneados.", ru, uk, kk, es);
        phrase("Creating your report…", "Создание отчёта…", "Створення звіту…", "Есеп жасалуда…", "Creando el informe…", ru, uk, kk, es);
        phrase("The PDF is generated entirely on this device.", "PDF полностью создаётся на этом устройстве.", "PDF повністю створюється на цьому пристрої.", "PDF толығымен осы құрылғыда жасалады.", "El PDF se genera por completo en este dispositivo.", ru, uk, kk, es);
        phrase("The PDF report could not be created.", "Не удалось создать PDF-отчёт.", "Не вдалося створити PDF-звіт.", "PDF есебін жасау мүмкін болмады.", "No se pudo crear el informe PDF.", ru, uk, kk, es);
        phrase("No app is available to share this file.", "Нет приложения для отправки этого файла.", "Немає застосунку для надсилання цього файлу.", "Бұл файлды бөлісетін қолданба жоқ.", "No hay una aplicación disponible para compartir este archivo.", ru, uk, kk, es);

        phrase("Manual monthly budget", "Ручной месячный бюджет", "Ручний місячний бюджет", "Қолмен басқарылатын айлық бюджет", "Presupuesto mensual manual", ru, uk, kk, es);
        phrase("Your editable limits stay separate from the AI-suggested budget.", "Ваши редактируемые лимиты хранятся отдельно от бюджета, предложенного ИИ.", "Ваші редаговані ліміти зберігаються окремо від бюджету, запропонованого ШІ.", "Өңделетін шектеріңіз AI ұсынған бюджеттен бөлек сақталады.", "Tus límites editables se mantienen separados del presupuesto sugerido por la IA.", ru, uk, kk, es);
        phrase("Create your own income, savings, and category limits, or start from the AI suggestion.", "Создайте собственные лимиты дохода, сбережений и категорий или начните с предложения ИИ.", "Створіть власні ліміти доходу, заощаджень і категорій або почніть із пропозиції ШІ.", "Кіріс, жинақ және санат шектерін өзіңіз жасаңыз немесе AI ұсынысынан бастаңыз.", "Crea tus propios límites de ingresos, ahorro y categorías, o empieza con la sugerencia de la IA.", ru, uk, kk, es);
        phrase("Planned remainder", "Плановый остаток", "Запланований залишок", "Жоспарланған қалдық", "Resto planificado", ru, uk, kk, es);
        phrase("Manual limits and savings exceed expected income by %s.", "Ручные лимиты и сбережения превышают ожидаемый доход на %s.", "Ручні ліміти й заощадження перевищують очікуваний дохід на %s.", "Қолмен қойылған шектер мен жинақ күтілетін кірістен %s-ға асады.", "Los límites manuales y el ahorro superan los ingresos previstos en %s.", ru, uk, kk, es);
        phrase("Edit manual budget", "Изменить ручной бюджет", "Редагувати ручний бюджет", "Қолмен басқарылатын бюджетті өңдеу", "Editar presupuesto manual", ru, uk, kk, es);
        phrase("Create manual budget", "Создать ручной бюджет", "Створити ручний бюджет", "Қолмен басқарылатын бюджет жасау", "Crear presupuesto manual", ru, uk, kk, es);
        phrase("Enter monthly amounts. A blank or zero category removes that limit.", "Введите месячные суммы. Пустая или нулевая сумма удаляет лимит категории.", "Введіть місячні суми. Порожнє або нульове значення видаляє ліміт категорії.", "Айлық сомаларды енгізіңіз. Бос немесе нөл мән санат шегін жояды.", "Introduce importes mensuales. Un valor vacío o cero elimina el límite de esa categoría.", ru, uk, kk, es);
        phrase("Monthly category limits", "Месячные лимиты по категориям", "Місячні ліміти за категоріями", "Санаттардың айлық шектері", "Límites mensuales por categoría", ru, uk, kk, es);
        phrase("Use AI suggestions as a starting point", "Использовать предложения ИИ как отправную точку", "Використати пропозиції ШІ як відправну точку", "AI ұсыныстарын бастапқы нүкте ретінде пайдалану", "Usar las sugerencias de la IA como punto de partida", ru, uk, kk, es);
        phrase("Add more transaction history before using an AI starting point.", "Добавьте больше истории операций, прежде чем использовать предложение ИИ.", "Додайте більше історії операцій, перш ніж використовувати пропозицію ШІ.", "AI бастапқы жоспарын пайдалану үшін көбірек транзакция тарихын қосыңыз.", "Añade más historial de transacciones antes de usar un punto de partida de la IA.", ru, uk, kk, es);
        phrase("AI suggestions copied. Review and save your manual budget.", "Предложения ИИ скопированы. Проверьте и сохраните ручной бюджет.", "Пропозиції ШІ скопійовано. Перевірте й збережіть ручний бюджет.", "AI ұсыныстары көшірілді. Қолмен басқарылатын бюджетті тексеріп, сақтаңыз.", "Se copiaron las sugerencias de la IA. Revisa y guarda tu presupuesto manual.", ru, uk, kk, es);
        phrase("Save manual budget", "Сохранить ручной бюджет", "Зберегти ручний бюджет", "Қолмен басқарылатын бюджетті сақтау", "Guardar presupuesto manual", ru, uk, kk, es);
        phrase("Enter at least one monthly amount.", "Введите хотя бы одну месячную сумму.", "Введіть хоча б одну місячну суму.", "Кемінде бір айлық соманы енгізіңіз.", "Introduce al menos un importe mensual.", ru, uk, kk, es);
        phrase("Manual budget saved", "Ручной бюджет сохранён", "Ручний бюджет збережено", "Қолмен басқарылатын бюджет сақталды", "Presupuesto manual guardado", ru, uk, kk, es);
        phrase("Clear manual budget", "Очистить ручной бюджет", "Очистити ручний бюджет", "Қолмен басқарылатын бюджетті тазалау", "Borrar presupuesto manual", ru, uk, kk, es);
        phrase("Clear the manual budget?", "Очистить ручной бюджет?", "Очистити ручний бюджет?", "Қолмен басқарылатын бюджет тазалансын ба?", "¿Borrar el presupuesto manual?", ru, uk, kk, es);
        phrase("Your AI suggestions and transactions will not be changed.", "Предложения ИИ и операции не изменятся.", "Пропозиції ШІ та операції не зміняться.", "AI ұсыныстары мен транзакциялар өзгермейді.", "Tus sugerencias de la IA y transacciones no cambiarán.", ru, uk, kk, es);
        phrase("Clear", "Очистить", "Очистити", "Тазалау", "Borrar", ru, uk, kk, es);
        phrase("Manual budget cleared", "Ручной бюджет очищен", "Ручний бюджет очищено", "Қолмен басқарылатын бюджет тазаланды", "Presupuesto manual borrado", ru, uk, kk, es);

        phrase("Language management", "Управление языком", "Керування мовою", "Тілді басқару", "Gestión de idioma", ru, uk, kk, es);
        phrase("App language", "Язык приложения", "Мова застосунку", "Қолданба тілі", "Idioma de la aplicación", ru, uk, kk, es);
        phrase("Choose the language used throughout the app. Changes apply immediately.", "Выберите язык всего приложения. Изменения применяются сразу.", "Виберіть мову всього застосунку. Зміни застосовуються одразу.", "Қолданбаның барлық бөлігінде қолданылатын тілді таңдаңыз. Өзгерістер бірден қолданылады.", "Elige el idioma de toda la aplicación. Los cambios se aplican de inmediato.", ru, uk, kk, es);
        phrase("Transaction sorting", "Сортировка операций", "Сортування операцій", "Транзакцияларды сұрыптау", "Orden de transacciones", ru, uk, kk, es);
        phrase("Sort records by", "Сортировать записи по", "Сортувати записи за", "Жазбаларды сұрыптау", "Ordenar registros por", ru, uk, kk, es);
        phrase("Ascending order", "По возрастанию", "За зростанням", "Өсу ретімен", "Orden ascendente", ru, uk, kk, es);
        phrase("Appearance", "Оформление", "Вигляд", "Сыртқы көрініс", "Apariencia", ru, uk, kk, es);
        phrase("Background color", "Цвет фона", "Колір тла", "Фон түсі", "Color de fondo", ru, uk, kk, es);
        phrase("Upload background photo", "Загрузить фоновое фото", "Завантажити фонове фото", "Фон суретін жүктеу", "Subir foto de fondo", ru, uk, kk, es);
        phrase("Replace background photo", "Заменить фоновое фото", "Замінити фонове фото", "Фон суретін ауыстыру", "Reemplazar foto de fondo", ru, uk, kk, es);
        phrase("Remove background photo", "Удалить фоновое фото", "Видалити фонове фото", "Фон суретін жою", "Quitar foto de fondo", ru, uk, kk, es);
        phrase("Background photo opacity", "Прозрачность фонового фото", "Прозорість фонового фото", "Фон суретінің мөлдірлігі", "Opacidad de la foto de fondo", ru, uk, kk, es);
        phrase("Text color", "Цвет текста", "Колір тексту", "Мәтін түсі", "Color del texto", ru, uk, kk, es);
        phrase("Text-box color", "Цвет текстовых блоков", "Колір текстових блоків", "Мәтін өрісінің түсі", "Color de cuadros de texto", ru, uk, kk, es);
        phrase("Text-box opacity", "Прозрачность текстовых блоков", "Прозорість текстових блоків", "Мәтін өрісінің мөлдірлігі", "Opacidad de cuadros de texto", ru, uk, kk, es);
        phrase("Text size", "Размер текста", "Розмір тексту", "Мәтін өлшемі", "Tamaño del texto", ru, uk, kk, es);
        phrase("Reset appearance", "Сбросить оформление", "Скинути вигляд", "Көріністі қалпына келтіру", "Restablecer apariencia", ru, uk, kk, es);
        phrase("Avatar", "Аватар", "Аватар", "Аватар", "Avatar", ru, uk, kk, es);
        phrase("Upload avatar", "Загрузить аватар", "Завантажити аватар", "Аватар жүктеу", "Subir avatar", ru, uk, kk, es);
        phrase("Replace avatar", "Заменить аватар", "Замінити аватар", "Аватарды ауыстыру", "Reemplazar avatar", ru, uk, kk, es);
        phrase("Use default avatar", "Использовать стандартный аватар", "Використати стандартний аватар", "Әдепкі аватарды пайдалану", "Usar avatar predeterminado", ru, uk, kk, es);
        phrase("Passcode", "Код доступа", "Код доступу", "Кіру коды", "Código de acceso", ru, uk, kk, es);
        phrase("A passcode protects access to the app.", "Код доступа защищает приложение.", "Код доступу захищає застосунок.", "Кіру коды қолданбаны қорғайды.", "Un código protege el acceso a la aplicación.", ru, uk, kk, es);
        phrase("No passcode is set. Add one to protect financial records when the app opens.", "Код доступа не задан. Создайте его для защиты финансовых записей при открытии приложения.", "Код доступу не задано. Створіть його для захисту фінансових записів під час відкриття застосунку.", "Кіру коды орнатылмаған. Қолданба ашылғанда қаржылық жазбаларды қорғау үшін код қосыңыз.", "No hay ningún código configurado. Añade uno para proteger los registros financieros al abrir la aplicación.", ru, uk, kk, es);
        phrase("Change or disable passcode", "Изменить или отключить код", "Змінити або вимкнути код", "Кодты өзгерту немесе өшіру", "Cambiar o desactivar código", ru, uk, kk, es);
        phrase("Create passcode", "Создать код доступа", "Створити код доступу", "Кіру кодын жасау", "Crear código de acceso", ru, uk, kk, es);
        phrase("Lock after 30 seconds in the background", "Блокировать через 30 секунд в фоне", "Блокувати через 30 секунд у фоні", "Фонда 30 секундтан кейін құлыптау", "Bloquear tras 30 segundos en segundo plano", ru, uk, kk, es);
        phrase("Automatic lock after leaving the app", "Автоблокировка после выхода из приложения", "Автоблокування після виходу із застосунку", "Қолданбадан шыққаннан кейін автоматты құлыптау", "Bloqueo automático al salir de la aplicación", ru, uk, kk, es);
        phrase("Manual only", "Только вручную", "Лише вручну", "Тек қолмен", "Solo manual", ru, uk, kk, es);
        phrase("Immediately", "Сразу", "Одразу", "Бірден", "Inmediatamente", ru, uk, kk, es);
        phrase("After 30 seconds", "Через 30 секунд", "Через 30 секунд", "30 секундтан кейін", "Después de 30 segundos", ru, uk, kk, es);
        phrase("After 1 minute", "Через 1 минуту", "Через 1 хвилину", "1 минуттан кейін", "Después de 1 minuto", ru, uk, kk, es);
        phrase("After 5 minutes", "Через 5 минут", "Через 5 хвилин", "5 минуттан кейін", "Después de 5 minutos", ru, uk, kk, es);
        phrase("After 15 minutes", "Через 15 минут", "Через 15 хвилин", "15 минуттан кейін", "Después de 15 minutos", ru, uk, kk, es);
        phrase("After 30 minutes", "Через 30 минут", "Через 30 хвилин", "30 минуттан кейін", "Después de 30 minutos", ru, uk, kk, es);
        phrase("Manual only never auto-locks while the app is running. A passcode is still required when the app launches.", "В режиме «Только вручную» приложение не блокируется автоматически во время работы. При запуске код доступа всё равно требуется.", "У режимі «Лише вручну» застосунок не блокується автоматично під час роботи. Під час запуску код доступу все одно потрібен.", "«Тек қолмен» режимінде қолданба жұмыс істеп тұрғанда автоматты түрде құлыпталмайды. Іске қосылғанда кіру коды әлі де қажет.", "El modo Solo manual nunca bloquea automáticamente mientras la aplicación está abierta. El código sigue siendo obligatorio al iniciarla.", ru, uk, kk, es);
        phrase("Lock now", "Заблокировать сейчас", "Заблокувати зараз", "Қазір құлыптау", "Bloquear ahora", ru, uk, kk, es);
        phrase("Storage management", "Управление хранилищем", "Керування сховищем", "Жадты басқару", "Gestión de almacenamiento", ru, uk, kk, es);
        phrase("%d records", "%d записей", "%d записів", "%d жазба", "%d registros", ru, uk, kk, es);
        phrase("Encrypted receipts/paystubs", "Зашифрованные чеки/расчётные листы", "Зашифровані чеки/розрахункові листи", "Шифрланған түбіртектер/жалақы парақтары", "Recibos/nóminas cifrados", ru, uk, kk, es);
        phrase("Encrypted financial documents", "Зашифрованные финансовые документы", "Зашифровані фінансові документи", "Шифрланған қаржылық құжаттар", "Documentos financieros cifrados", ru, uk, kk, es);
        phrase("Temporary viewing cache", "Временный кэш просмотра", "Тимчасовий кеш перегляду", "Уақытша көру кэші", "Caché temporal de visualización", ru, uk, kk, es);
        phrase("Database", "База данных", "База даних", "Дерекқор", "Base de datos", ru, uk, kk, es);
        phrase("Clear temporary document cache", "Очистить временный кэш документов", "Очистити тимчасовий кеш документів", "Құжаттардың уақытша кэшін тазалау", "Borrar caché temporal de documentos", ru, uk, kk, es);
        phrase("Temporary cache cleared", "Временный кэш очищен", "Тимчасовий кеш очищено", "Уақытша кэш тазаланды", "Caché temporal borrada", ru, uk, kk, es);
        phrase("Remove unused document files", "Удалить неиспользуемые файлы документов", "Видалити невикористані файли документів", "Пайдаланылмайтын құжат файлдарын жою", "Eliminar archivos de documentos sin usar", ru, uk, kk, es);
        phrase("Unused files removed: %d", "Удалено неиспользуемых файлов: %d", "Видалено невикористаних файлів: %d", "Жойылған пайдаланылмайтын файлдар: %d", "Archivos sin usar eliminados: %d", ru, uk, kk, es);
        phrase("Export transactions as CSV", "Экспортировать операции в CSV", "Експортувати операції у CSV", "Транзакцияларды CSV ретінде экспорттау", "Exportar transacciones como CSV", ru, uk, kk, es);
        phrase("Export transactions as PDF", "Экспортировать операции в PDF", "Експортувати операції у PDF", "Транзакцияларды PDF ретінде экспорттау", "Exportar transacciones como PDF", ru, uk, kk, es);
        phrase("Delete all transactions and documents", "Удалить все операции и документы", "Видалити всі операції та документи", "Барлық транзакциялар мен құжаттарды жою", "Eliminar todas las transacciones y documentos", ru, uk, kk, es);
        phrase("About My Budget", "О приложении «Мой бюджет»", "Про «Мій бюджет»", "«Менің бюджетім» туралы", "Acerca de Mi presupuesto", ru, uk, kk, es);
        phrase("Version 1.3.0", "Версия 1.3.0", "Версія 1.3.0", "1.3.0 нұсқасы", "Versión 1.3.0", ru, uk, kk, es);
        phrase("Version 1.4.0", "Версия 1.4.0", "Версія 1.4.0", "1.4.0 нұсқасы", "Versión 1.4.0", ru, uk, kk, es);
        phrase("Version 1.5.0", "Версия 1.5.0", "Версія 1.5.0", "1.5.0 нұсқасы", "Versión 1.5.0", ru, uk, kk, es);
        phrase("Version 1.6.0", "Версия 1.6.0", "Версія 1.6.0", "1.6.0 нұсқасы", "Versión 1.6.0", ru, uk, kk, es);
        phrase("Package: com.macleanofduartenterprises.mybudget\nThe learning agent and OCR run locally. The app requests no internet permission and stores imported financial documents encrypted with the Android Keystore.", "Пакет: com.macleanofduartenterprises.mybudget\nОбучаемый помощник и распознавание работают локально. Приложение не запрашивает доступ к интернету и хранит импортированные финансовые документы в зашифрованном виде с помощью Android Keystore.", "Пакет: com.macleanofduartenterprises.mybudget\nНавчальний помічник і розпізнавання працюють локально. Застосунок не запитує доступ до інтернету та зберігає імпортовані фінансові документи зашифрованими за допомогою Android Keystore.", "Пакет: com.macleanofduartenterprises.mybudget\nҮйренетін көмекші мен мәтінді тану жергілікті жұмыс істейді. Қолданба интернет рұқсатын сұрамайды және импортталған қаржылық құжаттарды Android Keystore арқылы шифрлап сақтайды.", "Paquete: com.macleanofduartenterprises.mybudget\nEl agente de aprendizaje y el OCR funcionan localmente. La aplicación no solicita permiso de Internet y guarda cifrados los documentos financieros importados mediante Android Keystore.", ru, uk, kk, es);

        phrase("%s color", "Цвет: %s", "Колір: %s", "%s түсі", "Color de %s", ru, uk, kk, es);
        phrase("%1$s: %2$d%3$s", "%1$s: %2$d%3$s", "%1$s: %2$d%3$s", "%1$s: %2$d%3$s", "%1$s: %2$d%3$s", ru, uk, kk, es);
        phrase("Enter a six-digit hex color or choose a palette color.", "Введите шестизначный HEX-код или выберите цвет из палитры.", "Введіть шестизначний HEX-код або виберіть колір із палітри.", "Алты таңбалы HEX түсін енгізіңіз немесе палитрадан таңдаңыз.", "Introduce un color hexadecimal de seis dígitos o elige uno de la paleta.", ru, uk, kk, es);
        phrase("Apply", "Применить", "Застосувати", "Қолдану", "Aplicar", ru, uk, kk, es);
        phrase("Use a color such as #16382E", "Используйте цвет в формате #16382E", "Використовуйте колір у форматі #16382E", "#16382E сияқты түсті пайдаланыңыз", "Usa un color como #16382E", ru, uk, kk, es);
        phrase("Saving image…", "Сохранение изображения…", "Збереження зображення…", "Кескін сақталуда…", "Guardando imagen…", ru, uk, kk, es);
        phrase("Applying your custom background.", "Применение пользовательского фона.", "Застосування власного тла.", "Жеке фон қолданылуда.", "Aplicando el fondo personalizado.", ru, uk, kk, es);
        phrase("Applying your avatar.", "Применение аватара.", "Застосування аватара.", "Аватар қолданылуда.", "Aplicando el avatar.", ru, uk, kk, es);
        phrase("Unable to use that image.", "Не удалось использовать это изображение.", "Не вдалося використати це зображення.", "Бұл кескінді пайдалану мүмкін болмады.", "No se pudo usar esa imagen.", ru, uk, kk, es);
        phrase("Preparing CSV export…", "Подготовка экспорта CSV…", "Підготовка експорту CSV…", "CSV экспорты дайындалуда…", "Preparando exportación CSV…", ru, uk, kk, es);
        phrase("Your export will contain transaction details but not receipt images.", "Экспорт будет содержать данные операций, но не изображения чеков.", "Експорт міститиме дані операцій, але не зображення чеків.", "Экспортта транзакция мәліметтері болады, бірақ түбіртек кескіндері болмайды.", "La exportación incluirá los datos de las transacciones, pero no las imágenes de recibos.", ru, uk, kk, es);
        phrase("Your export will contain transaction details but not attached financial documents.", "Экспорт будет содержать данные операций, но не прикреплённые финансовые документы.", "Експорт міститиме дані операцій, але не прикріплені фінансові документи.", "Экспортта транзакция мәліметтері болады, бірақ тіркелген қаржылық құжаттар болмайды.", "La exportación incluirá los datos de las transacciones, pero no los documentos financieros adjuntos.", ru, uk, kk, es);
        phrase("My Budget transactions", "Операции «Моего бюджета»", "Операції «Мого бюджету»", "«Менің бюджетім» транзакциялары", "Transacciones de Mi presupuesto", ru, uk, kk, es);
        phrase("The CSV could not be created.", "Не удалось создать CSV.", "Не вдалося створити CSV.", "CSV жасау мүмкін болмады.", "No se pudo crear el CSV.", ru, uk, kk, es);
        phrase("Preparing PDF export…", "Подготовка экспорта PDF…", "Підготовка експорту PDF…", "PDF экспорты дайындалуда…", "Preparando exportación PDF…", ru, uk, kk, es);
        phrase("The transaction PDF could not be created.", "Не удалось создать PDF с операциями.", "Не вдалося створити PDF з операціями.", "Транзакциялар PDF файлын жасау мүмкін болмады.", "No se pudo crear el PDF de transacciones.", ru, uk, kk, es);
        phrase("Delete all budget data?", "Удалить все данные бюджета?", "Видалити всі дані бюджету?", "Барлық бюджет дерегі жойылсын ба?", "¿Eliminar todos los datos del presupuesto?", ru, uk, kk, es);
        phrase("Every transaction and encrypted receipt/paystub will be permanently deleted from this device. Appearance and passcode settings will remain.", "Все операции и зашифрованные чеки/расчётные листы будут безвозвратно удалены с устройства. Настройки оформления и кода доступа сохранятся.", "Усі операції та зашифровані чеки/розрахункові листи буде назавжди видалено з пристрою. Налаштування вигляду й коду доступу збережуться.", "Барлық транзакциялар мен шифрланған түбіртектер/жалақы парақтары құрылғыдан біржола жойылады. Көрініс пен кіру коды баптаулары қалады.", "Todas las transacciones y los recibos/nóminas cifrados se eliminarán permanentemente del dispositivo. Se conservarán los ajustes de apariencia y código.", ru, uk, kk, es);
        phrase("Every transaction and encrypted financial document will be permanently deleted from this device. Appearance and passcode settings will remain.", "Все операции и зашифрованные финансовые документы будут безвозвратно удалены с устройства. Настройки оформления и кода доступа сохранятся.", "Усі операції та зашифровані фінансові документи буде назавжди видалено з пристрою. Налаштування вигляду й коду доступу збережуться.", "Барлық транзакциялар мен шифрланған қаржылық құжаттар құрылғыдан біржола жойылады. Көрініс пен кіру коды баптаулары қалады.", "Todas las transacciones y los documentos financieros cifrados se eliminarán permanentemente del dispositivo. Se conservarán los ajustes de apariencia y código.", ru, uk, kk, es);
        phrase("Delete all", "Удалить всё", "Видалити все", "Барлығын жою", "Eliminar todo", ru, uk, kk, es);
        phrase("All transactions and documents deleted", "Все операции и документы удалены", "Усі операції та документи видалено", "Барлық транзакциялар мен құжаттар жойылды", "Todas las transacciones y documentos se eliminaron", ru, uk, kk, es);

        phrase("Passcode management", "Управление кодом доступа", "Керування кодом доступу", "Кіру кодын басқару", "Gestión del código de acceso", ru, uk, kk, es);
        phrase("Change passcode", "Изменить код доступа", "Змінити код доступу", "Кіру кодын өзгерту", "Cambiar código", ru, uk, kk, es);
        phrase("Disable passcode", "Отключить код доступа", "Вимкнути код доступу", "Кіру кодын өшіру", "Desactivar código", ru, uk, kk, es);
        phrase("Current passcode", "Текущий код доступа", "Поточний код доступу", "Ағымдағы кіру коды", "Código actual", ru, uk, kk, es);
        phrase("New passcode (4–12 digits)", "Новый код (4–12 цифр)", "Новий код (4–12 цифр)", "Жаңа код (4–12 сан)", "Nuevo código (4–12 dígitos)", ru, uk, kk, es);
        phrase("Confirm new passcode", "Подтвердите новый код", "Підтвердьте новий код", "Жаңа кодты растаңыз", "Confirmar nuevo código", ru, uk, kk, es);
        phrase("Save", "Сохранить", "Зберегти", "Сақтау", "Guardar", ru, uk, kk, es);
        phrase("Current passcode is incorrect", "Текущий код неверен", "Поточний код неправильний", "Ағымдағы код дұрыс емес", "El código actual es incorrecto", ru, uk, kk, es);
        phrase("Use 4–12 digits", "Используйте 4–12 цифр", "Використовуйте 4–12 цифр", "4–12 сан пайдаланыңыз", "Usa entre 4 y 12 dígitos", ru, uk, kk, es);
        phrase("Passcodes do not match", "Коды не совпадают", "Коди не збігаються", "Кодтар сәйкес келмейді", "Los códigos no coinciden", ru, uk, kk, es);
        phrase("Passcode could not be saved", "Не удалось сохранить код", "Не вдалося зберегти код", "Кодты сақтау мүмкін болмады", "No se pudo guardar el código", ru, uk, kk, es);
        phrase("Passcode saved", "Код доступа сохранён", "Код доступу збережено", "Кіру коды сақталды", "Código guardado", ru, uk, kk, es);
        phrase("Disable passcode?", "Отключить код доступа?", "Вимкнути код доступу?", "Кіру коды өшірілсін бе?", "¿Desactivar el código?", ru, uk, kk, es);
        phrase("Financial records will open without a passcode.", "Финансовые записи будут открываться без кода доступа.", "Фінансові записи відкриватимуться без коду доступу.", "Қаржылық жазбалар кіру кодынсыз ашылады.", "Los registros financieros se abrirán sin código.", ru, uk, kk, es);
        phrase("Disable", "Отключить", "Вимкнути", "Өшіру", "Desactivar", ru, uk, kk, es);
        phrase("Passcode is incorrect", "Неверный код доступа", "Неправильний код доступу", "Кіру коды дұрыс емес", "El código es incorrecto", ru, uk, kk, es);
        phrase("Passcode disabled", "Код доступа отключён", "Код доступу вимкнено", "Кіру коды өшірілді", "Código desactivado", ru, uk, kk, es);
        phrase("Unlock My Budget", "Разблокировать «Мой бюджет»", "Розблокувати «Мій бюджет»", "«Менің бюджетімді» ашу", "Desbloquear Mi presupuesto", ru, uk, kk, es);
        phrase("Enter your passcode to view local financial records.", "Введите код доступа для просмотра локальных финансовых записей.", "Введіть код доступу для перегляду локальних фінансових записів.", "Жергілікті қаржылық жазбаларды көру үшін кіру кодын енгізіңіз.", "Introduce el código para ver los registros financieros locales.", ru, uk, kk, es);
        phrase("Exit", "Выйти", "Вийти", "Шығу", "Salir", ru, uk, kk, es);
        phrase("Unlock", "Разблокировать", "Розблокувати", "Ашу", "Desbloquear", ru, uk, kk, es);
        phrase("Too many attempts. Wait 30 seconds.", "Слишком много попыток. Подождите 30 секунд.", "Забагато спроб. Зачекайте 30 секунд.", "Әрекет тым көп. 30 секунд күтіңіз.", "Demasiados intentos. Espera 30 segundos.", ru, uk, kk, es);
        phrase("Incorrect passcode", "Неверный код доступа", "Неправильний код доступу", "Кіру коды дұрыс емес", "Código incorrecto", ru, uk, kk, es);

        phrase("Close", "Закрыть", "Закрити", "Жабу", "Cerrar", ru, uk, kk, es);
        phrase("Document", "Документ", "Документ", "Құжат", "Documento", ru, uk, kk, es);
        phrase("Previous", "Назад", "Назад", "Алдыңғы", "Anterior", ru, uk, kk, es);
        phrase("Next", "Далее", "Далі", "Келесі", "Siguiente", ru, uk, kk, es);
        phrase("Unable to open this document.", "Не удалось открыть документ.", "Не вдалося відкрити документ.", "Құжатты ашу мүмкін болмады.", "No se pudo abrir este documento.", ru, uk, kk, es);
        phrase("Unable to display this document.", "Не удалось показать документ.", "Не вдалося показати документ.", "Құжатты көрсету мүмкін болмады.", "No se pudo mostrar este documento.", ru, uk, kk, es);

        phrase("Add income and expense transactions to create your first learned budget.", "Добавьте доходы и расходы, чтобы создать первый рассчитанный бюджет.", "Додайте доходи й витрати, щоб створити перший розрахований бюджет.", "Алғашқы үйренген бюджетті жасау үшін кіріс пен шығыс транзакцияларын қосыңыз.", "Añade transacciones de ingresos y gastos para crear tu primer presupuesto aprendido.", ru, uk, kk, es);
        phrase("This is an early estimate. Accuracy improves after a full month of history.", "Это предварительная оценка. Точность повысится после полного месяца истории.", "Це попередня оцінка. Точність зросте після повного місяця історії.", "Бұл бастапқы болжам. Толық бір айлық тарихтан кейін дәлдік артады.", "Esta es una estimación inicial. La precisión mejora tras un mes completo de historial.", ru, uk, kk, es);
        phrase("Recent spending was above learned income, so category limits were scaled to protect a 10% savings reserve.", "Недавние расходы превысили рассчитанный доход, поэтому лимиты категорий уменьшены для сохранения резерва 10%.", "Нещодавні витрати перевищили розрахований дохід, тому ліміти категорій зменшено для збереження резерву 10%.", "Соңғы шығыстар үйренген кірістен жоғары болды, сондықтан 10% жинақ қорын қорғау үшін санат шектері азайтылды.", "El gasto reciente superó los ingresos aprendidos, así que los límites se ajustaron para proteger una reserva de ahorro del 10%.", ru, uk, kk, es);
        phrase("The learned plan leaves about %d%% of expected income unspent.", "Рассчитанный план оставляет около %d%% ожидаемого дохода неизрасходованным.", "Розрахований план залишає близько %d%% очікуваного доходу невитраченим.", "Үйренген жоспар күтілетін кірістің шамамен %d%% бөлігін жұмсамай қалдырады.", "El plan aprendido deja sin gastar aproximadamente el %d%% de los ingresos previstos.", ru, uk, kk, es);
        phrase("Add income records so the agent can balance spending limits against take-home pay.", "Добавьте записи о доходах, чтобы помощник мог сопоставить лимиты расходов с чистым доходом.", "Додайте записи про доходи, щоб помічник міг зіставити ліміти витрат із чистим доходом.", "Көмекші шығыс шектерін таза жалақымен теңестіруі үшін кіріс жазбаларын қосыңыз.", "Añade registros de ingresos para que el agente pueda equilibrar los límites de gasto con el sueldo neto.", ru, uk, kk, es);
        phrase("Likely recurring charges: %s.", "Вероятные регулярные списания: %s.", "Ймовірні регулярні списання: %s.", "Ықтимал тұрақты төлемдер: %s.", "Cargos probablemente recurrentes: %s.", ru, uk, kk, es);
        phrase("This plan uses %d reviewed transactions imported from bank statements.", "В этом плане используются %d проверенных операций, импортированных из банковских выписок.", "У цьому плані використовуються %d перевірених операцій, імпортованих із банківських виписок.", "Бұл жоспарда банк көшірмелерінен импортталған %d тексерілген транзакция пайдаланылады.", "Este plan usa %d transacciones revisadas importadas de extractos bancarios.", ru, uk, kk, es);
        phrase("No transactions were recorded in this period.", "За этот период операций не зарегистрировано.", "За цей період операцій не зафіксовано.", "Бұл кезеңде транзакциялар тіркелмеді.", "No se registraron transacciones en este periodo.", ru, uk, kk, es);
        phrase("%1$s was the largest expense category at %2$d%% of spending.", "Категория «%1$s» была крупнейшей и составила %2$d%% расходов.", "Категорія «%1$s» була найбільшою та склала %2$d%% витрат.", "%1$s ең үлкен шығыс санаты болды: барлық шығыстың %2$d%%.", "%1$s fue la mayor categoría de gasto, con el %2$d%%.", ru, uk, kk, es);
        phrase("Spending increased %d%% compared with the prior period.", "Расходы выросли на %d%% по сравнению с прошлым периодом.", "Витрати зросли на %d%% порівняно з попереднім періодом.", "Шығындар алдыңғы кезеңмен салыстырғанда %d%% өсті.", "El gasto aumentó un %d%% frente al periodo anterior.", ru, uk, kk, es);
        phrase("Spending decreased %d%% compared with the prior period.", "Расходы снизились на %d%% по сравнению с прошлым периодом.", "Витрати зменшилися на %d%% порівняно з попереднім періодом.", "Шығындар алдыңғы кезеңмен салыстырғанда %d%% азайды.", "El gasto disminuyó un %d%% frente al periodo anterior.", ru, uk, kk, es);
        phrase("You kept %d%% of recorded income this period.", "В этом периоде вы сохранили %d%% зарегистрированного дохода.", "У цьому періоді ви зберегли %d%% зафіксованого доходу.", "Бұл кезеңде тіркелген кірістің %d%% сақталды.", "Conservaste el %d%% de los ingresos registrados este periodo.", ru, uk, kk, es);
        phrase("Expenses exceeded recorded income by %s.", "Расходы превысили зарегистрированный доход на %s.", "Витрати перевищили зафіксований дохід на %s.", "Шығыстар тіркелген кірістен %s-ға асты.", "Los gastos superaron los ingresos registrados en %s.", ru, uk, kk, es);
        phrase("%1$s was unusually high at %2$s.", "Необычно высокая сумма у «%1$s»: %2$s.", "Незвично висока сума у «%1$s»: %2$s.", "%1$s бойынша әдеттен тыс жоғары сома: %2$s.", "%1$s tuvo un importe inusualmente alto de %2$s.", ru, uk, kk, es);

        phrase("Period summary", "Итоги периода", "Підсумок періоду", "Кезең қорытындысы", "Resumen del periodo", ru, uk, kk, es);
        phrase("Not available", "Нет данных", "Немає даних", "Қолжетімсіз", "No disponible", ru, uk, kk, es);
        phrase("Spending by category", "Расходы по категориям", "Витрати за категоріями", "Санаттар бойынша шығыс", "Gasto por categoría", ru, uk, kk, es);
        phrase("No expense transactions in this period.", "В этом периоде нет расходных операций.", "У цьому періоді немає операцій витрат.", "Бұл кезеңде шығыс транзакциялары жоқ.", "No hay transacciones de gasto en este periodo.", ru, uk, kk, es);
        phrase("Local agent observations", "Наблюдения локального помощника", "Спостереження локального помічника", "Жергілікті көмекші бақылаулары", "Observaciones del agente local", ru, uk, kk, es);
        phrase("Learned monthly budget", "Рассчитанный месячный бюджет", "Розрахований місячний бюджет", "Үйренген айлық бюджет", "Presupuesto mensual aprendido", ru, uk, kk, es);
        phrase("Generated locally by My Budget. Estimates are based only on transactions recorded on this device and should be reviewed before financial decisions.", "Создано локально приложением «Мой бюджет». Оценки основаны только на операциях этого устройства; проверьте их перед финансовыми решениями.", "Створено локально застосунком «Мій бюджет». Оцінки ґрунтуються лише на операціях цього пристрою; перевірте їх перед фінансовими рішеннями.", "«Менің бюджетім» қолданбасында жергілікті жасалды. Болжамдар тек осы құрылғыда жазылған транзакцияларға негізделген; қаржылық шешімдер алдында тексеріңіз.", "Generado localmente por Mi presupuesto. Las estimaciones se basan solo en las transacciones registradas en este dispositivo y deben revisarse antes de tomar decisiones financieras.", ru, uk, kk, es);
        phrase("MY BUDGET • LOCAL REPORT", "МОЙ БЮДЖЕТ • ЛОКАЛЬНЫЙ ОТЧЁТ", "МІЙ БЮДЖЕТ • ЛОКАЛЬНИЙ ЗВІТ", "МЕНІҢ БЮДЖЕТІМ • ЖЕРГІЛІКТІ ЕСЕП", "MI PRESUPUESTO • INFORME LOCAL", ru, uk, kk, es);
        phrase("Page %d", "Страница %d", "Сторінка %d", "%d-бет", "Página %d", ru, uk, kk, es);
        phrase("Has document", "Есть документ", "Є документ", "Құжат бар", "Tiene documento", ru, uk, kk, es);
        phrase("Document type", "Тип документа", "Тип документа", "Құжат түрі", "Tipo de documento", ru, uk, kk, es);
        phrase("Bank statement", "Банковская выписка", "Банківська виписка", "Банк көшірмесі", "Extracto bancario", ru, uk, kk, es);
        phrase("Receipt or paystub", "Чек или расчётный лист", "Чек або розрахунковий лист", "Түбіртек немесе жалақы парағы", "Recibo o nómina", ru, uk, kk, es);
        phrase("Bank-statement transactions used", "Использовано операций из выписок", "Використано операцій із виписок", "Көшірмеден пайдаланылған транзакциялар", "Transacciones de extractos utilizadas", ru, uk, kk, es);
        phrase("Yes", "Да", "Так", "Иә", "Sí", ru, uk, kk, es);
        phrase("No", "Нет", "Ні", "Жоқ", "No", ru, uk, kk, es);
        phrase("Transaction export", "Экспорт операций", "Експорт операцій", "Транзакциялар экспорты", "Exportación de transacciones", ru, uk, kk, es);
        phrase("Generated", "Создано", "Створено", "Жасалды", "Generado", ru, uk, kk, es);
        phrase("Transaction details", "Данные операций", "Дані операцій", "Транзакция мәліметтері", "Detalles de transacciones", ru, uk, kk, es);
        phrase("Created locally. Receipt and paystub images are not included in this transaction export.", "Создано локально. Изображения чеков и расчётных листов не включены в этот экспорт операций.", "Створено локально. Зображення чеків і розрахункових листів не включено до цього експорту операцій.", "Жергілікті жасалды. Түбіртек пен жалақы парағының кескіндері бұл транзакция экспортына қосылмайды.", "Creado localmente. Las imágenes de recibos y nóminas no se incluyen en esta exportación de transacciones.", ru, uk, kk, es);
        phrase("Created locally. Attached financial documents are not included in this transaction export.", "Создано локально. Прикреплённые финансовые документы не включены в этот экспорт операций.", "Створено локально. Прикріплені фінансові документи не включено до цього експорту операцій.", "Жергілікті жасалды. Тіркелген қаржылық құжаттар бұл транзакция экспортына қосылмайды.", "Creado localmente. Los documentos financieros adjuntos no se incluyen en esta exportación de transacciones.", ru, uk, kk, es);

        phrase("This week", "Эта неделя", "Цей тиждень", "Осы апта", "Esta semana", ru, uk, kk, es);
        phrase("Budget period", "Период бюджета", "Період бюджету", "Бюджет кезеңі", "Periodo del presupuesto", ru, uk, kk, es);
        phrase("Switch between independent weekly and monthly manual and AI budgets.", "Переключайтесь между отдельными недельными и месячными ручными бюджетами и бюджетами ИИ.", "Перемикайтеся між окремими тижневими й місячними ручними бюджетами та бюджетами ШІ.", "Бөлек апталық және айлық қолмен басқарылатын және AI бюджеттері арасында ауысыңыз.", "Cambia entre presupuestos manuales y de IA semanales y mensuales independientes.", ru, uk, kk, es);
        phrase("AI weekly budget", "Недельный бюджет ИИ", "Тижневий бюджет ШІ", "AI апталық бюджеті", "Presupuesto semanal de IA", ru, uk, kk, es);
        phrase("AI monthly budget", "Месячный бюджет ИИ", "Місячний бюджет ШІ", "AI айлық бюджеті", "Presupuesto mensual de IA", ru, uk, kk, es);
        phrase("Manual weekly budget", "Ручной недельный бюджет", "Ручний тижневий бюджет", "Қолмен басқарылатын апталық бюджет", "Presupuesto semanal manual", ru, uk, kk, es);
        phrase("Enter weekly amounts. A blank or zero category removes that limit.", "Введите недельные суммы. Пустая или нулевая сумма удаляет лимит категории.", "Введіть тижневі суми. Порожнє або нульове значення видаляє ліміт категорії.", "Апталық сомаларды енгізіңіз. Бос немесе нөл мән санат шегін жояды.", "Introduce importes semanales. Un valor vacío o cero elimina el límite de esa categoría.", ru, uk, kk, es);
        phrase("Weekly category limits", "Недельные лимиты по категориям", "Тижневі ліміти за категоріями", "Санаттардың апталық шектері", "Límites semanales por categoría", ru, uk, kk, es);
        phrase("Enter at least one weekly amount.", "Введите хотя бы одну недельную сумму.", "Введіть хоча б одну тижневу суму.", "Кемінде бір апталық соманы енгізіңіз.", "Introduce al menos un importe semanal.", ru, uk, kk, es);

        phrase("Weekly category report", "Недельный отчёт по категории", "Тижневий звіт за категорією", "Санат бойынша апталық есеп", "Informe semanal por categoría", ru, uk, kk, es);
        phrase("Monthly category report", "Месячный отчёт по категории", "Місячний звіт за категорією", "Санат бойынша айлық есеп", "Informe mensual por categoría", ru, uk, kk, es);
        phrase("Independent category report", "Отдельный отчёт по категории", "Окремий звіт за категорією", "Санат бойынша бөлек есеп", "Informe independiente por categoría", ru, uk, kk, es);
        phrase("Choose one income or expense category and create a separate weekly or monthly report.", "Выберите одну категорию доходов или расходов и создайте отдельный недельный или месячный отчёт.", "Виберіть одну категорію доходів або витрат і створіть окремий тижневий або місячний звіт.", "Бір кіріс немесе шығыс санатын таңдап, бөлек апталық не айлық есеп жасаңыз.", "Elige una categoría de ingresos o gastos y crea un informe semanal o mensual independiente.", ru, uk, kk, es);
        phrase("Report period", "Период отчёта", "Період звіту", "Есеп кезеңі", "Periodo del informe", ru, uk, kk, es);
        phrase("Create category report", "Создать отчёт по категории", "Створити звіт за категорією", "Санат есебін жасау", "Crear informe por categoría", ru, uk, kk, es);
        phrase("Income category activity", "Операции в категории доходов", "Операції в категорії доходів", "Кіріс санатының әрекеті", "Actividad de la categoría de ingresos", ru, uk, kk, es);
        phrase("Expense category activity", "Операции в категории расходов", "Операції в категорії витрат", "Шығыс санатының әрекеті", "Actividad de la categoría de gastos", ru, uk, kk, es);
        phrase("Category budget comparison", "Сравнение бюджета категории", "Порівняння бюджету категорії", "Санат бюджетін салыстыру", "Comparación del presupuesto de la categoría", ru, uk, kk, es);
        phrase("Recorded income", "Учтённый доход", "Зафіксований дохід", "Тіркелген кіріс", "Ingresos registrados", ru, uk, kk, es);
        phrase("Recorded spending", "Учтённые расходы", "Зафіксовані витрати", "Тіркелген шығыс", "Gasto registrado", ru, uk, kk, es);
        phrase("AI expected income", "Ожидаемый доход по оценке ИИ", "Очікуваний дохід за оцінкою ШІ", "AI болжаған кіріс", "Ingresos previstos por la IA", ru, uk, kk, es);
        phrase("Not set", "Не задано", "Не задано", "Орнатылмаған", "Sin configurar", ru, uk, kk, es);
        phrase("Manual expected income is stored for the whole budget period, not divided among income categories.", "Ручной ожидаемый доход сохраняется для всего бюджетного периода и не распределяется по категориям доходов.", "Ручний очікуваний дохід зберігається для всього бюджетного періоду й не розподіляється за категоріями доходів.", "Қолмен енгізілген күтілетін кіріс бүкіл бюджет кезеңіне сақталады және кіріс санаттарына бөлінбейді.", "Los ingresos previstos manualmente se guardan para todo el periodo presupuestario y no se dividen entre categorías de ingresos.", ru, uk, kk, es);
        phrase("AI category limit", "Лимит категории по оценке ИИ", "Ліміт категорії за оцінкою ШІ", "AI санат шегі", "Límite de categoría de la IA", ru, uk, kk, es);
        phrase("Manual category limit", "Ручной лимит категории", "Ручний ліміт категорії", "Қолмен қойылған санат шегі", "Límite manual de la categoría", ru, uk, kk, es);
        phrase("Edit weekly manual budget", "Изменить ручной недельный бюджет", "Редагувати ручний тижневий бюджет", "Қолмен басқарылатын апталық бюджетті өңдеу", "Editar presupuesto semanal manual", ru, uk, kk, es);
        phrase("Edit monthly manual budget", "Изменить ручной месячный бюджет", "Редагувати ручний місячний бюджет", "Қолмен басқарылатын айлық бюджетті өңдеу", "Editar presupuesto mensual manual", ru, uk, kk, es);

        phrase("Weekly report settings", "Настройки недельного отчёта", "Налаштування тижневого звіту", "Апталық есеп параметрлері", "Configuración del informe semanal", ru, uk, kk, es);
        phrase("Start day of the week", "Первый день недели", "Перший день тижня", "Аптаның басталу күні", "Día de inicio de la semana", ru, uk, kk, es);
        phrase("Weekly reports and weekly budget progress use this day as their first day.", "Недельные отчёты и ход недельного бюджета используют этот день как первый.", "Тижневі звіти та перебіг тижневого бюджету використовують цей день як перший.", "Апталық есептер мен апталық бюджет барысы осы күнді бірінші күн ретінде пайдаланады.", "Los informes y el progreso del presupuesto semanal usan este día como el primero de la semana.", ru, uk, kk, es);
        phrase("Category management", "Управление категориями", "Керування категоріями", "Санаттарды басқару", "Gestión de categorías", ru, uk, kk, es);
        phrase("Add your own income and expense categories. Custom categories can be renamed or removed.", "Добавляйте собственные категории доходов и расходов. Пользовательские категории можно переименовывать или удалять.", "Додавайте власні категорії доходів і витрат. Власні категорії можна перейменовувати або видаляти.", "Өзіңіздің кіріс және шығыс санаттарыңызды қосыңыз. Арнайы санаттарды өзгертуге немесе жоюға болады.", "Añade tus propias categorías de ingresos y gastos. Las categorías personalizadas se pueden renombrar o quitar.", ru, uk, kk, es);
        phrase("Add, rename, reorder, or remove any income or expense category, including the original categories.", "Добавляйте, переименовывайте, упорядочивайте или удаляйте любые категории доходов и расходов, включая исходные.", "Додавайте, перейменовуйте, упорядковуйте або видаляйте будь-які категорії доходів і витрат, зокрема початкові.", "Кіріс пен шығыстың кез келген санатын, соның ішінде бастапқы санаттарды қосуға, атауын өзгертуге, реттеуге немесе жоюға болады.", "Añade, renombra, reordena o quita cualquier categoría de ingresos o gastos, incluidas las originales.", ru, uk, kk, es);
        phrase("Income categories", "Категории доходов", "Категорії доходів", "Кіріс санаттары", "Categorías de ingresos", ru, uk, kk, es);
        phrase("Expense categories", "Категории расходов", "Категорії витрат", "Шығыс санаттары", "Categorías de gastos", ru, uk, kk, es);
        phrase("Rename", "Переименовать", "Перейменувати", "Атын өзгерту", "Renombrar", ru, uk, kk, es);
        phrase("Remove", "Удалить", "Видалити", "Жою", "Quitar", ru, uk, kk, es);
        phrase("Move category up", "Переместить категорию вверх", "Перемістити категорію вгору", "Санатты жоғары жылжыту", "Mover categoría hacia arriba", ru, uk, kk, es);
        phrase("Move category down", "Переместить категорию вниз", "Перемістити категорію вниз", "Санатты төмен жылжыту", "Mover categoría hacia abajo", ru, uk, kk, es);
        phrase("Add", "Добавить", "Додати", "Қосу", "Añadir", ru, uk, kk, es);
        phrase("Add income category", "Добавить категорию доходов", "Додати категорію доходів", "Кіріс санатын қосу", "Añadir categoría de ingresos", ru, uk, kk, es);
        phrase("Add expense category", "Добавить категорию расходов", "Додати категорію витрат", "Шығыс санатын қосу", "Añadir categoría de gastos", ru, uk, kk, es);
        phrase("Category name", "Название категории", "Назва категорії", "Санат атауы", "Nombre de la categoría", ru, uk, kk, es);
        phrase("Use a category name between 1 and 48 characters.", "Введите название категории длиной от 1 до 48 символов.", "Введіть назву категорії довжиною від 1 до 48 символів.", "1–48 таңбадан тұратын санат атауын енгізіңіз.", "Usa un nombre de categoría de entre 1 y 48 caracteres.", ru, uk, kk, es);
        phrase("That category already exists.", "Такая категория уже существует.", "Така категорія вже існує.", "Бұл санат бұрыннан бар.", "Esa categoría ya existe.", ru, uk, kk, es);
        phrase("That category could not be added.", "Не удалось добавить категорию.", "Не вдалося додати категорію.", "Санатты қосу мүмкін болмады.", "No se pudo añadir la categoría.", ru, uk, kk, es);
        phrase("Category added", "Категория добавлена", "Категорію додано", "Санат қосылды", "Categoría añadida", ru, uk, kk, es);
        phrase("Rename category", "Переименовать категорию", "Перейменувати категорію", "Санат атауын өзгерту", "Renombrar categoría", ru, uk, kk, es);
        phrase("That category could not be renamed.", "Не удалось переименовать категорию.", "Не вдалося перейменувати категорію.", "Санат атауын өзгерту мүмкін болмады.", "No se pudo renombrar la categoría.", ru, uk, kk, es);
        phrase("Category renamed", "Категория переименована", "Категорію перейменовано", "Санат атауы өзгертілді", "Categoría renombrada", ru, uk, kk, es);
        phrase("Remove category?", "Удалить категорию?", "Видалити категорію?", "Санат жойылсын ба?", "¿Quitar categoría?", ru, uk, kk, es);
        phrase("%1$d existing transactions will be moved to %2$s. Any manual limits will also be moved.", "%1$d существующих операций будут перемещены в категорию «%2$s». Ручные лимиты также будут перемещены.", "%1$d наявних операцій буде переміщено до категорії «%2$s». Ручні ліміти також буде переміщено.", "%1$d бар транзакция %2$s санатына ауыстырылады. Қолмен қойылған шектер де ауыстырылады.", "Se moverán %1$d transacciones existentes a %2$s. También se moverán los límites manuales.", ru, uk, kk, es);
        phrase("This removes the custom category from future selections.", "Пользовательская категория будет удалена из будущих списков выбора.", "Власну категорію буде видалено з майбутніх списків вибору.", "Арнайы санат болашақ таңдау тізімдерінен жойылады.", "Esto quita la categoría personalizada de las selecciones futuras.", ru, uk, kk, es);
        phrase("This removes the custom category from future selections. Any manual limits will be moved to %s.", "Пользовательская категория будет удалена из будущих списков выбора. Ручные лимиты будут перемещены в «%s».", "Власну категорію буде видалено з майбутніх списків вибору. Ручні ліміти буде переміщено до «%s».", "Арнайы санат болашақ таңдау тізімдерінен жойылады. Қолмен қойылған шектер %s санатына ауыстырылады.", "Esto quita la categoría personalizada de las selecciones futuras. Los límites manuales se moverán a %s.", ru, uk, kk, es);
        phrase("This removes the category from future selections. Any manual limits will be moved to %s.", "Категория будет удалена из будущих списков выбора. Ручные лимиты будут перемещены в «%s».", "Категорію буде видалено з майбутніх списків вибору. Ручні ліміти буде переміщено до «%s».", "Санат болашақ таңдау тізімдерінен жойылады. Қолмен қойылған шектер %s санатына ауыстырылады.", "Esto quita la categoría de las selecciones futuras. Los límites manuales se moverán a %s.", ru, uk, kk, es);
        phrase("At least one category must remain in each list.", "В каждом списке должна остаться хотя бы одна категория.", "У кожному списку має залишитися принаймні одна категорія.", "Әр тізімде кемінде бір санат қалуы керек.", "Debe quedar al menos una categoría en cada lista.", ru, uk, kk, es);
        phrase("Category removed", "Категория удалена", "Категорію видалено", "Санат жойылды", "Categoría quitada", ru, uk, kk, es);
        phrase("License", "Лицензия", "Ліцензія", "Лицензия", "Licencia", ru, uk, kk, es);
        phrase("My Budget is licensed under the GNU Affero General Public License, version 3 (AGPLv3).", "«Мой бюджет» распространяется на условиях GNU Affero General Public License версии 3 (AGPLv3).", "«Мій бюджет» поширюється на умовах GNU Affero General Public License версії 3 (AGPLv3).", "«Менің бюджетім» GNU Affero General Public License 3-нұсқасы (AGPLv3) бойынша лицензияланған.", "Mi presupuesto se distribuye bajo la Licencia Pública General Affero de GNU, versión 3 (AGPLv3).", ru, uk, kk, es);
        phrase("Read full AGPLv3 license", "Прочитать полный текст AGPLv3", "Прочитати повний текст AGPLv3", "AGPLv3 лицензиясының толық мәтінін оқу", "Leer la licencia AGPLv3 completa", ru, uk, kk, es);
        phrase("← Back to Settings", "← Назад к настройкам", "← Назад до налаштувань", "← Баптауларға оралу", "← Volver a Ajustes", ru, uk, kk, es);
        phrase("My Budget is free software licensed under version 3 of the GNU Affero General Public License (AGPLv3). You may redistribute and modify it under that license. It is provided without warranty to the extent permitted by law.", "«Мой бюджет» — свободное программное обеспечение под лицензией GNU Affero General Public License версии 3 (AGPLv3). Вы можете распространять и изменять его на условиях этой лицензии. В пределах, разрешённых законом, программа предоставляется без каких-либо гарантий.", "«Мій бюджет» — вільне програмне забезпечення за ліцензією GNU Affero General Public License версії 3 (AGPLv3). Ви можете поширювати й змінювати його на умовах цієї ліцензії. У межах, дозволених законом, програма надається без будь-яких гарантій.", "«Менің бюджетім» — GNU Affero General Public License 3-нұсқасы (AGPLv3) бойынша лицензияланған еркін бағдарламалық жасақтама. Оны осы лицензия шарттарына сәйкес таратуға және өзгертуге болады. Заң рұқсат еткен шекте ол ешқандай кепілдіксіз ұсынылады.", "Mi presupuesto es software libre con licencia GNU Affero General Public License versión 3 (AGPLv3). Puede redistribuirlo y modificarlo conforme a esa licencia. Se proporciona sin garantía en la medida permitida por la ley.", ru, uk, kk, es);
        phrase("The complete corresponding source code is distributed with this release.", "Полный соответствующий исходный код распространяется вместе с этим выпуском.", "Повний відповідний вихідний код поширюється разом із цим випуском.", "Толық сәйкес бастапқы код осы шығарылыммен бірге таратылады.", "El código fuente correspondiente completo se distribuye con esta versión.", ru, uk, kk, es);
        phrase("Full license text", "Полный текст лицензии", "Повний текст ліцензії", "Лицензияның толық мәтіні", "Texto completo de la licencia", ru, uk, kk, es);
        phrase("The complete license text below is the authoritative English text.", "Полный текст лицензии ниже является официальным текстом на английском языке.", "Повний текст ліцензії нижче є офіційним текстом англійською мовою.", "Төмендегі лицензияның толық ағылшын мәтіні ресми мәтін болып табылады.", "El texto completo de la licencia que aparece a continuación es el texto oficial en inglés.", ru, uk, kk, es);
        phrase("The license text could not be loaded.", "Не удалось загрузить текст лицензии.", "Не вдалося завантажити текст ліцензії.", "Лицензия мәтінін жүктеу мүмкін болмады.", "No se pudo cargar el texto de la licencia.", ru, uk, kk, es);
        phrase("Version %s", "Версия %s", "Версія %s", "%s нұсқасы", "Versión %s", ru, uk, kk, es);
        phrase("Version 1.7.0", "Версия 1.7.0", "Версія 1.7.0", "1.7.0 нұсқасы", "Versión 1.7.0", ru, uk, kk, es);
        phrase("Version 1.7.1", "Версия 1.7.1", "Версія 1.7.1", "1.7.1 нұсқасы", "Versión 1.7.1", ru, uk, kk, es);

        category("Housing", "Жильё", "Житло", "Тұрғын үй", "Vivienda", ru, uk, kk, es);
        category("Utilities", "Коммунальные услуги", "Комунальні послуги", "Коммуналдық қызметтер", "Servicios", ru, uk, kk, es);
        category("Groceries", "Продукты", "Продукти", "Азық-түлік", "Comestibles", ru, uk, kk, es);
        category("Transportation", "Транспорт", "Транспорт", "Көлік", "Transporte", ru, uk, kk, es);
        category("Healthcare", "Здоровье", "Здоров’я", "Денсаулық", "Salud", ru, uk, kk, es);
        category("Insurance", "Страхование", "Страхування", "Сақтандыру", "Seguros", ru, uk, kk, es);
        category("Debt", "Долги", "Борги", "Қарыз", "Deudas", ru, uk, kk, es);
        category("Childcare", "Уход за детьми", "Догляд за дітьми", "Бала күтімі", "Cuidado infantil", ru, uk, kk, es);
        category("Household", "Дом", "Дім", "Үй шаруашылығы", "Hogar", ru, uk, kk, es);
        category("Dining", "Кафе и рестораны", "Кафе й ресторани", "Кафе мен мейрамханалар", "Restaurantes", ru, uk, kk, es);
        category("Shopping", "Покупки", "Покупки", "Сатып алулар", "Compras", ru, uk, kk, es);
        category("Entertainment", "Развлечения", "Розваги", "Ойын-сауық", "Entretenimiento", ru, uk, kk, es);
        category("Giving", "Пожертвования", "Пожертви", "Қайырымдылық", "Donaciones", ru, uk, kk, es);
        category("Education", "Образование", "Освіта", "Білім", "Educación", ru, uk, kk, es);
        category("Business", "Бизнес", "Бізнес", "Бизнес", "Negocio", ru, uk, kk, es);
        category("Other", "Другое", "Інше", "Басқа", "Otros", ru, uk, kk, es);
        category("Paycheck", "Зарплата", "Зарплата", "Жалақы", "Nómina", ru, uk, kk, es);
        category("Business income", "Доход от бизнеса", "Дохід від бізнесу", "Бизнес кірісі", "Ingresos del negocio", ru, uk, kk, es);
        category("Benefits", "Пособия", "Допомога", "Жәрдемақы", "Prestaciones", ru, uk, kk, es);
        category("Reimbursement", "Возмещение", "Відшкодування", "Өтемақы", "Reembolso", ru, uk, kk, es);
        category("Gift", "Подарок", "Подарунок", "Сыйлық", "Regalo", ru, uk, kk, es);
        category("Other income", "Другой доход", "Інший дохід", "Басқа кіріс", "Otros ingresos", ru, uk, kk, es);
    }

    private final String code;
    private final Locale locale;

    public LanguageManager(String requestedCode) {
        code = normalize(requestedCode);
        locale = Locale.forLanguageTag(code);
    }

    public String code() { return code; }
    public Locale locale() { return locale; }

    public String t(String english, Object... args) {
        String template = english == null ? "" : english;
        Map<String, String> catalog = TRANSLATIONS.get(code);
        if (catalog != null && catalog.containsKey(template)) template = catalog.get(template);
        if (args == null || args.length == 0) return template;
        try { return String.format(locale, template, args); }
        catch (Exception ignored) { return template; }
    }

    public String category(String canonical) { return t(canonical == null ? "Other" : canonical); }

    public String canonicalCategory(String displayed) {
        if (displayed == null) return "Other";
        for (String value : allCanonicalCategories()) if (category(value).equals(displayed)) return value;
        String custom = displayed.trim();
        return custom.isEmpty() ? "Other" : custom;
    }

    public List<String> categoryList(List<String> canonicalValues) {
        List<String> result = new ArrayList<>();
        for (String value : canonicalValues) result.add(category(value));
        return result;
    }

    public Map<String, Long> localizedCategories(Map<String, Long> canonicalValues) {
        Map<String, Long> result = new LinkedHashMap<>();
        for (Map.Entry<String, Long> entry : canonicalValues.entrySet()) result.put(category(entry.getKey()), entry.getValue());
        return result;
    }

    public boolean hasTranslation(String english) {
        return ENGLISH.equals(code) || TRANSLATIONS.get(code).containsKey(english);
    }

    public static List<String> codes() { return new ArrayList<>(CODES); }
    public static List<String> languageNames() { return new ArrayList<>(NAMES); }
    public static int indexOf(String code) { return Math.max(0, CODES.indexOf(normalize(code))); }
    public static String codeAt(int index) { return CODES.get(Math.max(0, Math.min(CODES.size() - 1, index))); }

    public static String defaultCode(Locale locale) {
        String candidate = locale == null ? ENGLISH : locale.getLanguage();
        return CODES.contains(candidate) ? candidate : ENGLISH;
    }

    private static String normalize(String value) { return CODES.contains(value) ? value : ENGLISH; }

    private static List<String> allCanonicalCategories() {
        List<String> values = new ArrayList<>(TransactionRecord.EXPENSE_CATEGORIES);
        for (String value : TransactionRecord.INCOME_CATEGORIES) if (!values.contains(value)) values.add(value);
        return values;
    }

    private static void add(Map<String, String> map, String english, String translation) { map.put(english, translation); }

    private static void phrase(String english, String russian, String ukrainian, String kazakh, String spanish,
                               Map<String, String> ru, Map<String, String> uk, Map<String, String> kk, Map<String, String> es) {
        add(ru, english, russian); add(uk, english, ukrainian); add(kk, english, kazakh); add(es, english, spanish);
    }

    private static void category(String english, String russian, String ukrainian, String kazakh, String spanish,
                                 Map<String, String> ru, Map<String, String> uk, Map<String, String> kk, Map<String, String> es) {
        phrase(english, russian, ukrainian, kazakh, spanish, ru, uk, kk, es);
    }
}
