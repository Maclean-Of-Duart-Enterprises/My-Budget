package com.macleanofduartenterprises.mybudget;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Persists the editable manual budget locally without changing transaction data. */
public final class ManualBudgetStore {
    private static final String FILE = "manual_budget";
    private static final String CONFIGURED = "configured";
    private static final String CATEGORIES = "categories";
    private final SharedPreferences preferences;

    public ManualBudgetStore(Context context) {
        preferences = context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public ManualBudget load() {
        return load(BudgetPeriod.MONTHLY);
    }

    public ManualBudget load(String requestedPeriod) {
        String period = BudgetPeriod.normalize(requestedPeriod);
        String prefix = prefix(period);
        if (!preferences.contains(prefix + CONFIGURED)) {
            return BudgetPeriod.MONTHLY.equals(period) ? loadLegacyMonthly() : new ManualBudget();
        }
        ManualBudget budget = new ManualBudget();
        budget.expectedMonthlyIncome = Math.max(0, preferences.getLong(prefix + "expected_income", 0));
        budget.savingsTarget = Math.max(0, preferences.getLong(prefix + "savings_target", 0));
        budget.updatedAt = preferences.getLong(prefix + "updated_at", 0);
        List<String> categoryNames = new ArrayList<>(TransactionRecord.EXPENSE_CATEGORIES);
        Set<String> stored = preferences.getStringSet(prefix + CATEGORIES, new HashSet<>());
        if (stored != null) {
            for (String category : stored) if (!categoryNames.contains(category)) categoryNames.add(category);
        }
        for (String category : categoryNames) {
            long limit = Math.max(0, preferences.getLong(key(prefix, category), 0));
            if (limit > 0) budget.categoryLimits.put(category, limit);
        }
        return budget;
    }

    public void save(ManualBudget budget) {
        save(BudgetPeriod.MONTHLY, budget);
    }

    public void save(String requestedPeriod, ManualBudget budget) {
        String period = BudgetPeriod.normalize(requestedPeriod);
        String prefix = prefix(period);
        ManualBudget safe = budget == null ? new ManualBudget() : budget;
        SharedPreferences.Editor editor = preferences.edit();
        removePrefix(editor, prefix);
        editor.putBoolean(prefix + CONFIGURED, true)
                .putLong(prefix + "expected_income", Math.max(0, safe.expectedMonthlyIncome))
                .putLong(prefix + "savings_target", Math.max(0, safe.savingsTarget))
                .putLong(prefix + "updated_at", safe.updatedAt > 0 ? safe.updatedAt : System.currentTimeMillis())
                .putStringSet(prefix + CATEGORIES, new HashSet<>(safe.categoryLimits.keySet()));
        for (Map.Entry<String, Long> entry : safe.categoryLimits.entrySet()) {
            long limit = Math.max(0, entry.getValue() == null ? 0 : entry.getValue());
            if (limit > 0) editor.putLong(key(prefix, entry.getKey()), limit);
        }
        if (BudgetPeriod.MONTHLY.equals(period)) removeLegacy(editor);
        editor.apply();
    }

    public void clear() { clear(BudgetPeriod.MONTHLY); }

    public void clear(String requestedPeriod) {
        String period = BudgetPeriod.normalize(requestedPeriod);
        SharedPreferences.Editor editor = preferences.edit();
        removePrefix(editor, prefix(period));
        if (BudgetPeriod.MONTHLY.equals(period)) removeLegacy(editor);
        editor.apply();
    }

    public void renameCategory(String oldValue, String newValue) {
        moveCategory(oldValue, newValue);
    }

    public void moveCategory(String oldValue, String replacement) {
        if (oldValue == null || replacement == null || oldValue.equals(replacement)) return;
        for (String period : new String[]{BudgetPeriod.WEEKLY, BudgetPeriod.MONTHLY}) {
            ManualBudget budget = load(period);
            Long oldLimit = removeIgnoreCase(budget, oldValue);
            if (oldLimit == null || oldLimit <= 0) continue;
            String existingKey = findIgnoreCase(budget, replacement);
            long existing = existingKey == null ? 0 : budget.categoryLimits.remove(existingKey);
            budget.categoryLimits.put(replacement, Math.max(0, existing) + oldLimit);
            budget.updatedAt = System.currentTimeMillis();
            save(period, budget);
        }
    }

    private ManualBudget loadLegacyMonthly() {
        ManualBudget budget = new ManualBudget();
        budget.expectedMonthlyIncome = Math.max(0, preferences.getLong("expected_income", 0));
        budget.savingsTarget = Math.max(0, preferences.getLong("savings_target", 0));
        budget.updatedAt = preferences.getLong("updated_at", 0);
        for (String category : TransactionRecord.EXPENSE_CATEGORIES) {
            long limit = Math.max(0, preferences.getLong("limit_" + category, 0));
            if (limit > 0) budget.categoryLimits.put(category, limit);
        }
        return budget;
    }

    private void removePrefix(SharedPreferences.Editor editor, String prefix) {
        for (String key : preferences.getAll().keySet()) if (key.startsWith(prefix)) editor.remove(key);
    }

    private void removeLegacy(SharedPreferences.Editor editor) {
        editor.remove("expected_income").remove("savings_target").remove("updated_at");
        for (String category : TransactionRecord.EXPENSE_CATEGORIES) editor.remove("limit_" + category);
    }

    private static Long removeIgnoreCase(ManualBudget budget, String category) {
        String key = findIgnoreCase(budget, category);
        return key == null ? null : budget.categoryLimits.remove(key);
    }

    private static String findIgnoreCase(ManualBudget budget, String category) {
        for (String value : budget.categoryLimits.keySet()) {
            if (value.equalsIgnoreCase(category)) return value;
        }
        return null;
    }

    private static String prefix(String period) { return BudgetPeriod.normalize(period) + "_"; }
    private static String key(String prefix, String category) { return prefix + "limit_" + category; }
}
