package com.macleanofduartenterprises.mybudget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.ImageDecoder;
import android.graphics.Paint;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.googlecode.tesseract.android.TessBaseAPI;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class OcrEngine implements AutoCloseable {
    public interface Callback {
        void onSuccess(String text);
        void onError(Exception error);
    }

    private final Context context;
    private final TextRecognizer recognizer;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    public OcrEngine(Context context) {
        this.context = context.getApplicationContext();
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    public void scan(Uri uri, String mimeType, Callback callback) {
        scan(uri, mimeType, LanguageManager.ENGLISH, callback);
    }

    public void scan(Uri uri, String mimeType, String languageCode, Callback callback) {
        scan(uri, mimeType, languageCode, 3, callback);
    }

    public void scanStatement(Uri uri, String mimeType, String languageCode, Callback callback) {
        scan(uri, mimeType, languageCode, 12, callback);
    }

    private void scan(Uri uri, String mimeType, String languageCode, int maximumPdfPages,
                      Callback callback) {
        executor.execute(() -> {
            try {
                boolean cyrillic = LanguageManager.RUSSIAN.equals(languageCode)
                        || LanguageManager.UKRAINIAN.equals(languageCode)
                        || LanguageManager.KAZAKH.equals(languageCode);
                String text;
                if (cyrillic) {
                    String model = LanguageManager.RUSSIAN.equals(languageCode) ? "rus"
                            : LanguageManager.UKRAINIAN.equals(languageCode) ? "ukr" : "kaz";
                    text = "application/pdf".equals(mimeType)
                            ? scanPdfWithTesseract(uri, model, maximumPdfPages) : scanImageWithTesseract(uri, model);
                } else {
                    text = "application/pdf".equals(mimeType) ? scanPdf(uri, maximumPdfPages) : scanImage(uri);
                }
                main.post(() -> callback.onSuccess(text));
            } catch (Exception error) {
                main.post(() -> callback.onError(error));
            }
        });
    }

    private String scanImage(Uri uri) throws Exception {
        Bitmap bitmap = loadBitmap(uri);
        if (bitmap == null) throw new IllegalArgumentException("The selected image cannot be opened.");
        try {
            return recognizeLatinBest(bitmap);
        } finally {
            bitmap.recycle();
        }
    }

    private String scanPdf(Uri uri, int maximumPages) throws Exception {
        StringBuilder result = new StringBuilder();
        try (ParcelFileDescriptor descriptor = context.getContentResolver().openFileDescriptor(uri, "r")) {
            if (descriptor == null) throw new IllegalArgumentException("The selected PDF cannot be opened.");
            try (PdfRenderer renderer = new PdfRenderer(descriptor)) {
                int pages = Math.min(renderer.getPageCount(), maximumPages);
                for (int index = 0; index < pages; index++) {
                    try (PdfRenderer.Page page = renderer.openPage(index)) {
                        int maximumWidth = maximumPages > 3 ? 2600 : 2200;
                        int width = Math.min(maximumWidth, Math.max(1400, page.getWidth() * 3));
                        int height = Math.max(1, Math.round(width * (page.getHeight() / (float) page.getWidth())));
                        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                        bitmap.eraseColor(Color.WHITE);
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                        String pageText = recognizeLatinBest(bitmap);
                        bitmap.recycle();
                        if (result.length() > 0) result.append('\n');
                        result.append(pageText);
                    }
                }
            }
        }
        return result.toString();
    }

    private String scanImageWithTesseract(Uri uri, String model) throws Exception {
        Bitmap bitmap = loadBitmap(uri);
        if (bitmap == null) throw new IllegalArgumentException("The selected image cannot be opened.");
        try {
            return recognizeWithTesseractBest(bitmap, model);
        } finally {
            bitmap.recycle();
        }
    }

    private String scanPdfWithTesseract(Uri uri, String model, int maximumPages) throws Exception {
        File dataRoot = ensureModel(model);
        TessBaseAPI api = new TessBaseAPI();
        if (!api.init(dataRoot.getAbsolutePath(), model, TessBaseAPI.OEM_LSTM_ONLY)) {
            api.recycle();
            throw new IllegalStateException("The local OCR model could not be initialized.");
        }
        api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO);
        api.setVariable("preserve_interword_spaces", "1");
        StringBuilder result = new StringBuilder();
        try (ParcelFileDescriptor descriptor = context.getContentResolver().openFileDescriptor(uri, "r")) {
            if (descriptor == null) throw new IllegalArgumentException("The selected PDF cannot be opened.");
            try (PdfRenderer renderer = new PdfRenderer(descriptor)) {
                int pages = Math.min(renderer.getPageCount(), maximumPages);
                for (int index = 0; index < pages; index++) {
                    Bitmap bitmap;
                    try (PdfRenderer.Page page = renderer.openPage(index)) {
                        int maximumWidth = maximumPages > 3 ? 2600 : 2200;
                        int width = Math.min(maximumWidth, Math.max(1400, page.getWidth() * 3));
                        int height = Math.max(1, Math.round(width * (page.getHeight() / (float) page.getWidth())));
                        bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                        bitmap.eraseColor(android.graphics.Color.WHITE);
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    }
                    String pageText = recognizeTesseractPageBest(api, bitmap);
                    bitmap.recycle();
                    if (result.length() > 0) result.append('\n');
                    if (pageText != null) result.append(pageText);
                }
            }
        } finally {
            api.recycle();
        }
        return result.toString();
    }

    private String recognizeWithTesseractBest(Bitmap bitmap, String model) throws Exception {
        File dataRoot = ensureModel(model);
        TessBaseAPI api = new TessBaseAPI();
        if (!api.init(dataRoot.getAbsolutePath(), model, TessBaseAPI.OEM_LSTM_ONLY)) {
            api.recycle();
            throw new IllegalStateException("The local OCR model could not be initialized.");
        }
        try {
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO);
            api.setVariable("preserve_interword_spaces", "1");
            return recognizeTesseractPageBest(api, bitmap);
        } finally {
            api.recycle();
        }
    }

    private String recognizeLatinBest(Bitmap bitmap) throws Exception {
        String original = Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0))).getText();
        if (OcrTextQuality.score(original) >= 120) return original;
        Bitmap enhanced = tryEnhanceForText(bitmap);
        if (enhanced == null) return original;
        try {
            String second = Tasks.await(recognizer.process(InputImage.fromBitmap(enhanced, 0))).getText();
            return OcrTextQuality.choose(original, second);
        } catch (Exception ignored) {
            return original;
        } finally {
            enhanced.recycle();
        }
    }

    private String recognizeTesseractPageBest(TessBaseAPI api, Bitmap bitmap) {
        api.setImage(bitmap);
        String original = api.getUTF8Text();
        api.clear();
        if (original == null) original = "";
        if (OcrTextQuality.score(original) >= 120) return original;
        Bitmap enhanced = tryEnhanceForText(bitmap);
        if (enhanced == null) return original;
        try {
            api.setImage(enhanced);
            String second = api.getUTF8Text();
            api.clear();
            return OcrTextQuality.choose(original, second);
        } finally {
            enhanced.recycle();
        }
    }

    private static Bitmap tryEnhanceForText(Bitmap source) {
        try {
            return enhanceForText(source);
        } catch (OutOfMemoryError ignored) {
            return null;
        }
    }

    private static Bitmap enhanceForText(Bitmap source) {
        int width = source.getWidth();
        int height = source.getHeight();
        Bitmap result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        float contrast = 1.7f;
        float offset = 128f * (1f - contrast);
        ColorMatrix matrix = new ColorMatrix(new float[]{
                0.30f * contrast, 0.59f * contrast, 0.11f * contrast, 0, offset,
                0.30f * contrast, 0.59f * contrast, 0.11f * contrast, 0, offset,
                0.30f * contrast, 0.59f * contrast, 0.11f * contrast, 0, offset,
                0, 0, 0, 1, 0
        });
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        paint.setColorFilter(new ColorMatrixColorFilter(matrix));
        Canvas canvas = new Canvas(result);
        canvas.drawColor(Color.WHITE);
        canvas.drawBitmap(source, 0, 0, paint);
        return result;
    }

    @SuppressWarnings("deprecation")
    private Bitmap loadBitmap(Uri uri) throws Exception {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.Source source = ImageDecoder.createSource(context.getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(source, (decoder, info, ignored) -> {
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                int width = info.getSize().getWidth();
                int height = info.getSize().getHeight();
                int largest = Math.max(width, height);
                if (largest > 2800) {
                    float scale = 2800f / largest;
                    decoder.setTargetSize(Math.max(1, Math.round(width * scale)), Math.max(1, Math.round(height * scale)));
                }
            });
        }
        return MediaStore.Images.Media.getBitmap(context.getContentResolver(), uri);
    }

    private File ensureModel(String model) throws Exception {
        File root = new File(context.getFilesDir(), "tesseract");
        File directory = new File(root, "tessdata");
        if (!directory.exists() && !directory.mkdirs()) throw new IllegalStateException("The OCR model directory could not be created.");
        File target = new File(directory, model + ".traineddata");
        if (target.isFile() && target.length() > 1_000_000) return root;
        File temporary = new File(directory, model + ".traineddata.tmp");
        try (InputStream input = context.getAssets().open("tessdata/" + model + ".traineddata");
             FileOutputStream output = new FileOutputStream(temporary)) {
            byte[] buffer = new byte[32 * 1024];
            int count;
            while ((count = input.read(buffer)) >= 0) output.write(buffer, 0, count);
            output.getFD().sync();
        }
        if (target.exists() && !target.delete()) throw new IllegalStateException("The OCR model could not be replaced.");
        if (!temporary.renameTo(target)) throw new IllegalStateException("The OCR model could not be installed.");
        return root;
    }

    @Override public void close() {
        executor.shutdownNow();
        recognizer.close();
    }
}
