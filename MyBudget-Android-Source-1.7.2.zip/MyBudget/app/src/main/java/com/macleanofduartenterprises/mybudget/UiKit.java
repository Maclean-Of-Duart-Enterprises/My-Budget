package com.macleanofduartenterprises.mybudget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class UiKit {
    private UiKit() {}

    public static int dp(Context context, float value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    public static TextView text(Context context, AppSettings settings, String value, float deltaSp, boolean bold) {
        TextView view = new TextView(context);
        view.setText(value);
        view.setTextColor(settings.textColor());
        view.setTextSize(Math.max(11f, settings.textSizeSp() + deltaSp));
        view.setTypeface(Typeface.create(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL));
        view.setLineSpacing(0, 1.12f);
        view.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        return view;
    }

    public static TextView heading(Context context, AppSettings settings, String value) {
        TextView view = text(context, settings, value, 5f, true);
        view.setPadding(0, dp(context, 4), 0, dp(context, 8));
        return view;
    }

    public static LinearLayout panel(Context context, AppSettings settings) {
        LinearLayout panel = new LinearLayout(context);
        panel.setOrientation(LinearLayout.VERTICAL);
        int padding = dp(context, 16);
        panel.setPadding(padding, padding, padding, padding);
        panel.setBackground(roundRect(settings.boxColor(), settings.boxOpacity(), dp(context, 18), 0, 0));
        panel.setElevation(dp(context, 2));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 0, dp(context, 12));
        panel.setLayoutParams(params);
        return panel;
    }

    public static Button primaryButton(Context context, String value) {
        Button button = baseButton(context, value);
        button.setTextColor(Color.WHITE);
        button.setBackground(roundRect(Color.rgb(22, 56, 46), 100, dp(context, 12), 0, 0));
        return button;
    }

    public static Button goldButton(Context context, String value) {
        Button button = baseButton(context, value);
        button.setTextColor(Color.rgb(13, 38, 31));
        button.setBackground(roundRect(Color.rgb(201, 167, 80), 100, dp(context, 12), 0, 0));
        return button;
    }

    public static Button secondaryButton(Context context, AppSettings settings, String value) {
        Button button = baseButton(context, value);
        button.setTextColor(settings.textColor());
        button.setBackground(roundRect(settings.boxColor(), Math.min(100, settings.boxOpacity()),
                dp(context, 12), Color.rgb(22, 56, 46), dp(context, 1)));
        return button;
    }

    public static EditText input(Context context, AppSettings settings, String hint) {
        EditText edit = new EditText(context);
        edit.setHint(hint);
        edit.setTextColor(settings.textColor());
        edit.setHintTextColor(withAlpha(settings.textColor(), 55));
        edit.setTextSize(settings.textSizeSp());
        edit.setSingleLine(true);
        edit.setPadding(dp(context, 12), dp(context, 8), dp(context, 12), dp(context, 8));
        edit.setBackground(roundRect(settings.boxColor(), 100, dp(context, 10),
                withAlpha(settings.textColor(), 35), dp(context, 1)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 52));
        params.setMargins(0, dp(context, 4), 0, dp(context, 10));
        edit.setLayoutParams(params);
        return edit;
    }

    public static EditText moneyInput(Context context, AppSettings settings, String hint) {
        EditText edit = input(context, settings, hint);
        edit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return edit;
    }

    public static TextView caption(Context context, AppSettings settings, String value) {
        TextView view = text(context, settings, value, -3f, false);
        view.setTextColor(withAlpha(settings.textColor(), 72));
        return view;
    }

    public static GradientDrawable roundRect(int color, int opacity, float radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(withAlpha(color, opacity));
        drawable.setCornerRadius(radius);
        if (strokeWidth > 0) drawable.setStroke(strokeWidth, strokeColor);
        return drawable;
    }

    public static int withAlpha(int color, int percent) {
        int alpha = Math.round(Math.max(0, Math.min(100, percent)) * 2.55f);
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    public static LinearLayout.LayoutParams weighted(float weight) {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
    }

    private static Button baseButton(Context context, String value) {
        Button button = new Button(context);
        button.setText(value);
        button.setAllCaps(false);
        button.setTextSize(15);
        button.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        button.setGravity(Gravity.CENTER);
        button.setMinHeight(dp(context, 48));
        button.setPadding(dp(context, 10), dp(context, 6), dp(context, 10), dp(context, 6));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, dp(context, 4), 0, dp(context, 6));
        button.setLayoutParams(params);
        return button;
    }
}
