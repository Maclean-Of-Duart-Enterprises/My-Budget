package com.macleanofduartenterprises.mybudget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

import java.util.Locale;

public final class AppSettings {
    private static final String FILE = "my_budget_settings";
    public static final int LOCK_MANUAL_ONLY = LockPolicy.MANUAL_ONLY;
    public static final int LOCK_IMMEDIATELY = LockPolicy.IMMEDIATELY;
    private final SharedPreferences preferences;

    public AppSettings(Context context) {
        preferences = context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public int backgroundColor() { return preferences.getInt("background_color", Color.rgb(246, 241, 230)); }
    public void setBackgroundColor(int value) { preferences.edit().putInt("background_color", value).apply(); }
    public int backgroundOpacity() { return clamp(preferences.getInt("background_opacity", 18)); }
    public void setBackgroundOpacity(int value) { preferences.edit().putInt("background_opacity", clamp(value)).apply(); }
    public String backgroundPath() { return preferences.getString("background_path", ""); }
    public void setBackgroundPath(String value) { preferences.edit().putString("background_path", safe(value)).apply(); }

    public int textColor() { return preferences.getInt("text_color", Color.rgb(19, 32, 27)); }
    public void setTextColor(int value) { preferences.edit().putInt("text_color", value).apply(); }
    public float textSizeSp() { return preferences.getFloat("text_size", 16f); }
    public void setTextSizeSp(float value) { preferences.edit().putFloat("text_size", Math.max(12f, Math.min(36f, value))).apply(); }

    public int boxColor() { return preferences.getInt("box_color", Color.WHITE); }
    public void setBoxColor(int value) { preferences.edit().putInt("box_color", value).apply(); }
    public int boxOpacity() { return clamp(preferences.getInt("box_opacity", 94)); }
    public void setBoxOpacity(int value) { preferences.edit().putInt("box_opacity", clamp(value)).apply(); }

    public String sortField() { return preferences.getString("sort_field", "timestamp"); }
    public void setSortField(String value) { preferences.edit().putString("sort_field", safe(value)).apply(); }
    public boolean sortAscending() { return preferences.getBoolean("sort_ascending", false); }
    public void setSortAscending(boolean value) { preferences.edit().putBoolean("sort_ascending", value).apply(); }

    /** ISO day-of-week value: Monday is 1 and Sunday is 7. */
    public int weekStartDay() { return Math.max(1, Math.min(7, preferences.getInt("week_start_day", 1))); }
    public void setWeekStartDay(int value) {
        preferences.edit().putInt("week_start_day", Math.max(1, Math.min(7, value))).apply();
    }

    public String languageCode() {
        return preferences.getString("language_code", LanguageManager.defaultCode(Locale.getDefault()));
    }
    public void setLanguageCode(String value) {
        preferences.edit().putString("language_code", LanguageManager.codeAt(LanguageManager.indexOf(value))).apply();
    }

    public String avatarPath() { return preferences.getString("avatar_path", ""); }
    public void setAvatarPath(String value) { preferences.edit().putString("avatar_path", safe(value)).apply(); }

    /** Zero means manual-only; -1 means immediately after leaving the foreground. */
    public int lockTimeoutSeconds() { return preferences.getInt("lock_timeout_seconds", LOCK_MANUAL_ONLY); }
    public void setLockTimeoutSeconds(int value) { preferences.edit().putInt("lock_timeout_seconds", value).apply(); }

    public void resetAppearance() {
        preferences.edit()
                .remove("background_color").remove("background_opacity").remove("background_path")
                .remove("text_color").remove("text_size").remove("box_color").remove("box_opacity")
                .apply();
    }

    private static String safe(String value) { return value == null ? "" : value; }
    private static int clamp(int value) { return Math.max(1, Math.min(100, value)); }
}
