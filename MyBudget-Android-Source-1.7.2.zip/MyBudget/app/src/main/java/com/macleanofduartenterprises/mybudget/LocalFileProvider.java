package com.macleanofduartenterprises.mybudget;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Minimal app-private content provider for camera output and user-initiated exports. */
public final class LocalFileProvider extends ContentProvider {
    private static final String[] DEFAULT_COLUMNS = {OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};

    public static Uri getUriForFile(Context context, File file) {
        try {
            String canonical = file.getCanonicalPath();
            Map<String, File> roots = roots(context);
            String bestName = null;
            File bestRoot = null;
            for (Map.Entry<String, File> entry : roots.entrySet()) {
                String rootPath = entry.getValue().getCanonicalPath();
                if (canonical.startsWith(rootPath + File.separator)
                        && (bestRoot == null || rootPath.length() > bestRoot.getCanonicalPath().length())) {
                    bestName = entry.getKey();
                    bestRoot = entry.getValue();
                }
            }
            if (bestRoot == null) throw new IllegalArgumentException("File is outside an approved sharing directory.");
            String relative = canonical.substring(bestRoot.getCanonicalPath().length() + 1);
            return new Uri.Builder().scheme("content").authority(context.getPackageName() + ".files")
                    .appendPath(bestName).appendPath(relative).build();
        } catch (Exception error) {
            throw new IllegalArgumentException("Unable to share this file.", error);
        }
    }

    @Override public boolean onCreate() { return true; }

    @Override public String getType(Uri uri) {
        String name = uri.getLastPathSegment();
        if (name == null) return "application/octet-stream";
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".pdf")) return "application/pdf";
        if (lower.endsWith(".csv")) return "text/csv";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        return "application/octet-stream";
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection,
                                  String[] selectionArgs, String sortOrder) {
        File file = resolve(uri);
        String[] columns = projection == null ? DEFAULT_COLUMNS : projection;
        MatrixCursor cursor = new MatrixCursor(columns, 1);
        Object[] row = new Object[columns.length];
        for (int i = 0; i < columns.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(columns[i])) row[i] = file.getName();
            else if (OpenableColumns.SIZE.equals(columns[i])) row[i] = file.length();
            else row[i] = null;
        }
        cursor.addRow(row);
        return cursor;
    }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File file = resolve(uri);
        int flags;
        if ("w".equals(mode) || "wt".equals(mode)) flags = ParcelFileDescriptor.MODE_WRITE_ONLY | ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE;
        else if ("rw".equals(mode) || "rwt".equals(mode)) flags = ParcelFileDescriptor.MODE_READ_WRITE | ParcelFileDescriptor.MODE_CREATE;
        else flags = ParcelFileDescriptor.MODE_READ_ONLY;
        return ParcelFileDescriptor.open(file, flags);
    }

    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return resolve(uri).delete() ? 1 : 0; }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { throw new UnsupportedOperationException(); }

    private File resolve(Uri uri) {
        Context context = getContext();
        if (context == null || uri.getPathSegments().size() < 2) throw new IllegalArgumentException("Invalid file URI.");
        String rootName = uri.getPathSegments().get(0);
        File root = roots(context).get(rootName);
        if (root == null) throw new IllegalArgumentException("Unknown file root.");
        StringBuilder relative = new StringBuilder();
        for (int i = 1; i < uri.getPathSegments().size(); i++) {
            if (relative.length() > 0) relative.append(File.separator);
            relative.append(uri.getPathSegments().get(i));
        }
        try {
            File target = new File(root, relative.toString()).getCanonicalFile();
            if (!target.getPath().startsWith(root.getCanonicalPath() + File.separator)) throw new SecurityException("Path traversal rejected.");
            return target;
        } catch (Exception error) {
            throw new IllegalArgumentException("Invalid file path.", error);
        }
    }

    private static Map<String, File> roots(Context context) {
        Map<String, File> roots = new HashMap<>();
        roots.put("camera", new File(context.getCacheDir(), "camera"));
        roots.put("view", new File(context.getCacheDir(), "view"));
        roots.put("exports", new File(context.getFilesDir(), "exports"));
        File reports = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        if (reports != null) roots.put("reports", reports);
        return roots;
    }
}
