package com.macleanofduartenterprises.mybudget;

import java.util.ArrayList;
import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * A deterministic, on-device learning agent. It uses recent history, category trends,
 * recurring-charge detection, and outlier checks. No transaction data leaves the phone.
 */
public final class BudgetAgent {
    private static final long DAY = 86_400_000L;
    private static final Set<String> DEFAULT_ESSENTIAL = new HashSet<>(Arrays.asList(
            "Housing", "Utilities", "Groceries", "Transportation", "Healthcare",
            "Insurance", "Debt", "Childcare", "Household"
    ));
    private final LanguageManager language;
    private final Set<String> essentialCategories;

    public BudgetAgent() { this(new LanguageManager(LanguageManager.ENGLISH)); }

    public BudgetAgent(LanguageManager language) {
        this(language, DEFAULT_ESSENTIAL);
    }

    public BudgetAgent(LanguageManager language, Set<String> essentialCategories) {
        this.language = language == null ? new LanguageManager(LanguageManager.ENGLISH) : language;
        this.essentialCategories = new HashSet<>(essentialCategories == null
                ? DEFAULT_ESSENTIAL : essentialCategories);
    }

    public BudgetPlan createPlan(List<TransactionRecord> all, long now) {
        return createPlan(all, now, BudgetPeriod.MONTHLY);
    }

    public BudgetPlan createPlan(List<TransactionRecord> all, long now, String requestedPeriod) {
        BudgetPlan monthly = createMonthlyPlan(all, now);
        return BudgetPeriod.isWeekly(requestedPeriod) ? weeklyFromMonthly(monthly) : monthly;
    }

    public BudgetPlan createCategoryPlan(List<TransactionRecord> all, long now, String requestedPeriod,
                                         String type, String category) {
        TransactionHistoryAnalyzer.Result history = new TransactionHistoryAnalyzer().analyze(all);
        List<TransactionRecord> selected = new ArrayList<>();
        for (TransactionRecord record : history.analysisRecords) {
            if (matchesFilter(record, type, category)) selected.add(record);
        }
        BudgetPlan plan = createPlan(selected, now, requestedPeriod);
        if (TransactionRecord.INCOME.equals(type)) plan.savingsTarget = 0;
        return plan;
    }

    private BudgetPlan createMonthlyPlan(List<TransactionRecord> all, long now) {
        BudgetPlan plan = new BudgetPlan();
        plan.period = BudgetPeriod.MONTHLY;
        plan.generatedAt = now;
        TransactionHistoryAnalyzer.Result history = new TransactionHistoryAnalyzer().analyze(all);
        plan.accountCount = history.accountCount;
        plan.excludedTransferCount = history.excludedRecordCount;
        plan.duplicateCount = history.duplicateCount;
        long cutoff = now - 120L * DAY;
        List<TransactionRecord> recent = new ArrayList<>();
        long earliest = now;
        for (TransactionRecord record : history.analysisRecords) {
            if (record.timestamp >= cutoff && record.timestamp <= now && record.amountCents > 0) {
                recent.add(record);
                earliest = Math.min(earliest, record.timestamp);
            }
        }
        if (recent.isEmpty()) {
            plan.confidencePercent = 0;
            plan.insights.add(language.t("Add income and expense transactions to create your first learned budget."));
            return plan;
        }

        plan.historyDays = Math.max(1, (int) ((now - earliest) / DAY) + 1);
        double observedMonths = Math.max(1.0, plan.historyDays / 30.4375);
        long incomeTotal = 0;
        Map<String, Long> expenseTotals = new HashMap<>();
        Map<String, List<TransactionRecord>> expenseRecords = new HashMap<>();
        for (TransactionRecord record : recent) {
            if (TransactionRecord.DOCUMENT_BANK_STATEMENT.equals(record.documentKind)) {
                plan.statementTransactionCount++;
            }
            if (TransactionRecord.INCOME.equals(record.type)) incomeTotal += record.amountCents;
            else {
                expenseTotals.merge(record.category, record.amountCents, Long::sum);
                expenseRecords.computeIfAbsent(record.category, ignored -> new ArrayList<>()).add(record);
            }
        }

        plan.expectedMonthlyIncome = Math.round(incomeTotal / observedMonths);
        List<Map.Entry<String, Long>> limits = new ArrayList<>();
        for (Map.Entry<String, Long> entry : expenseTotals.entrySet()) {
            long monthlyAverage = Math.round(entry.getValue() / observedMonths);
            double trend = recentTrendMultiplier(expenseRecords.get(entry.getKey()), now);
            double cushion = essentialCategories.contains(entry.getKey()) ? 1.04 : 0.92;
            long learnedLimit = roundToFiveDollars(Math.round(monthlyAverage * trend * cushion));
            if (learnedLimit > 0) limits.add(new AbstractMap.SimpleImmutableEntry<>(entry.getKey(), learnedLimit));
        }
        limits.sort(Map.Entry.<String, Long>comparingByValue().reversed());
        long learnedExpenses = 0;
        for (Map.Entry<String, Long> entry : limits) learnedExpenses += entry.getValue();
        plan.expectedMonthlyExpenses = learnedExpenses;

        long minimumSavings = plan.expectedMonthlyIncome > 0 ? Math.round(plan.expectedMonthlyIncome * 0.10) : 0;
        long spendable = Math.max(0, plan.expectedMonthlyIncome - minimumSavings);
        double scale = learnedExpenses > 0 && spendable > 0 && learnedExpenses > spendable
                ? (double) spendable / learnedExpenses : 1.0;
        for (Map.Entry<String, Long> entry : limits) {
            long value = scale < 1.0 ? roundToFiveDollars(Math.round(entry.getValue() * scale)) : entry.getValue();
            plan.categoryLimits.put(entry.getKey(), Math.max(500, value));
        }
        plan.expectedMonthlyExpenses = plan.totalAllocated();
        plan.savingsTarget = Math.max(0, plan.expectedMonthlyIncome - plan.expectedMonthlyExpenses);
        if (plan.expectedMonthlyIncome > 0) plan.savingsTarget = Math.max(minimumSavings, plan.savingsTarget);

        int confidence = 10 + Math.min(50, plan.historyDays / 2) + Math.min(35, recent.size());
        plan.confidencePercent = Math.min(95, confidence);

        if (plan.historyDays < 30) {
            plan.insights.add(language.t("This is an early estimate. Accuracy improves after a full month of history."));
        }
        if (scale < 1.0) {
            plan.insights.add(language.t("Recent spending was above learned income, so category limits were scaled to protect a 10% savings reserve."));
        } else if (plan.expectedMonthlyIncome > 0) {
            int rate = (int) Math.round(plan.savingsTarget * 100.0 / plan.expectedMonthlyIncome);
            plan.insights.add(language.t("The learned plan leaves about %d%% of expected income unspent.", rate));
        } else {
            plan.insights.add(language.t("Add income records so the agent can balance spending limits against take-home pay."));
        }

        if (plan.statementTransactionCount > 0) {
            plan.insights.add(language.t("This plan uses %d reviewed transactions imported from bank statements.",
                    plan.statementTransactionCount));
        }
        if (plan.accountCount > 1) {
            plan.insights.add(language.t("The agent combined transaction history from %d bank accounts.",
                    plan.accountCount));
        }
        if (plan.excludedTransferCount > 0) {
            plan.insights.add(language.t("%d internal-transfer or excluded entries were left out of income and expense calculations.",
                    plan.excludedTransferCount));
        }
        if (plan.duplicateCount > 0) {
            plan.insights.add(language.t("%d duplicate statement entries were ignored.", plan.duplicateCount));
        }

        List<String> recurring = recurringMerchants(recent);
        if (!recurring.isEmpty()) {
            plan.insights.add(language.t("Likely recurring charges: %s.", String.join(", ", recurring)));
        }
        return plan;
    }

    public PeriodReport createReport(List<TransactionRecord> all, long start, long end, String title) {
        return createReport(all, start, end, title, "", "");
    }

    public PeriodReport createCategoryReport(List<TransactionRecord> all, long start, long end,
                                             String title, String type, String category) {
        return createReport(all, start, end, title, type, category);
    }

    private PeriodReport createReport(List<TransactionRecord> all, long start, long end, String title,
                                      String filterType, String filterCategory) {
        PeriodReport report = new PeriodReport();
        report.title = title;
        report.filterType = filterType == null ? "" : filterType;
        report.filterCategory = filterCategory == null ? "" : filterCategory;
        report.start = start;
        report.end = end;
        long duration = end - start;
        long previousStart = start - duration;
        Map<String, List<Long>> categoryAmounts = new HashMap<>();
        TransactionHistoryAnalyzer.Result history = new TransactionHistoryAnalyzer().analyze(all);
        report.duplicateCount = history.duplicateCount;
        Set<String> periodAccounts = new HashSet<>();
        for (TransactionRecord excluded : history.excludedRecords) {
            if (matchesFilter(excluded, report.filterType, report.filterCategory)
                    && excluded.timestamp >= start && excluded.timestamp < end) {
                report.excludedTransferCount++;
            }
        }
        for (TransactionRecord record : history.analysisRecords) {
            if (!matchesFilter(record, report.filterType, report.filterCategory)) continue;
            if (record.timestamp >= previousStart && record.timestamp < start
                    && TransactionRecord.EXPENSE.equals(record.type)) {
                report.previousExpenses += record.amountCents;
            }
            if (record.timestamp < start || record.timestamp >= end) continue;
            report.transactionCount++;
            if (TransactionRecord.DOCUMENT_BANK_STATEMENT.equals(record.documentKind)) {
                report.statementTransactionCount++;
            }
            if (record.accountId != null && !record.accountId.isEmpty()) periodAccounts.add(record.accountId);
            if (TransactionRecord.INCOME.equals(record.type)) report.income += record.amountCents;
            else {
                report.expenses += record.amountCents;
                report.spendingByCategory.merge(record.category, record.amountCents, Long::sum);
                categoryAmounts.computeIfAbsent(record.category, ignored -> new ArrayList<>()).add(record.amountCents);
            }
        }
        report.accountCount = periodAccounts.size();
        report.net = report.income - report.expenses;
        if (report.previousExpenses > 0) {
            report.expenseChangePercent = (int) Math.round((report.expenses - report.previousExpenses) * 100.0 / report.previousExpenses);
        }
        if (report.income > 0) report.savingsRatePercent = (int) Math.round(report.net * 100.0 / report.income);

        Map<String, Long> sortedCategories = sortDescending(report.spendingByCategory);
        report.spendingByCategory.clear();
        report.spendingByCategory.putAll(sortedCategories);
        if (report.transactionCount == 0) {
            report.insights.add(language.t("No transactions were recorded in this period."));
            return report;
        }
        if (report.filterCategory.isEmpty() && !report.spendingByCategory.isEmpty()) {
            Map.Entry<String, Long> top = report.spendingByCategory.entrySet().iterator().next();
            int share = report.expenses == 0 ? 0 : (int) Math.round(top.getValue() * 100.0 / report.expenses);
            report.insights.add(language.t("%1$s was the largest expense category at %2$d%% of spending.",
                    language.category(top.getKey()), share));
        }
        if (report.previousExpenses > 0) {
            report.insights.add(language.t(report.expenseChangePercent >= 0
                            ? "Spending increased %d%% compared with the prior period."
                            : "Spending decreased %d%% compared with the prior period.",
                    Math.abs(report.expenseChangePercent)));
        }
        if (report.filterCategory.isEmpty() && report.income > 0) {
            if (report.net >= 0) report.insights.add(language.t("You kept %d%% of recorded income this period.", report.savingsRatePercent));
            else report.insights.add(language.t("Expenses exceeded recorded income by %s.", Money.format(-report.net)));
        }
        if (report.accountCount > 1) {
            report.insights.add(language.t("This report combines activity from %d bank accounts.",
                    report.accountCount));
        }
        if (report.excludedTransferCount > 0) {
            report.insights.add(language.t("%d internal-transfer or excluded entries were not counted as income or expenses.",
                    report.excludedTransferCount));
        }
        findAnomalies(history.analysisRecords, start, end, categoryAmounts, report.anomalies);
        return report;
    }

    private static BudgetPlan weeklyFromMonthly(BudgetPlan monthly) {
        BudgetPlan weekly = new BudgetPlan();
        weekly.period = BudgetPeriod.WEEKLY;
        weekly.generatedAt = monthly.generatedAt;
        weekly.confidencePercent = monthly.confidencePercent;
        weekly.historyDays = monthly.historyDays;
        weekly.statementTransactionCount = monthly.statementTransactionCount;
        weekly.accountCount = monthly.accountCount;
        weekly.excludedTransferCount = monthly.excludedTransferCount;
        weekly.duplicateCount = monthly.duplicateCount;
        weekly.insights.addAll(monthly.insights);
        weekly.expectedMonthlyIncome = scaleMonthlyToWeekly(monthly.expectedMonthlyIncome);
        for (Map.Entry<String, Long> entry : monthly.categoryLimits.entrySet()) {
            long value = scaleMonthlyToWeekly(entry.getValue());
            if (value > 0) weekly.categoryLimits.put(entry.getKey(), value);
        }
        weekly.expectedMonthlyExpenses = weekly.totalAllocated();
        weekly.savingsTarget = Math.max(0, weekly.expectedMonthlyIncome - weekly.expectedMonthlyExpenses);
        return weekly;
    }

    private static long scaleMonthlyToWeekly(long monthlyCents) {
        if (monthlyCents <= 0) return 0;
        return Math.max(500, roundToFiveDollars(Math.round(monthlyCents * 12.0 / 52.0)));
    }

    private static boolean matchesFilter(TransactionRecord record, String type, String category) {
        if (record == null) return false;
        String cleanCategory = category == null ? "" : category.trim();
        if (cleanCategory.isEmpty()) return true;
        String cleanType = TransactionRecord.INCOME.equals(type)
                ? TransactionRecord.INCOME : TransactionRecord.EXPENSE;
        return cleanType.equals(record.type) && record.category != null
                && record.category.equalsIgnoreCase(cleanCategory);
    }

    private static double recentTrendMultiplier(List<TransactionRecord> records, long now) {
        if (records == null || records.size() < 2) return 1.0;
        long last30 = 0;
        long prior30 = 0;
        for (TransactionRecord record : records) {
            if (record.timestamp >= now - 30L * DAY) last30 += record.amountCents;
            else if (record.timestamp >= now - 60L * DAY) prior30 += record.amountCents;
        }
        if (prior30 == 0) return 1.0;
        double ratio = (double) last30 / prior30;
        return Math.max(0.85, Math.min(1.20, 0.75 + ratio * 0.25));
    }

    private static List<String> recurringMerchants(List<TransactionRecord> records) {
        Map<String, List<TransactionRecord>> groups = new HashMap<>();
        for (TransactionRecord record : records) {
            if (TransactionRecord.EXPENSE.equals(record.type) && !record.merchant.trim().isEmpty()) {
                groups.computeIfAbsent(record.merchant.trim(), ignored -> new ArrayList<>()).add(record);
            }
        }
        List<String> result = new ArrayList<>();
        for (Map.Entry<String, List<TransactionRecord>> entry : groups.entrySet()) {
            List<TransactionRecord> values = entry.getValue();
            if (values.size() < 2) continue;
            double average = values.stream().mapToLong(value -> value.amountCents).average().orElse(0);
            boolean stable = average > 0;
            for (TransactionRecord value : values) {
                if (Math.abs(value.amountCents - average) / average > 0.18) stable = false;
            }
            if (stable) result.add(entry.getKey());
        }
        Collections.sort(result);
        if (result.size() > 4) return new ArrayList<>(result.subList(0, 4));
        return result;
    }

    private void findAnomalies(List<TransactionRecord> all, long start, long end,
                               Map<String, List<Long>> categoryAmounts, List<String> output) {
        for (Map.Entry<String, List<Long>> entry : categoryAmounts.entrySet()) {
            List<Long> amounts = entry.getValue();
            if (amounts.size() < 3) continue;
            amounts.sort(Long::compareTo);
            long median = amounts.get(amounts.size() / 2);
            for (TransactionRecord record : all) {
                if (record.timestamp >= start && record.timestamp < end
                        && TransactionRecord.EXPENSE.equals(record.type)
                        && entry.getKey().equals(record.category)
                        && record.amountCents > Math.max(5_000, median * 2)) {
                    output.add(language.t("%1$s was unusually high at %2$s.",
                            record.merchant.isEmpty() ? language.category(record.category) : record.merchant,
                            Money.format(record.amountCents)));
                    if (output.size() == 3) return;
                }
            }
        }
    }

    private static Map<String, Long> sortDescending(Map<String, Long> input) {
        List<Map.Entry<String, Long>> entries = new ArrayList<>(input.entrySet());
        entries.sort(Map.Entry.<String, Long>comparingByValue(Comparator.reverseOrder()));
        Map<String, Long> sorted = new LinkedHashMap<>();
        for (Map.Entry<String, Long> entry : entries) sorted.put(entry.getKey(), entry.getValue());
        return sorted;
    }

    private static long roundToFiveDollars(long cents) {
        return Math.max(0, Math.round(cents / 500.0) * 500L);
    }
}
