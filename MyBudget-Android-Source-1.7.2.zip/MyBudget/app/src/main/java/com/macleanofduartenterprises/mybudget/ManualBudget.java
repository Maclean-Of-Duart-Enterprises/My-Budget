package com.macleanofduartenterprises.mybudget;

import java.util.LinkedHashMap;
import java.util.Map;

/** A user-controlled monthly budget kept separately from the learned AI plan. */
public final class ManualBudget {
    public final Map<String, Long> categoryLimits = new LinkedHashMap<>();
    public long expectedMonthlyIncome;
    public long savingsTarget;
    public long updatedAt;

    public long totalAllocated() {
        long total = 0;
        for (long amount : categoryLimits.values()) total += Math.max(0, amount);
        return total;
    }

    public boolean isConfigured() {
        return updatedAt > 0 || expectedMonthlyIncome > 0 || savingsTarget > 0 || !categoryLimits.isEmpty();
    }

    public long plannedRemainder() {
        return expectedMonthlyIncome - totalAllocated() - savingsTarget;
    }

    public ManualBudget copy() {
        ManualBudget result = new ManualBudget();
        result.expectedMonthlyIncome = expectedMonthlyIncome;
        result.savingsTarget = savingsTarget;
        result.updatedAt = updatedAt;
        result.categoryLimits.putAll(categoryLimits);
        return result;
    }
}
