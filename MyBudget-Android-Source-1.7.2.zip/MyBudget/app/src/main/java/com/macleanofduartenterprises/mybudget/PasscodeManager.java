package com.macleanofduartenterprises.mybudget;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class PasscodeManager {
    private static final int ITERATIONS = 150_000;
    private final SharedPreferences preferences;

    public PasscodeManager(Context context) {
        preferences = context.getSharedPreferences("my_budget_security", Context.MODE_PRIVATE);
    }

    public boolean hasPasscode() {
        return preferences.contains("passcode_hash") && preferences.contains("passcode_salt");
    }

    public boolean setPasscode(String passcode) {
        if (!isValid(passcode)) return false;
        try {
            byte[] salt = new byte[24];
            new SecureRandom().nextBytes(salt);
            byte[] hash = derive(passcode, salt);
            preferences.edit()
                    .putString("passcode_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                    .putString("passcode_hash", Base64.encodeToString(hash, Base64.NO_WRAP))
                    .apply();
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    public boolean verify(String passcode) {
        if (!hasPasscode()) return true;
        try {
            byte[] salt = Base64.decode(preferences.getString("passcode_salt", ""), Base64.NO_WRAP);
            byte[] expected = Base64.decode(preferences.getString("passcode_hash", ""), Base64.NO_WRAP);
            return MessageDigest.isEqual(expected, derive(passcode, salt));
        } catch (Exception ignored) {
            return false;
        }
    }

    public void disable() {
        preferences.edit().remove("passcode_salt").remove("passcode_hash").apply();
    }

    public static boolean isValid(String passcode) {
        return passcode != null && passcode.matches("[0-9]{4,12}");
    }

    private byte[] derive(String passcode, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(passcode.toCharArray(), salt, ITERATIONS, 256);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } finally {
            spec.clearPassword();
        }
    }
}
