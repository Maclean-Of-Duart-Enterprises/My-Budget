package com.macleanofduartenterprises.mybudget;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Stores each user's complete, ordered income and expense category lists locally. */
public final class CategoryStore {
    private static final String FILE = "budget_categories";
    private static final String CUSTOM_EXPENSE = "custom_expense";
    private static final String CUSTOM_INCOME = "custom_income";
    private static final String ORDER_EXPENSE = "order_expense_v2";
    private static final String ORDER_INCOME = "order_income_v2";
    private static final String ALIASES_EXPENSE = "aliases_expense_v2";
    private static final String ALIASES_INCOME = "aliases_income_v2";
    private static final List<String> ESSENTIAL_EXPENSES = Arrays.asList(
            "Housing", "Utilities", "Groceries", "Transportation", "Healthcare",
            "Insurance", "Debt", "Childcare", "Household"
    );
    public static final int MAXIMUM_NAME_LENGTH = 48;

    private final SharedPreferences preferences;

    public CategoryStore(Context context) {
        preferences = context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public List<String> categories(String type) {
        return catalog(type).categories();
    }

    public boolean add(String type, String value) {
        CategoryCatalog catalog = catalog(type);
        if (!catalog.add(value)) return false;
        save(type, catalog);
        return true;
    }

    public boolean rename(String type, String oldValue, String newValue) {
        CategoryCatalog catalog = catalog(type);
        if (!catalog.rename(oldValue, newValue)) return false;
        save(type, catalog);
        return true;
    }

    public boolean remove(String type, String value, String replacement) {
        CategoryCatalog catalog = catalog(type);
        if (!catalog.remove(value, replacement)) return false;
        save(type, catalog);
        return true;
    }

    public boolean move(String type, String value, int direction) {
        CategoryCatalog catalog = catalog(type);
        if (!catalog.move(value, direction)) return false;
        save(type, catalog);
        return true;
    }

    /** Maps built-in OCR/parser suggestions to the user's current category names. */
    public String resolve(String type, String suggested) {
        return catalog(type).resolve(suggested);
    }

    public String removalFallback(String type, String value) {
        return catalog(type).fallbackFor(value);
    }

    /** Preserves the AI safety cushion when an original essential category is renamed. */
    public Set<String> essentialExpenseCategories() {
        return catalog(TransactionRecord.EXPENSE).mappedCategories(ESSENTIAL_EXPENSES);
    }

    public static boolean isValidName(String value) {
        String clean = clean(value);
        return !clean.isEmpty() && clean.length() <= MAXIMUM_NAME_LENGTH
                && clean.indexOf('\n') < 0 && clean.indexOf('\r') < 0;
    }

    private static List<String> builtIns(String type) {
        return TransactionRecord.INCOME.equals(type)
                ? TransactionRecord.INCOME_CATEGORIES : TransactionRecord.EXPENSE_CATEGORIES;
    }

    private CategoryCatalog catalog(String type) {
        boolean stored = preferences.contains(orderKey(type));
        List<String> order = stored ? decodeList(preferences.getString(orderKey(type), "")) : null;
        return new CategoryCatalog(builtIns(type), order, legacyCustom(type),
                decodeMap(preferences.getString(aliasKey(type), "")));
    }

    private List<String> legacyCustom(String type) {
        Set<String> stored = preferences.getStringSet(legacyKey(type), Collections.emptySet());
        List<String> result = new ArrayList<>();
        if (stored != null) result.addAll(stored);
        return result;
    }

    private void save(String type, CategoryCatalog catalog) {
        preferences.edit()
                .putString(orderKey(type), encodeList(catalog.categories()))
                .putString(aliasKey(type), encodeMap(catalog.aliases()))
                .remove(legacyKey(type))
                .apply();
    }

    private static String legacyKey(String type) {
        return TransactionRecord.INCOME.equals(type) ? CUSTOM_INCOME : CUSTOM_EXPENSE;
    }

    private static String orderKey(String type) {
        return TransactionRecord.INCOME.equals(type) ? ORDER_INCOME : ORDER_EXPENSE;
    }

    private static String aliasKey(String type) {
        return TransactionRecord.INCOME.equals(type) ? ALIASES_INCOME : ALIASES_EXPENSE;
    }

    private static String encodeList(List<String> values) {
        JSONArray array = new JSONArray();
        for (String value : values) array.put(value);
        return array.toString();
    }

    private static List<String> decodeList(String raw) {
        List<String> result = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(raw == null || raw.isEmpty() ? "[]" : raw);
            for (int index = 0; index < array.length(); index++) {
                String value = clean(array.optString(index, ""));
                if (isValidName(value)) result.add(value);
            }
        } catch (Exception ignored) {
            // A corrupt preference safely falls back to the original lists.
        }
        return result;
    }

    private static String encodeMap(Map<String, String> values) {
        JSONObject object = new JSONObject();
        for (Map.Entry<String, String> entry : values.entrySet()) {
            try { object.put(entry.getKey(), entry.getValue()); }
            catch (Exception ignored) { }
        }
        return object.toString();
    }

    private static Map<String, String> decodeMap(String raw) {
        Map<String, String> result = new LinkedHashMap<>();
        try {
            JSONObject object = new JSONObject(raw == null || raw.isEmpty() ? "{}" : raw);
            Iterator<String> keys = object.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                String value = clean(object.optString(key, ""));
                if (isValidName(key) && isValidName(value)) result.put(key, value);
            }
        } catch (Exception ignored) {
            // Missing aliases are reconstructed from the stored list.
        }
        return result;
    }

    private static String clean(String value) {
        if (value == null) return "";
        return value.trim().replaceAll("\\s+", " ");
    }
}
