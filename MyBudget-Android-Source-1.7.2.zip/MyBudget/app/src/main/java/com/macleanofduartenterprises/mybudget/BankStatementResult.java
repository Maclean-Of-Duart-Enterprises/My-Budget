package com.macleanofduartenterprises.mybudget;

import java.util.ArrayList;
import java.util.List;

public final class BankStatementResult {
    public final List<BankStatementEntry> entries = new ArrayList<>();
    public final List<String> warnings = new ArrayList<>();
    public String bankName = "Bank";
    public String accountName = "Imported account";
    public String accountId = BankAccountIdentity.stableId("Bank", "Imported account");
    public long periodStart;
    public long periodEnd;
    public long incomeCents;
    public long expenseCents;

    public void setAccount(String bank, String account) {
        BankAccountIdentity identity = new BankAccountIdentity();
        identity.update(bank, account);
        bankName = identity.bankName;
        accountName = identity.accountName;
        accountId = identity.accountId;
        refreshFingerprints();
    }

    public void refreshFingerprints() {
        for (BankStatementEntry entry : entries) {
            entry.sourceFingerprint = BankAccountIdentity.transactionFingerprint(accountId,
                    entry.timestamp, entry.type, entry.amountCents, entry.description);
        }
    }

    public void recalculateTotals() {
        incomeCents = 0;
        expenseCents = 0;
        for (BankStatementEntry entry : entries) {
            if (!entry.selected || entry.duplicate || entry.excludeFromBudget) continue;
            if (TransactionRecord.INCOME.equals(entry.type)) incomeCents += entry.amountCents;
            else expenseCents += entry.amountCents;
        }
    }
}
