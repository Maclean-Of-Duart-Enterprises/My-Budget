package com.macleanofduartenterprises.mybudget;

public final class BankStatementEntry {
    public boolean selected = true;
    public long timestamp;
    public String description = "";
    public String type = TransactionRecord.EXPENSE;
    public String category = "Other";
    public long amountCents;
    public int confidencePercent;
    public String sourceLine = "";
    public String sourceFingerprint = "";
    public boolean duplicate;
    public boolean excludeFromBudget;
}
