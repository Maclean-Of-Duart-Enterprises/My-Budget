package com.macleanofduartenterprises.mybudget;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class BudgetPlan {
    public String period = BudgetPeriod.MONTHLY;
    public final Map<String, Long> categoryLimits = new LinkedHashMap<>();
    public final List<String> insights = new ArrayList<>();
    public long expectedMonthlyIncome;
    public long expectedMonthlyExpenses;
    public long savingsTarget;
    public int confidencePercent;
    public int historyDays;
    public int statementTransactionCount;
    public int accountCount;
    public int excludedTransferCount;
    public int duplicateCount;
    public long generatedAt;

    public long totalAllocated() {
        long total = 0;
        for (long amount : categoryLimits.values()) total += amount;
        return total;
    }
}
