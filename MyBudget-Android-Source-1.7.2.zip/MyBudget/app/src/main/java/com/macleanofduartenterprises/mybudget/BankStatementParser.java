package com.macleanofduartenterprises.mybudget;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Conservative, line-oriented parser for printed bank statements. It deliberately imports only
 * rows that contain both a recognizable date and a decimal monetary amount. Every proposed row is
 * presented to the user for review before it is saved.
 */
public final class BankStatementParser {
    private static final int MAX_ENTRIES = 250;
    private static final Pattern DATE_AT_START = Pattern.compile(
            "^\\s*(?:(\\d{4})[-/.](\\d{1,2})[-/.](\\d{1,2})|(\\d{1,2})[-/.](\\d{1,2})(?:[-/.](\\d{2,4}))?)\\b");
    private static final Pattern MONTH_FIRST_AT_START = Pattern.compile(
            "(?iu)^\\s*([\\p{L}.]{3,12})\\s+(\\d{1,2})(?:,)?(?:\\s+(\\d{2,4}))?\\b");
    private static final Pattern DAY_FIRST_MONTH_AT_START = Pattern.compile(
            "(?iu)^\\s*(\\d{1,2})\\s+([\\p{L}.]{3,12})(?:\\s+(\\d{2,4}))?\\b");
    private static final Pattern NUMERIC_OCR_TOKEN = Pattern.compile(
            "(?iu)(?<!\\p{L})([0-9OIlSB][0-9OIlSB ,.'’\\u00A0/-]{2,})(?!\\p{L})");
    private static final Pattern YEAR = Pattern.compile("\\b((?:19|20)\\d{2})\\b");
    private static final Pattern MONEY = Pattern.compile(
            "(?<![\\p{L}\\d])([(+\\-−]?\\s*(?:[$€₸₴₽£]\\s*)?\\d{1,3}(?:[ ,.'’\\u00A0]\\d{3})*(?:[.,]\\d{2})\\s*\\)?)(?!\\d)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern DR_CR = Pattern.compile("(?i)(?<!\\p{L})(DR|CR)(?!\\p{L})");
    private static final Map<String, Integer> MONTHS = monthNames();

    public BankStatementResult parse(String text, long fallbackDate, String languageCode) {
        BankStatementResult result = new BankStatementResult();
        String original = text == null ? "" : text;
        BankAccountIdentity identity = BankAccountIdentity.detect(original);
        result.bankName = identity.bankName;
        result.accountName = identity.accountName;
        result.accountId = identity.accountId;
        String source = normalizeNumericOcr(original);
        if (source.trim().isEmpty()) {
            result.warnings.add("No readable text was found.");
            return result;
        }

        int fallbackYear = java.time.Instant.ofEpochMilli(fallbackDate)
                .atZone(ZoneId.systemDefault()).getYear();
        Matcher yearMatcher = YEAR.matcher(source);
        int statementYear = yearMatcher.find() ? Integer.parseInt(yearMatcher.group(1)) : fallbackYear;
        Set<String> seen = new HashSet<>();
        int datedLines = 0;
        int skippedLines = 0;

        for (String rawLine : transactionRows(source)) {
            String line = rawLine == null ? "" : rawLine.trim().replaceAll("\\s+", " ");
            if (line.isEmpty()) continue;
            DateMatch date = dateAtStart(line, statementYear, fallbackDate, languageCode);
            if (date == null) continue;
            datedLines++;
            if (isSummaryLine(line)) { skippedLines++; continue; }

            long timestamp = date.timestamp;
            String afterDate = line.substring(date.end).trim();
            Matcher moneyMatcher = MONEY.matcher(afterDate);
            if (!moneyMatcher.find()) { skippedLines++; continue; }
            String amountToken = moneyMatcher.group(1);
            long signedCents = Money.parseCents(amountToken);
            long cents = Math.abs(signedCents);
            if (cents == 0) { skippedLines++; continue; }

            String lower = line.toLowerCase(Locale.ROOT);
            String type = inferType(lower, amountToken);
            String description = cleanDescription(afterDate);
            if (description.length() < 2 || !description.matches(".*\\p{L}.*")) {
                description = "Bank transaction";
            }
            String category = inferCategory(line, type);
            String key = timestamp + "|" + type + "|" + cents + "|" + description.toLowerCase(Locale.ROOT);
            if (!seen.add(key)) continue;

            BankStatementEntry entry = new BankStatementEntry();
            entry.timestamp = timestamp;
            entry.description = description;
            entry.type = type;
            entry.category = category;
            entry.amountCents = cents;
            entry.sourceLine = line;
            int confidence = 65;
            if (!"Bank transaction".equals(description)) confidence += 12;
            if (hasExplicitDirection(lower, amountToken)) confidence += 10;
            if (!"Other".equals(category) && !"Other income".equals(category)) confidence += 8;
            entry.confidencePercent = Math.min(95, confidence);
            entry.sourceFingerprint = BankAccountIdentity.transactionFingerprint(result.accountId,
                    entry.timestamp, entry.type, entry.amountCents, entry.description);
            result.entries.add(entry);
            if (result.entries.size() == MAX_ENTRIES) {
                result.warnings.add("Only the first 250 transaction rows were prepared for review.");
                break;
            }
        }

        if (result.entries.isEmpty()) {
            result.warnings.add(datedLines == 0
                    ? "No dated transaction rows were recognized."
                    : "Dated rows were found, but no transaction amounts could be read.");
        } else if (skippedLines > 0) {
            result.warnings.add(skippedLines + " dated summary or unreadable rows were skipped.");
        }
        if (!result.entries.isEmpty()) {
            result.periodStart = Long.MAX_VALUE;
            for (BankStatementEntry entry : result.entries) {
                result.periodStart = Math.min(result.periodStart, entry.timestamp);
                result.periodEnd = Math.max(result.periodEnd, entry.timestamp);
            }
        }
        result.recalculateTotals();
        return result;
    }

    private static DateMatch dateAtStart(String line, int statementYear, long fallback,
                                         String languageCode) {
        Matcher numeric = DATE_AT_START.matcher(line);
        if (numeric.find()) return new DateMatch(numeric.end(), parseNumericDate(numeric,
                statementYear, fallback, languageCode));
        Matcher monthFirst = MONTH_FIRST_AT_START.matcher(line);
        if (monthFirst.find()) {
            int month = monthNumber(monthFirst.group(1));
            if (month > 0) return new DateMatch(monthFirst.end(), date(statementYear,
                    month, parseInt(monthFirst.group(2), 1), monthFirst.group(3), fallback));
        }
        Matcher dayFirst = DAY_FIRST_MONTH_AT_START.matcher(line);
        if (dayFirst.find()) {
            int month = monthNumber(dayFirst.group(2));
            if (month > 0) return new DateMatch(dayFirst.end(), date(statementYear,
                    month, parseInt(dayFirst.group(1), 1), dayFirst.group(3), fallback));
        }
        return null;
    }

    private static long parseNumericDate(Matcher matcher, int statementYear, long fallback,
                                         String languageCode) {
        try {
            int year;
            int month;
            int day;
            if (matcher.group(1) != null) {
                year = Integer.parseInt(matcher.group(1));
                month = Integer.parseInt(matcher.group(2));
                day = Integer.parseInt(matcher.group(3));
            } else {
                int first = Integer.parseInt(matcher.group(4));
                int second = Integer.parseInt(matcher.group(5));
                boolean monthFirst = LanguageManager.ENGLISH.equals(languageCode) && first <= 12;
                if (first > 12) monthFirst = false;
                else if (second > 12) monthFirst = true;
                month = monthFirst ? first : second;
                day = monthFirst ? second : first;
                String yearText = matcher.group(6);
                year = yearText == null ? statementYear : Integer.parseInt(yearText);
                if (year < 100) year += year >= 70 ? 1900 : 2000;
            }
            return LocalDate.of(year, month, day).atStartOfDay(ZoneId.systemDefault())
                    .toInstant().toEpochMilli();
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static long date(int statementYear, int month, int day, String yearText, long fallback) {
        try {
            int year = yearText == null ? statementYear : Integer.parseInt(yearText);
            if (year < 100) year += year >= 70 ? 1900 : 2000;
            return LocalDate.of(year, month, day).atStartOfDay(ZoneId.systemDefault())
                    .toInstant().toEpochMilli();
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static List<String> transactionRows(String source) {
        List<String> rows = new ArrayList<>();
        String current = null;
        int continuations = 0;
        for (String raw : source.split("\\R")) {
            String line = raw == null ? "" : raw.replaceAll("\\s+", " ").trim();
            if (line.isEmpty()) continue;
            boolean beginsWithDate = DATE_AT_START.matcher(line).find()
                    || MONTH_FIRST_AT_START.matcher(line).find()
                    || DAY_FIRST_MONTH_AT_START.matcher(line).find();
            if (beginsWithDate) {
                if (current != null) rows.add(current);
                current = line;
                continuations = 0;
            } else if (current != null && !MONEY.matcher(current).find() && continuations < 3) {
                current += " " + line;
                continuations++;
            }
        }
        if (current != null) rows.add(current);
        return rows;
    }

    private static String normalizeNumericOcr(String source) {
        Matcher matcher = NUMERIC_OCR_TOKEN.matcher(source);
        StringBuffer output = new StringBuffer();
        while (matcher.find()) {
            String token = matcher.group(1);
            int digits = token.replaceAll("\\D", "").length();
            if (digits >= 1 && token.matches(".*[-/.,].*")) {
                token = token.replace('O', '0').replace('o', '0')
                        .replace('I', '1').replace('l', '1')
                        .replace('S', '5').replace('B', '8');
            }
            matcher.appendReplacement(output, Matcher.quoteReplacement(token));
        }
        matcher.appendTail(output);
        return output.toString();
    }

    private static int monthNumber(String value) {
        String normalized = value == null ? "" : value.toLowerCase(Locale.ROOT).replace(".", "");
        for (Map.Entry<String, Integer> entry : MONTHS.entrySet()) {
            if (normalized.startsWith(entry.getKey())) return entry.getValue();
        }
        return 0;
    }

    private static Map<String, Integer> monthNames() {
        Map<String, Integer> result = new HashMap<>();
        addMonths(result, 1, "jan", "january", "ene", "enero", "янв", "січ", "қаң");
        addMonths(result, 2, "feb", "february", "фев", "лют", "ақп");
        addMonths(result, 3, "mar", "march", "мар", "бер", "наур");
        addMonths(result, 4, "apr", "april", "abr", "апр", "квіт", "сәу");
        addMonths(result, 5, "may", "mayo", "май", "трав", "мам");
        addMonths(result, 6, "jun", "june", "июн", "чер", "мау");
        addMonths(result, 7, "jul", "july", "июл", "лип", "шіл");
        addMonths(result, 8, "aug", "august", "ago", "авг", "серп", "там");
        addMonths(result, 9, "sep", "sept", "september", "сен", "вер", "қыр");
        addMonths(result, 10, "oct", "october", "окт", "жовт", "қаз");
        addMonths(result, 11, "nov", "november", "ноя", "лист", "қар");
        addMonths(result, 12, "dec", "december", "dic", "дек", "груд", "жел");
        return result;
    }

    private static void addMonths(Map<String, Integer> target, int month, String... names) {
        for (String name : names) target.put(name, month);
    }

    private static int parseInt(String value, int fallback) {
        try { return Integer.parseInt(value); } catch (Exception ignored) { return fallback; }
    }

    private static final class DateMatch {
        final int end;
        final long timestamp;

        DateMatch(int end, long timestamp) {
            this.end = end;
            this.timestamp = timestamp;
        }
    }

    private static String inferType(String lowerLine, String amountToken) {
        String token = amountToken.trim();
        boolean negative = token.startsWith("-") || token.startsWith("−")
                || token.startsWith("(") || token.endsWith(")");
        if (negative || containsAny(lowerLine, " debit", "withdrawal", "purchase",
                "списание", "расход", "зняття", "списання", "шығыс", "алу ",
                "cargo", "retiro", "compra")) return TransactionRecord.EXPENSE;
        if (token.startsWith("+") || containsAny(lowerLine,
                "deposit", "depósito", "deposito", "direct dep", "payroll", "salary", "refund", "interest paid",
                "transfer from", "ach credit", "зачисление", "зарплата", "перевод от",
                "возврат", "проценты", "зарахування", "переказ від", "повернення",
                "відсотки", "түсім", "жалақы", "қайтарым", "депозит", "nómina",
                "nomina", "abono", "reembolso", "intereses", "transferencia recibida")) {
            return TransactionRecord.INCOME;
        }
        Matcher direction = DR_CR.matcher(lowerLine);
        if (direction.find()) return "cr".equalsIgnoreCase(direction.group(1))
                ? TransactionRecord.INCOME : TransactionRecord.EXPENSE;
        return TransactionRecord.EXPENSE;
    }

    private static boolean hasExplicitDirection(String lowerLine, String token) {
        return token.trim().matches("^[+\\-−(].*") || DR_CR.matcher(lowerLine).find()
                || containsAny(lowerLine, "deposit", "payroll", "salary", "withdrawal", "purchase",
                "зачисление", "зарплата", "списание", "зарахування", "списання",
                "түсім", "шығыс", "depósito", "deposito", "nómina", "nomina", "cargo");
    }

    private static String cleanDescription(String value) {
        String cleaned = MONEY.matcher(value).replaceAll(" ");
        cleaned = DR_CR.matcher(cleaned).replaceAll(" ");
        cleaned = cleaned.replaceAll("(?i)\\b(?:debit|credit)\\b", " ")
                .replaceAll("[#*]?[0-9]{6,}", " ")
                .replaceAll("^[|:;,-]+|[|:;,-]+$", " ")
                .replaceAll("\\s+", " ").trim();
        if (cleaned.length() > 72) cleaned = cleaned.substring(0, 72).trim();
        return titleCaseIfAllCaps(cleaned);
    }

    private static boolean isSummaryLine(String line) {
        String lower = line.toLowerCase(Locale.ROOT);
        return containsAny(lower, "opening balance", "closing balance", "beginning balance",
                "ending balance", "daily balance", "available balance", "account balance",
                "начальный остаток", "конечный остаток", "входящий остаток", "исходящий остаток",
                "початковий залишок", "кінцевий залишок", "бастапқы қалдық", "соңғы қалдық",
                "saldo inicial", "saldo final", "saldo disponible");
    }

    private static String inferCategory(String description, String type) {
        String lower = description.toLowerCase(Locale.ROOT);
        if (TransactionRecord.INCOME.equals(type)) {
            if (containsAny(lower, "payroll", "salary", "direct dep", "wages", "зарплат",
                    "жалақы", "налік", "nómina", "nomina", "sueldo", "salario")) return "Paycheck";
            if (containsAny(lower, "refund", "reimburse", "возврат", "возмещ", "повернен",
                    "відшкод", "қайтарым", "өтем", "reembolso")) return "Reimbursement";
            if (containsAny(lower, "benefit", "pension", "social security", "пособ", "пенси",
                    "допомог", "жәрдем", "prestación", "pensión")) return "Benefits";
            if (containsAny(lower, "business", "client", "invoice", "бизнес", "клиент",
                    "рахунок", "кәсіп", "negocio", "cliente")) return "Business income";
            return "Other income";
        }
        if (containsAny(lower, "rent", "mortgage", "landlord", "аренд", "ипотек", "оренд",
                "жалға", "alquiler", "hipoteca")) return "Housing";
        if (containsAny(lower, "electric", "utility", "water", "internet", "wireless", "phone",
                "электр", "коммун", "электро", "вода", "связь", "світло", "комун",
                "жарық", "су ", "electricidad", "agua", "teléfono")) return "Utilities";
        if (containsAny(lower, "grocery", "supermarket", "market", "food store", "продукт",
                "супермаркет", "азық", "mercado", "supermercado")) return "Groceries";
        if (containsAny(lower, "restaurant", "cafe", "coffee", "pizza", "delivery", "ресторан",
                "кафе", "мейрамхана", "restaurante", "cafetería")) return "Dining";
        if (containsAny(lower, "gas", "fuel", "transit", "uber", "taxi", "parking", "auto",
                "бензин", "топливо", "транспорт", "такси", "жанармай", "gasolina",
                "combustible", "aparcamiento")) return "Transportation";
        if (containsAny(lower, "pharmacy", "medical", "clinic", "hospital", "dental", "аптек",
                "клиник", "больниц", "лікар", "дәріхана", "farmacia", "hospital")) return "Healthcare";
        if (containsAny(lower, "insurance", "страх", "сақтан", "seguro")) return "Insurance";
        if (containsAny(lower, "loan", "credit card", "interest charge", "кредит", "заём",
                "позик", "қарыз", "préstamo", "tarjeta")) return "Debt";
        if (containsAny(lower, "daycare", "childcare", "детсад", "няня", "садок", "балабақша",
                "guardería")) return "Childcare";
        if (containsAny(lower, "hardware", "household", "home improvement", "хозтовар", "ремонт",
                "господар", "үй тауар", "ferretería", "hogar")) return "Household";
        if (containsAny(lower, "school", "tuition", "book", "course", "школ", "обуч", "книг",
                "навчан", "мектеп", "кітап", "escuela", "libro", "curso")) return "Education";
        if (containsAny(lower, "donation", "charity", "church", "пожертв", "благотвор",
                "қайырым", "donación", "caridad")) return "Giving";
        if (containsAny(lower, "cinema", "theater", "streaming", "netflix", "game", "кино",
                "театр", "ойын", "cine", "juego")) return "Entertainment";
        if (containsAny(lower, "store", "shop", "retail", "магазин", "крамниц", "дүкен",
                "tienda", "comercio")) return "Shopping";
        return "Other";
    }

    private static boolean containsAny(String value, String... needles) {
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }

    private static String titleCaseIfAllCaps(String value) {
        if (!value.equals(value.toUpperCase(Locale.ROOT))) return value;
        StringBuilder result = new StringBuilder();
        for (String word : value.toLowerCase(Locale.ROOT).split(" ")) {
            if (word.isEmpty()) continue;
            if (result.length() > 0) result.append(' ');
            result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return result.toString();
    }
}
