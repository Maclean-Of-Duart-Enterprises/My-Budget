package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import static org.junit.Assert.assertEquals;

public class ReportPeriodTest {
    @Test public void honorsEveryConfiguredWeekStartDay() {
        ZoneId zone = ZoneId.of("America/New_York");
        LocalDate thursday = LocalDate.of(2026, 8, 20);
        long monday = ReportPeriod.weekStart(thursday, 1, zone);
        long sunday = ReportPeriod.weekStart(thursday, 7, zone);
        assertEquals(LocalDate.of(2026, 8, 17), ZonedDateTime.ofInstant(
                java.time.Instant.ofEpochMilli(monday), zone).toLocalDate());
        assertEquals(LocalDate.of(2026, 8, 16), ZonedDateTime.ofInstant(
                java.time.Instant.ofEpochMilli(sunday), zone).toLocalDate());
    }

    @Test public void weekEndUsesLocalCalendarAcrossDaylightSavingTime() {
        ZoneId zone = ZoneId.of("America/New_York");
        LocalDate date = LocalDate.of(2026, 3, 10);
        long start = ReportPeriod.weekStart(date, 7, zone);
        long end = ReportPeriod.weekEnd(date, 7, zone);
        assertEquals(167, (end - start) / 3_600_000L);
    }
}
