package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class BudgetAgentTest {
    private static final long DAY = 86_400_000L;

    @Test public void createsBalancedBudgetFromHistory() {
        long now = 1_800_000_000_000L;
        List<TransactionRecord> records = new ArrayList<>();
        for (int month = 1; month <= 3; month++) {
            records.add(record(now - month * 28L * DAY, TransactionRecord.INCOME, "Employer", "Paycheck", 400_000));
            records.add(record(now - month * 28L * DAY + DAY, TransactionRecord.EXPENSE, "Landlord", "Housing", 120_000));
            records.add(record(now - month * 28L * DAY + 2 * DAY, TransactionRecord.EXPENSE, "Market", "Groceries", 45_000));
            records.add(record(now - month * 28L * DAY + 3 * DAY, TransactionRecord.EXPENSE, "Electric", "Utilities", 20_000));
        }
        BudgetPlan plan = new BudgetAgent().createPlan(records, now);
        assertTrue(plan.confidencePercent > 50);
        assertTrue(plan.expectedMonthlyIncome > 0);
        assertTrue(plan.savingsTarget >= Math.round(plan.expectedMonthlyIncome * 0.10));
        assertTrue(plan.totalAllocated() <= plan.expectedMonthlyIncome - Math.round(plan.expectedMonthlyIncome * 0.10));
        assertTrue(plan.categoryLimits.containsKey("Housing"));
    }

    @Test public void reportsIncomeExpenseAndPriorComparison() {
        long start = 1_800_000_000_000L;
        long end = start + 7 * DAY;
        List<TransactionRecord> records = List.of(
                record(start + DAY, TransactionRecord.INCOME, "Employer", "Paycheck", 100_000),
                record(start + 2 * DAY, TransactionRecord.EXPENSE, "Market", "Groceries", 20_000),
                record(start - 2 * DAY, TransactionRecord.EXPENSE, "Market", "Groceries", 10_000)
        );
        PeriodReport report = new BudgetAgent().createReport(records, start, end, "Weekly");
        assertEquals(100_000, report.income);
        assertEquals(20_000, report.expenses);
        assertEquals(80_000, report.net);
        assertEquals(10_000, report.previousExpenses);
        assertEquals(100, report.expenseChangePercent);
        assertFalse(report.insights.isEmpty());
    }

    @Test public void reportsWhenReviewedStatementRowsFeedThePlan() {
        long now = 1_800_000_000_000L;
        TransactionRecord income = record(now - DAY, TransactionRecord.INCOME,
                "Employer deposit", "Paycheck", 200_000);
        TransactionRecord expense = record(now - DAY / 2, TransactionRecord.EXPENSE,
                "Market", "Groceries", 35_000);
        income.documentKind = TransactionRecord.DOCUMENT_BANK_STATEMENT;
        expense.documentKind = TransactionRecord.DOCUMENT_BANK_STATEMENT;
        BudgetPlan plan = new BudgetAgent().createPlan(List.of(income, expense), now);
        assertEquals(2, plan.statementTransactionCount);
        assertTrue(plan.insights.stream().anyMatch(value -> value.contains("bank statements")));
    }

    @Test public void createsIndependentWeeklyAndMonthlyAiBudgets() {
        long now = 1_800_000_000_000L;
        List<TransactionRecord> records = List.of(
                record(now - 20 * DAY, TransactionRecord.INCOME, "Employer", "Paycheck", 400_000),
                record(now - 18 * DAY, TransactionRecord.EXPENSE, "Rent", "Housing", 120_000),
                record(now - 10 * DAY, TransactionRecord.EXPENSE, "Market", "Groceries", 40_000)
        );
        BudgetAgent agent = new BudgetAgent();
        BudgetPlan monthly = agent.createPlan(records, now, BudgetPeriod.MONTHLY);
        BudgetPlan weekly = agent.createPlan(records, now, BudgetPeriod.WEEKLY);
        assertEquals(BudgetPeriod.MONTHLY, monthly.period);
        assertEquals(BudgetPeriod.WEEKLY, weekly.period);
        assertTrue(weekly.expectedMonthlyIncome > 0);
        assertTrue(weekly.expectedMonthlyIncome < monthly.expectedMonthlyIncome);
        assertTrue(weekly.categoryLimits.get("Housing") < monthly.categoryLimits.get("Housing"));
    }

    @Test public void preservesEssentialCushionAfterOriginalCategoryIsRenamed() {
        long now = 1_800_000_000_000L;
        List<TransactionRecord> records = List.of(
                record(now - 30 * DAY, TransactionRecord.EXPENSE, "Landlord", "Rent", 100_000)
        );
        LanguageManager english = new LanguageManager(LanguageManager.ENGLISH);
        BudgetPlan essential = new BudgetAgent(english, Set.of("Rent")).createPlan(records, now);
        BudgetPlan discretionary = new BudgetAgent(english, Set.of()).createPlan(records, now);

        assertTrue(essential.categoryLimits.get("Rent") > discretionary.categoryLimits.get("Rent"));
    }

    @Test public void categoryReportIncludesOnlyTheSelectedTypeAndCategory() {
        long start = 1_800_000_000_000L;
        long end = start + 7 * DAY;
        List<TransactionRecord> records = List.of(
                record(start + DAY, TransactionRecord.INCOME, "Employer", "Paycheck", 100_000),
                record(start + 2 * DAY, TransactionRecord.EXPENSE, "Market", "Groceries", 20_000),
                record(start + 3 * DAY, TransactionRecord.EXPENSE, "Fuel", "Transportation", 5_000)
        );
        PeriodReport report = new BudgetAgent().createCategoryReport(records, start, end,
                "Groceries", TransactionRecord.EXPENSE, "Groceries");
        assertEquals(1, report.transactionCount);
        assertEquals(20_000, report.expenses);
        assertEquals(0, report.income);
        assertEquals(20_000L, report.spendingByCategory.get("Groceries").longValue());
        assertEquals("Groceries", report.filterCategory);
    }

    @Test public void combinesAccountsWithoutDoubleCountingInternalTransfers() {
        long now = 1_800_000_000_000L;
        TransactionRecord salary = statement(now - 5 * DAY, TransactionRecord.INCOME,
                "Employer payroll", "Paycheck", 400_000, "checking", "salary");
        TransactionRecord groceries = statement(now - 4 * DAY, TransactionRecord.EXPENSE,
                "Market", "Groceries", 50_000, "checking", "groceries");
        TransactionRecord transferOut = statement(now - 3 * DAY, TransactionRecord.EXPENSE,
                "Transfer to savings", "Other", 100_000, "checking", "transfer-out");
        TransactionRecord transferIn = statement(now - 2 * DAY, TransactionRecord.INCOME,
                "Transfer from checking", "Other income", 100_000, "savings", "transfer-in");
        TransactionRecord utility = statement(now - DAY, TransactionRecord.EXPENSE,
                "Electric utility", "Utilities", 20_000, "savings", "utility");
        List<TransactionRecord> records = List.of(salary, groceries, transferOut, transferIn, utility);

        BudgetPlan plan = new BudgetAgent().createPlan(records, now);
        assertEquals(2, plan.accountCount);
        assertEquals(2, plan.excludedTransferCount);
        assertEquals(3, plan.statementTransactionCount);
        assertEquals(400_000, plan.expectedMonthlyIncome);

        PeriodReport report = new BudgetAgent().createReport(records, now - 6 * DAY,
                now + DAY, "Weekly");
        assertEquals(2, report.accountCount);
        assertEquals(2, report.excludedTransferCount);
        assertEquals(3, report.transactionCount);
        assertEquals(400_000, report.income);
        assertEquals(70_000, report.expenses);
        assertEquals(330_000, report.net);
    }

    private static TransactionRecord record(long time, String type, String merchant, String category, long cents) {
        TransactionRecord record = new TransactionRecord();
        record.timestamp = time;
        record.type = type;
        record.merchant = merchant;
        record.category = category;
        record.amountCents = cents;
        return record;
    }

    private static TransactionRecord statement(long time, String type, String merchant,
                                               String category, long cents, String account,
                                               String fingerprint) {
        TransactionRecord record = record(time, type, merchant, category, cents);
        record.documentKind = TransactionRecord.DOCUMENT_BANK_STATEMENT;
        record.accountId = account;
        record.accountName = account;
        record.sourceFingerprint = fingerprint;
        return record;
    }
}
