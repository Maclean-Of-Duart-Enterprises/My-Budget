package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class OcrTextQualityTest {
    @Test public void prefersThePassWithReadableStatementRows() {
        String weak = "Acc0unt surnrnary\ncl0sing ba1ance";
        String clear = "08/01/2026 PAYROLL +2,125.00\n08/02/2026 MARKET -87.42";
        assertTrue(OcrTextQuality.score(clear) > OcrTextQuality.score(weak));
        assertEquals(clear, OcrTextQuality.choose(weak, clear));
    }

    @Test public void scoresMultilingualMonthDatesWithAmounts() {
        assertTrue(OcrTextQuality.score("14 августа 2026 Зарплата 125 000,00") >= 30);
        assertTrue(OcrTextQuality.score("14 agosto 2026 Nómina 1.250,00") >= 30);
    }
}
