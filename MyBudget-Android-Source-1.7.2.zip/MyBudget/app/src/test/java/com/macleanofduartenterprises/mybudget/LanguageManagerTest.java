package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class LanguageManagerTest {
    @Test public void exposesAllFiveLanguagesAndTranslatesNavigation() {
        assertEquals(5, LanguageManager.codes().size());
        assertEquals("Главная", new LanguageManager("ru").t("Home"));
        assertEquals("Головна", new LanguageManager("uk").t("Home"));
        assertEquals("Басты", new LanguageManager("kk").t("Home"));
        assertEquals("Inicio", new LanguageManager("es").t("Home"));
    }

    @Test public void canonicalCategoriesSurviveLanguageChanges() {
        for (String code : LanguageManager.codes()) {
            LanguageManager language = new LanguageManager(code);
            String shown = language.category("Groceries");
            assertFalse(shown.isEmpty());
            assertEquals("Groceries", language.canonicalCategory(shown));
        }
        assertEquals("Farm supplies", new LanguageManager("ru")
                .canonicalCategory("Farm supplies"));
    }

    @Test public void parsesCommonLocalizedMoneyFormats() {
        assertEquals(123_456, Money.parseCents("1 234,56"));
        assertEquals(123_456, Money.parseCents("1.234,56 €"));
        assertEquals(123_456, Money.parseCents("$1,234.56"));
    }

    @Test public void newBudgetLockAndPdfControlsAreTranslated() {
        String[] labels = {
                "Manual monthly budget", "Edit manual budget", "Save manual budget",
                "Use AI suggestions as a starting point", "Automatic lock after leaving the app",
                "Manual only", "After 5 minutes", "Lock now", "Export transactions as PDF",
                "Transaction export", "Transaction details", "Version 1.6.0",
                "Upload bank statements", "Upload receipt/paystub photos or PDFs",
                "Review bank statement", "Import selected transactions", "Selected %d files",
                "Skip this statement", "Skip this upload", "Cancel remaining uploads",
                "Finish or skip the current upload before leaving this screen.",
                "Please wait while the local document task finishes.",
                "Batch complete • %1$d saved • %2$d skipped • %3$d failed",
                "Statements complete • %1$d imported • %2$d transactions • %3$d skipped • %4$d failed",
                "Review upload %1$d of %2$d. Save or skip this transaction to continue.",
                "This plan uses %d reviewed transactions imported from bank statements.",
                "Document type", "Bank statement", "Statement bank account",
                "Edit bank account identity", "Bank or institution",
                "Account name or last four digits", "All bank accounts",
                "Exclude from AI budget and reports (transfer or adjustment)",
                "Bank accounts used", "Statement transactions used",
                "Transfers or adjustments excluded", "Bank accounts learned",
                "The agent combined transaction history from %d bank accounts.",
                "This report combines activity from %d bank accounts.",
                "Imported %1$d transactions • %2$d duplicates skipped",
                "Manage transactions", "Transaction management", "Select all shown",
                "Select one transaction for full editing, or select several to replace checked fields or delete them together.",
                "Clear selection", "Edit or replace selected", "Delete selected", "Done managing",
                "Select transaction: %s", "%1$d selected • %2$d shown",
                "Edit or replace selected transaction",
                "Replace fields in %d selected transactions", "Delete selected transaction",
                "Delete %d selected transactions", "Edit or replace transaction",
                "Delete %d selected transactions?",
                "Attached financial documents no longer used by another transaction will also be deleted. This cannot be undone.",
                "Deleting selected transactions…",
                "Updating the local history and encrypted document storage.",
                "The selected transactions could not be deleted.",
                "Only checked fields will be replaced. Attachments and original import fingerprints will remain unchanged.",
                "Replace merchant or income source", "New merchant or income source",
                "Replace amount", "Replace transaction type and category", "Replace date",
                "Replace or clear note", "New note; leave blank to clear",
                "Replace or clear bank account association",
                "Enter both values, or leave both blank to remove the bank account association.",
                "Replace AI budget and report treatment", "Apply replacements",
                "Choose at least one field to replace.", "Updating selected transactions…",
                "Applying only the checked replacements to local transaction history.",
                "The selected transactions could not be updated.",
                "Please wait while the local transaction task finishes.",
                "Bank account association (optional)", "Include in AI budget and reports",
                "Enter both values, or leave both blank for no bank account association.",
                "Exclude from AI budget and reports", "Updated %d transactions",
                "Deleted %d transactions", "Budget period", "AI weekly budget",
                "AI monthly budget", "Manual weekly budget", "Weekly category limits",
                "Enter at least one weekly amount.", "Independent category report",
                "Create category report", "Category budget comparison",
                "Weekly report settings", "Start day of the week", "Category management",
                "Add income category", "Add expense category", "Rename category",
                "Remove category?", "Category added", "Category renamed", "Category removed",
                "Add, rename, reorder, or remove any income or expense category, including the original categories.",
                "Move category up", "Move category down",
                "At least one category must remain in each list.",
                "This removes the category from future selections. Any manual limits will be moved to %s.",
                "Version 1.7.1"
        };
        for (String code : new String[]{"ru", "uk", "kk", "es"}) {
            LanguageManager language = new LanguageManager(code);
            for (String label : labels) assertTrue(code + " missing " + label, language.hasTranslation(label));
        }
    }
}
