package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class BankAccountIdentityTest {
    @Test public void detectsBankAccountTypeAndMaskedNumber() {
        BankAccountIdentity identity = BankAccountIdentity.detect(
                "CHASE\nMonthly statement\nChecking account ending in 1234\nAugust 2026");
        assertEquals("Chase", identity.bankName);
        assertEquals("Checking", identity.accountType);
        assertEquals("1234", identity.lastFour);
        assertEquals("Checking ••••1234", identity.accountName);
    }

    @Test public void accountIdsAndTransactionFingerprintsStayAccountSpecific() {
        BankAccountIdentity first = BankAccountIdentity.detect(
                "Wells Fargo\nSavings account ••••1111");
        BankAccountIdentity second = BankAccountIdentity.detect(
                "Wells Fargo\nSavings account ••••2222");
        assertNotEquals(first.accountId, second.accountId);
        assertNotEquals(
                BankAccountIdentity.transactionFingerprint(first.accountId, 123L,
                        TransactionRecord.EXPENSE, 4_500, "Market"),
                BankAccountIdentity.transactionFingerprint(second.accountId, 123L,
                        TransactionRecord.EXPENSE, 4_500, "Market"));
    }

    @Test public void genericStatementHeadingIsNotUsedAsTheBankName() {
        BankAccountIdentity identity = BankAccountIdentity.detect(
                "BANK STATEMENT\nAccount ending 9876\n08/01/2026 Market 10.00");
        assertEquals("Bank", identity.bankName);
    }
}
