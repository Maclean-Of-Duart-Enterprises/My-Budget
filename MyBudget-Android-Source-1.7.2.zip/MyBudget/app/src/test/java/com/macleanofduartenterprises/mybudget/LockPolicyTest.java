package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class LockPolicyTest {
    @Test public void manualAndTimedModesBehaveAsSelected() {
        assertFalse(LockPolicy.shouldLock(LockPolicy.MANUAL_ONLY, 86_400_000));
        assertTrue(LockPolicy.shouldLock(LockPolicy.IMMEDIATELY, 0));
        assertFalse(LockPolicy.shouldLock(30, 29_999));
        assertTrue(LockPolicy.shouldLock(30, 30_000));
        assertFalse(LockPolicy.shouldLock(300, 299_999));
        assertTrue(LockPolicy.shouldLock(300, 300_000));
    }
}
