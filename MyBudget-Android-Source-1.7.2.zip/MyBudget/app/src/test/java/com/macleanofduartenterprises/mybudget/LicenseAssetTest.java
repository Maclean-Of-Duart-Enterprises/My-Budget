package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class LicenseAssetTest {
    @Test public void completeAgplv3TextIsBundledAndLicenseNavigationIsTranslated() throws Exception {
        String bundled = new String(Files.readAllBytes(Paths.get("src/main/assets/LICENSE.txt")),
                StandardCharsets.UTF_8);
        String source = new String(Files.readAllBytes(Paths.get("../LICENSE.txt")),
                StandardCharsets.UTF_8);

        assertEquals(source, bundled);
        assertTrue(bundled.startsWith("GNU AFFERO GENERAL PUBLIC LICENSE"));
        assertTrue(bundled.contains("Version 3, 19 November 2007"));
        assertTrue(bundled.contains("13. Remote Network Interaction; Use with the GNU General Public License."));
        assertTrue(bundled.contains("END OF TERMS AND CONDITIONS"));

        for (String code : LanguageManager.codes()) {
            LanguageManager language = new LanguageManager(code);
            assertTrue(language.hasTranslation("License"));
            assertTrue(language.hasTranslation("Read full AGPLv3 license"));
            assertTrue(language.hasTranslation("Full license text"));
        }
    }
}
