package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TransactionHistoryAnalyzerTest {
    private static final long DAY = 86_400_000L;

    @Test public void deduplicatesStatementsAndExcludesMatchedTransfersAcrossAccounts() {
        long time = 1_800_000_000_000L;
        TransactionRecord transferOut = record(1, time, "checking", TransactionRecord.EXPENSE,
                100_000, "Transfer to savings", "out");
        TransactionRecord transferIn = record(2, time + DAY, "savings", TransactionRecord.INCOME,
                100_000, "Transfer from checking", "in");
        TransactionRecord groceries = record(3, time + DAY, "checking", TransactionRecord.EXPENSE,
                5_000, "Grocery market", "grocery");
        TransactionRecord duplicate = record(4, time + DAY, "checking", TransactionRecord.EXPENSE,
                5_000, "Grocery market", "grocery");

        TransactionHistoryAnalyzer.Result result = new TransactionHistoryAnalyzer().analyze(
                List.of(transferOut, transferIn, groceries, duplicate));

        assertEquals(3, result.canonicalRecords.size());
        assertEquals(1, result.analysisRecords.size());
        assertEquals(1, result.duplicateCount);
        assertEquals(2, result.excludedRecordCount);
        assertEquals(2, result.accountCount);
        assertTrue(result.analysisRecords.contains(groceries));
    }

    @Test public void manualExclusionsStayOutOfAnalysis() {
        TransactionRecord adjustment = record(7, 10L, "cash", TransactionRecord.EXPENSE,
                1_000, "Opening adjustment", "adjustment");
        adjustment.excludeFromBudget = true;
        TransactionHistoryAnalyzer.Result result = new TransactionHistoryAnalyzer().analyze(
                List.of(adjustment));
        assertEquals(1, result.canonicalRecords.size());
        assertTrue(result.analysisRecords.isEmpty());
        assertEquals(1, result.excludedRecordCount);
    }

    private static TransactionRecord record(long id, long time, String account, String type,
                                            long amount, String merchant, String fingerprint) {
        TransactionRecord record = new TransactionRecord();
        record.id = id;
        record.timestamp = time;
        record.accountId = account;
        record.type = type;
        record.amountCents = amount;
        record.merchant = merchant;
        record.sourceFingerprint = fingerprint;
        return record;
    }
}
