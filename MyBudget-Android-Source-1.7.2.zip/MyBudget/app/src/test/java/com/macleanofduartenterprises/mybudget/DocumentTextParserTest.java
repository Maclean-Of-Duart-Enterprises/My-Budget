package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class DocumentTextParserTest {
    private final DocumentTextParser parser = new DocumentTextParser();

    @Test public void readsReceiptTotalMerchantAndCategory() {
        String text = "GREEN VALLEY MARKET\n" +
                "123 Main Street\n" +
                "08/12/2026\n" +
                "Produce 12.40\nMilk 4.59\nSubtotal $16.99\nTax $0.00\nTOTAL $16.99";
        ParsedDocument result = parser.parse(text, 1L);
        assertEquals(ParsedDocument.RECEIPT, result.kind);
        assertEquals(TransactionRecord.EXPENSE, result.transactionType);
        assertEquals("Green Valley Market", result.party);
        assertEquals("Groceries", result.category);
        assertEquals(1699, result.amountCents);
        assertTrue(result.confidencePercent >= 80);
    }

    @Test public void readsPaystubNetPayAsIncome() {
        String text = "MACLEAN COMPANY\nEARNINGS STATEMENT\nPay Date 08/14/2026\n" +
                "Gross Pay $1,850.00\nTaxes $350.00\nNET PAY $1,500.00\nYTD Earnings $20,000.00";
        ParsedDocument result = parser.parse(text, 1L);
        assertEquals(ParsedDocument.PAYSTUB, result.kind);
        assertEquals(TransactionRecord.INCOME, result.transactionType);
        assertEquals("Paycheck", result.category);
        assertEquals(150000, result.amountCents);
        assertEquals("Maclean Company", result.party);
    }

    @Test public void warnsWhenAmountIsMissing() {
        ParsedDocument result = parser.parse("SMALL SHOP\nThank you", 123L);
        assertEquals(0, result.amountCents);
        assertTrue(result.warnings.stream().anyMatch(value -> value.contains("Amount")));
    }

    @Test public void readsRussianPaystubWithDecimalComma() {
        String text = "КОМПАНИЯ РОМАШКА\nРАСЧЕТНЫЙ ЛИСТ\nДата 14.08.2026\n"
                + "Начислено 200 000,00 ₽\nК ВЫДАЧЕ 175 000,50 ₽";
        ParsedDocument result = parser.parse(text, 1L, LanguageManager.RUSSIAN);
        assertEquals(ParsedDocument.PAYSTUB, result.kind);
        assertEquals(TransactionRecord.INCOME, result.transactionType);
        assertEquals(17_500_050, result.amountCents);
    }

    @Test public void readsUkrainianKazakhAndSpanishReceipts() {
        ParsedDocument ukrainian = parser.parse(
                "СУПЕРМАРКЕТ ДОБРИЙ\n14.08.2026\nРАЗОМ 1 234,56 ₴", 1L, LanguageManager.UKRAINIAN);
        assertEquals(123_456, ukrainian.amountCents);
        assertEquals("Groceries", ukrainian.category);

        ParsedDocument kazakh = parser.parse(
                "БЕРЕКЕ ДҮКЕН\n14.08.2026\nАЗЫҚ-ТҮЛІК\nБАРЛЫҒЫ 12 345,67 ₸", 1L, LanguageManager.KAZAKH);
        assertEquals(1_234_567, kazakh.amountCents);
        assertEquals("Groceries", kazakh.category);

        ParsedDocument spanish = parser.parse(
                "SUPERMERCADO SOL\n14.08.2026\nTOTAL A PAGAR €42,75", 1L, LanguageManager.SPANISH);
        assertEquals(4_275, spanish.amountCents);
        assertEquals("Groceries", spanish.category);
    }
}
