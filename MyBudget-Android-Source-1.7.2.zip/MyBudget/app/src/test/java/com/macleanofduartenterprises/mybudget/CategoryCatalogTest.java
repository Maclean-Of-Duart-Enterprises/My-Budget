package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class CategoryCatalogTest {
    private static final List<String> DEFAULTS = Arrays.asList("Housing", "Groceries", "Other");

    @Test public void migratesOriginalAndLegacyCustomCategoriesInStableOrder() {
        CategoryCatalog catalog = new CategoryCatalog(DEFAULTS, null,
                Arrays.asList("Travel", "Car maintenance"), Collections.emptyMap());

        assertEquals(Arrays.asList("Housing", "Groceries", "Other", "Car maintenance", "Travel"),
                catalog.categories());
    }

    @Test public void renamesOriginalCategoryAndKeepsParserAlias() {
        CategoryCatalog catalog = new CategoryCatalog(DEFAULTS, null,
                Collections.emptyList(), Collections.emptyMap());

        assertTrue(catalog.rename("Housing", "Rent & mortgage"));
        assertEquals("Rent & mortgage", catalog.categories().get(0));
        assertEquals("Rent & mortgage", catalog.resolve("Housing"));

        CategoryCatalog restored = new CategoryCatalog(DEFAULTS, catalog.categories(),
                Collections.emptyList(), catalog.aliases());
        assertEquals("Rent & mortgage", restored.resolve("Housing"));
    }

    @Test public void removesOriginalCategoryAndMapsItsSuggestionsToFallback() {
        CategoryCatalog catalog = new CategoryCatalog(DEFAULTS, null,
                Collections.emptyList(), Collections.emptyMap());
        assertTrue(catalog.rename("Other", "Everything else"));

        String fallback = catalog.fallbackFor("Housing");
        assertEquals("Everything else", fallback);
        assertTrue(catalog.remove("Housing", fallback));
        assertFalse(catalog.categories().contains("Housing"));
        assertEquals("Everything else", catalog.resolve("Housing"));
    }

    @Test public void reordersEveryCategoryAndNeverAllowsAnEmptyList() {
        CategoryCatalog catalog = new CategoryCatalog(Arrays.asList("One", "Other"), null,
                Collections.emptyList(), Map.of());

        assertTrue(catalog.move("Other", -1));
        assertEquals(Arrays.asList("Other", "One"), catalog.categories());
        assertFalse(catalog.move("Other", -1));
        assertTrue(catalog.remove("One", "Other"));
        assertEquals(Collections.singletonList("Other"), catalog.categories());
        assertEquals("", catalog.fallbackFor("Other"));
        assertEquals("Other", catalog.resolve("Housing"));
        assertFalse(catalog.remove("Other", "Other"));
    }
}
