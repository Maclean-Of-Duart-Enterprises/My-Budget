package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ManualBudgetTest {
    @Test public void totalsAndRemainderReflectManualControls() {
        ManualBudget budget = new ManualBudget();
        assertFalse(budget.isConfigured());
        budget.expectedMonthlyIncome = 400_000;
        budget.savingsTarget = 50_000;
        budget.categoryLimits.put("Housing", 120_000L);
        budget.categoryLimits.put("Groceries", 45_000L);
        budget.updatedAt = 1;
        assertTrue(budget.isConfigured());
        assertEquals(165_000, budget.totalAllocated());
        assertEquals(185_000, budget.plannedRemainder());
        assertEquals(budget.categoryLimits, budget.copy().categoryLimits);
    }
}
