package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import java.time.LocalDate;
import java.time.ZoneId;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

public class BankStatementParserTest {
    private final BankStatementParser parser = new BankStatementParser();
    private final long fallback = LocalDate.of(2026, 8, 14).atStartOfDay(ZoneId.systemDefault())
            .toInstant().toEpochMilli();

    @Test public void readsSignedIncomeAndExpenseWhileIgnoringRunningBalance() {
        String text = "Statement period August 2026\n"
                + "08/01/2026 PAYROLL ACME +2,125.00 4,800.00\n"
                + "08/02/2026 GREEN VALLEY MARKET -87.42 4,712.58\n";
        BankStatementResult result = parser.parse(text, fallback, LanguageManager.ENGLISH);
        assertEquals(2, result.entries.size());
        assertEquals(TransactionRecord.INCOME, result.entries.get(0).type);
        assertEquals("Paycheck", result.entries.get(0).category);
        assertEquals(212_500, result.entries.get(0).amountCents);
        assertEquals(TransactionRecord.EXPENSE, result.entries.get(1).type);
        assertEquals("Groceries", result.entries.get(1).category);
        assertEquals(8_742, result.entries.get(1).amountCents);
        assertEquals(212_500, result.incomeCents);
        assertEquals(8_742, result.expenseCents);
    }

    @Test public void readsRussianCreditAndDebitRowsWithDecimalCommas() {
        String text = "БАНКОВСКАЯ ВЫПИСКА 2026\n"
                + "14.08.2026 ЗАРПЛАТА 125 000,00 CR 150 000,00\n"
                + "15.08.2026 СУПЕРМАРКЕТ 4 500,00 DR 145 500,00\n";
        BankStatementResult result = parser.parse(text, fallback, LanguageManager.RUSSIAN);
        assertEquals(2, result.entries.size());
        assertEquals(TransactionRecord.INCOME, result.entries.get(0).type);
        assertEquals(12_500_000, result.entries.get(0).amountCents);
        assertEquals(TransactionRecord.EXPENSE, result.entries.get(1).type);
        assertEquals("Groceries", result.entries.get(1).category);
        assertEquals(450_000, result.entries.get(1).amountCents);
    }

    @Test public void recognizesSpanishDepositsAndSkipsBalanceRows() {
        String text = "Extracto 2026\n"
                + "14/08/2026 SALDO INICIAL 900,00\n"
                + "14/08/2026 DEPÓSITO NÓMINA 1.250,00 2.150,00\n"
                + "15/08/2026 RESTAURANTE SOL 35,50 2.114,50\n"
                + "15/08/2026 SALDO FINAL 2.114,50\n";
        BankStatementResult result = parser.parse(text, fallback, LanguageManager.SPANISH);
        assertEquals(2, result.entries.size());
        assertEquals(TransactionRecord.INCOME, result.entries.get(0).type);
        assertEquals("Paycheck", result.entries.get(0).category);
        assertEquals(125_000, result.entries.get(0).amountCents);
        assertEquals("Dining", result.entries.get(1).category);
    }

    @Test public void doesNotMistakeCreditCardPaymentsForIncome() {
        BankStatementResult result = parser.parse(
                "08/13/2026 CREDIT CARD PAYMENT 125.00 800.00", fallback,
                LanguageManager.ENGLISH);
        assertEquals(1, result.entries.size());
        assertEquals(TransactionRecord.EXPENSE, result.entries.get(0).type);
        assertEquals("Debt", result.entries.get(0).category);
    }

    @Test public void proposesNothingWhenNoDatedMonetaryRowsExist() {
        BankStatementResult result = parser.parse("Account summary\nClosing balance 100.00", fallback,
                LanguageManager.ENGLISH);
        assertTrue(result.entries.isEmpty());
        assertFalse(result.warnings.isEmpty());
    }

    @Test public void reconstructsMultilineRowsAndCorrectsCommonOcrNumberErrors() {
        String text = "CHASE\nChecking account ending in 1234\nStatement period August 2026\n"
                + "O8/O1/2O26 ONLINE TRANSFER\n"
                + "TO SAVINGS ACCOUNT\n"
                + "-5O0.00 3,500.00\n"
                + "Aug 2, 2026 PAYROLL ACME +2,000.00 5,500.00\n";
        BankStatementResult result = parser.parse(text, fallback, LanguageManager.ENGLISH);
        assertEquals("Chase", result.bankName);
        assertEquals("Checking ••••1234", result.accountName);
        assertEquals(2, result.entries.size());
        assertEquals(50_000, result.entries.get(0).amountCents);
        assertTrue(result.entries.get(0).description.contains("Savings"));
        assertEquals(TransactionRecord.INCOME, result.entries.get(1).type);
        assertEquals(200_000, result.entries.get(1).amountCents);
        assertFalse(result.entries.get(0).sourceFingerprint.isEmpty());
    }

    @Test public void readsLocalizedMonthNameDates() {
        BankStatementResult russian = parser.parse(
                "Сбербанк\nСчет ••••4321\n14 августа 2026 ЗАРПЛАТА +125 000,00",
                fallback, LanguageManager.RUSSIAN);
        BankStatementResult spanish = parser.parse(
                "BBVA\nCuenta terminada en 7777\n14 agosto 2026 SUPERMERCADO 42,75",
                fallback, LanguageManager.SPANISH);
        assertEquals(1, russian.entries.size());
        assertEquals(12_500_000, russian.entries.get(0).amountCents);
        assertEquals(1, spanish.entries.size());
        assertEquals(4_275, spanish.entries.get(0).amountCents);
        assertNotEquals(russian.accountId, spanish.accountId);
    }
}
