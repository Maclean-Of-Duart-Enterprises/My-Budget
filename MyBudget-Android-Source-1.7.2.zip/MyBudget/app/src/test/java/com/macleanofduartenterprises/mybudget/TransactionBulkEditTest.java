package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class TransactionBulkEditTest {
    @Test public void replacesOnlyCheckedFieldsAndPreservesAttachmentsAndImportIdentity() {
        TransactionRecord record = new TransactionRecord();
        record.id = 42;
        record.timestamp = 100;
        record.merchant = "Old merchant";
        record.type = TransactionRecord.EXPENSE;
        record.category = "Other";
        record.amountCents = 1_000;
        record.note = "Keep until replaced";
        record.documentPath = "/secure/receipt.bin";
        record.documentMime = "image/jpeg";
        record.sourceFingerprint = "original-import-fingerprint";

        TransactionBulkEdit edit = new TransactionBulkEdit();
        edit.replaceMerchant = true;
        edit.merchant = "New merchant";
        edit.replaceTypeAndCategory = true;
        edit.type = TransactionRecord.EXPENSE;
        edit.category = "Groceries";
        edit.replaceBudgetInclusion = true;
        edit.excludeFromBudget = true;
        edit.apply(record);

        assertEquals("New merchant", record.merchant);
        assertEquals("Groceries", record.category);
        assertEquals(1_000, record.amountCents);
        assertEquals(100, record.timestamp);
        assertEquals("Keep until replaced", record.note);
        assertTrue(record.excludeFromBudget);
        assertEquals("/secure/receipt.bin", record.documentPath);
        assertEquals("image/jpeg", record.documentMime);
        assertEquals("original-import-fingerprint", record.sourceFingerprint);
    }

    @Test public void canClearNotesAndAccountAssociation() {
        TransactionRecord record = new TransactionRecord();
        record.note = "Old note";
        record.bankName = "Bank";
        record.accountName = "Checking ••••1234";
        record.accountId = "old-account";

        TransactionBulkEdit edit = new TransactionBulkEdit();
        edit.replaceNote = true;
        edit.note = "";
        edit.replaceAccount = true;
        edit.apply(record);

        assertEquals("", record.note);
        assertEquals("", record.bankName);
        assertEquals("", record.accountName);
        assertEquals("", record.accountId);
        assertTrue(edit.hasChanges());
        assertFalse(new TransactionBulkEdit().hasChanges());
    }

    @Test public void replacesAmountDateNoteAndAccountWithStableIdentity() {
        TransactionRecord record = new TransactionRecord();
        TransactionBulkEdit edit = new TransactionBulkEdit();
        edit.replaceAmount = true;
        edit.amountCents = 12_345;
        edit.replaceTimestamp = true;
        edit.timestamp = 987_654L;
        edit.replaceNote = true;
        edit.note = "  Reviewed manually  ";
        edit.replaceAccount = true;
        edit.bankName = "Example Bank";
        edit.accountName = "Checking ••••2468";
        edit.apply(record);

        assertEquals(12_345, record.amountCents);
        assertEquals(987_654L, record.timestamp);
        assertEquals("Reviewed manually", record.note);
        assertEquals("Example Bank", record.bankName);
        assertEquals("Checking ••••2468", record.accountName);
        assertEquals(BankAccountIdentity.stableId("Example Bank", "Checking ••••2468"),
                record.accountId);
    }
}
