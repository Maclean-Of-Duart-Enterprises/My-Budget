# My Budget for Android

`com.macleanofduartenterprises.mybudget`

My Budget is a privacy-first Android budgeting app. Transactions, learned budgets, OCR results, receipts, paystubs, appearance settings, and reports are processed and stored locally. The app does not request internet access.

## Included features

- Income and expense transaction records with search and customizable sorting
- Fully customizable income and expense category lists: add, rename, remove, and reorder any category, including every original category; related transactions and manual limits move safely with category changes
- Manual transaction management for one or many records: select all shown, fully edit/replace one transaction, replace only checked fields across several transactions, or delete selected records together
- Bulk replacement controls for merchant/source, amount, type/category, date, note, bank-account association, and AI budget/report inclusion; unselected fields and encrypted attachments remain unchanged
- Receipt and paystub import from the camera, images, or PDFs, including multi-select photo/PDF batches
- Multi-select bank-statement image/PDF upload with on-device extraction of multiple dated income and expense rows
- Improved two-pass OCR for faint or low-contrast statement text, with higher-resolution PDF rendering and a memory-safe fallback
- Automatic bank, account type, and masked account-number recognition, plus an editable account identity before import
- A required review screen with row selection and editable merchant, amount, type, category, date, and budget/report inclusion before statement transactions are saved
- Bundled on-device OCR with editable extraction results
- Complete in-app language management for English, Russian, Ukrainian, Kazakh, and Spanish
- Localized navigation, settings, categories, alerts, agent insights, dates, PDF reports, and CSV exports
- Bundled Cyrillic OCR models and multilingual receipt, paystub, and bank-statement parsing for the five app languages
- Encrypted financial-document storage using an Android Keystore AES-GCM key
- Clickable transactions that reopen the attached receipt, paystub, or shared source bank statement
- A deterministic local learning agent that:
  - normalizes recent spending into category-level monthly limits
  - gives essentials a small buffer and trims discretionary averages
  - detects recent trends and likely recurring charges
  - balances learned limits against recorded income and a savings reserve
  - uses reviewed income and expense transactions imported from bank statements
  - combines multiple bank accounts into one canonical history, skips re-imported duplicates, and excludes matched internal transfers
  - flags unusually large transactions for review
- Weekly and monthly reports with prior-period comparisons and a customizable first day of the week
- Independent weekly or monthly reports for any selected income or expense category, including focused PDF creation
- Separate weekly and monthly local-agent budgets with category limits, expected income, and savings targets
- Separate editable manual weekly and monthly budgets for income, savings, and category limits alongside the matching AI suggestion
- One-tap copying of the matching weekly or monthly learned AI plan into the manual editor as a starting point
- Locally generated PDF reports plus PDF and CSV transaction exports
- Background colors/photos with 1–100% photo opacity
- Text color, text-box color, 1–100% text-box opacity, and 12–36sp text size
- Avatar upload/removal
- PBKDF2-hashed 4–12 digit app passcode, a manual **Lock now** control, and customizable background-lock delays
- Cache cleanup, orphan-document cleanup, storage usage, and full local-data deletion

## Build

Open the project folder in a current Android Studio version and build the `app` module, or run:

```bash
./gradlew testDebugUnitTest assembleDebug
```

Requirements: Java 17, Android SDK Platform 35, and Android Build Tools 35.0.1.

## Install the included APK

1. Copy `MyBudget-Android-1.7.2.apk` to an Android 8.0 or newer phone or tablet.
2. Open the APK from the device's Files app.
3. If Android asks, allow that Files app to install unknown apps, then choose **Install**.
4. Open **My Budget**. Choose a language under **Settings → Language management**, then add a passcode under **Settings → Passcode** before entering financial records.

The included APK is universal (ARM64, ARMv7, x86, and x86_64), release-optimized, and signed for sideloading with the same bundled non-production continuity key as versions 1.3.0–1.7.2. The source archive contains that key so later private builds can remain update-compatible through version 1.7.2. It must never be used for store or public distribution.

The originally distributed 1.0.0–1.2.0 test APKs used a temporary key that is no longer available. Android therefore cannot install this 1.7.2 build over those original APKs. A replacement-key 1.2.0 build was supplied with the same bundled key as versions 1.3.0–1.7.2; an in-place update works from that specific replacement build. Moving from an original build still requires uninstalling it first, which removes its private database, encrypted documents, and Android Keystore key.

## Important behavior

- OCR and document classification are local conveniences, not accounting verification. Every extracted merchant, amount, date, category, and pay figure remains editable and should be checked against the source document.
- The “AI agent” is an explainable adaptive statistical model rather than a cloud language model. This keeps financial history offline and avoids API keys, subscriptions, and external transmission.
- The packaged app declares no Internet or network-state permissions. Optional ML Kit telemetry permissions and scheduling components are explicitly removed.
- Imported documents are encrypted inside app-private storage. Android backups are disabled. Uninstalling the app removes its database, Keystore key, and private documents.
- Receipt/paystub PDF OCR analyzes the first three pages. Bank-statement OCR analyzes up to the first 12 pages. The attached PDF viewer can display every page.
- Bank-statement parsing is deliberately conservative: dated rows may span several OCR lines, month-name dates and common number-character confusions are normalized, and no row is saved until the user reviews and confirms it.
- Each statement is assigned to a locally derived bank-account identity. Re-imported statement rows are skipped by an account-aware fingerprint, and likely transfers between two imported accounts are omitted from budget/report math to avoid double-counting. Both the identity and each row's inclusion remain editable.
- Multi-selected receipts/paystubs are processed one at a time for review; multi-selected bank statements are likewise reviewed sequentially so every imported transaction stays linked to the correct encrypted source file.
- Select the document's language under **Settings → Language management** before scanning. English and Spanish use the bundled Latin recognizer; Russian, Ukrainian, and Kazakh use their matching bundled Tesseract model.
- The recognizers are intended for printed text. Handwriting, unusual fonts, or low-quality photographs may require manual correction.

## License

Copyright © 2026 Maclean Of Duart Enterprises.

My Budget is free software licensed under version 3 of the GNU Affero General Public License (`AGPL-3.0-only`). The complete license is included in `LICENSE.txt` and can be read offline inside the app under **Settings → License**. The complete corresponding source code is distributed with this release. Third-party components remain governed by the licenses listed in `THIRD_PARTY_NOTICES.md`.

## Release signing

The included release APK is suitable for private testing and sideloading. The bundled continuity key and its public development password preserve update compatibility but provide no publisher security. Before public distribution, create a protected production keystore, configure release signing outside version control, and distribute through a trusted store or managed channel.
