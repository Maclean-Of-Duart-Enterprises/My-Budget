# My Budget 1.7.1

## Fully customizable category lists

- Every income and expense category can now be renamed, removed, and reordered, including all original categories.
- Added categories use the same controls as original categories; each list always retains at least one category.
- Existing matching transactions move with a renamed category without changing amounts, dates, notes, bank-account associations, or attachments.
- Removing a category safely moves its transactions and weekly/monthly manual limits into another remaining category shown in the confirmation dialog.
- Category order is stored locally and reused in transaction entry, bulk editing, statement review, manual budgets, reports, and category selectors.
- Existing custom categories from version 1.7.0 migrate automatically into the new ordered lists.

## Recognition, reports, and budgets

- Receipt and bank-statement category suggestions follow renamed or removed original categories instead of recreating the original labels.
- Independent category reports continue to point to the renamed category, or to the selected fallback when a category is removed.
- The local AI budget preserves its essential-category safety cushion after an original essential category is renamed.
- Customized category names remain literal across the five interface languages, including names that resemble a translated built-in label.

## Privacy and release identity

- All category migration, OCR mapping, budgets, reports, and transaction updates remain on the device.
- The app still declares no Internet or network-state permission.
- Package: `com.macleanofduartenterprises.mybudget`
- Version code/name: `9` / `1.7.1`
- Unit tests: 41 passed
- Android lint: passed with no errors or warnings
- Minified release build: passed
- APK Signature Scheme v2: verified
- Signing certificate SHA-256: `2B:8B:C4:8C:FC:F4:F0:17:0A:80:F9:AA:10:60:5F:59:8F:EF:87:7C:1D:E0:16:68:1D:0B:B4:15:D8:F4:2F:A0`

The bundled continuity key already present in the source was used. It matches the supplied 1.6.0 APK, so the separately supplied fallback `release.keystore` was not used or added to the source.
