# My Budget 1.7.0

## Custom income and expense categories

- Adds a **Category management** section under Settings.
- Users can create independent custom income and expense categories.
- Custom categories appear in manual transaction entry, single and bulk editing, bank-statement review, manual budgets, local-agent budgets, charts, exports, and reports.
- Custom categories can be renamed. Existing matching transactions and weekly/monthly manual category limits are updated without changing amounts, dates, notes, bank-account associations, or attachments.
- Custom categories can be removed after confirmation. Existing records and manual limits are safely moved to **Other** or **Other income**.
- Built-in categories remain available and continue to use the app's five-language translations. User-created names are preserved exactly.

## Weekly report control and category reports

- Adds a selectable first day of the week under **Settings → Weekly report settings**.
- Weekly report and budget boundaries use local calendar dates, including daylight-saving transitions.
- Adds an independent **Category** report mode for any income or expense category.
- Category reports can use either the current week or current month and can be generated as focused local PDF files.

## Weekly and monthly budgets

- Adds distinct weekly and monthly manual budgets with separate expected income, savings target, and category limits.
- Preserves and migrates the existing 1.6.0 manual monthly budget automatically.
- Adds weekly local-agent budgets derived consistently from the learned monthly plan.
- The dashboard and report pages can switch between weekly and monthly manual and AI budgets.
- The manual editor can copy the matching weekly or monthly AI suggestion as a starting point.

## Privacy and reliability

- Keeps all category, budget, transaction, OCR, and report processing on the device.
- Adds explicit Android cloud-backup and device-transfer exclusions for financial data.
- Adds Android 13 monochrome launcher-icon support.
- The app still declares no Internet or network-state permission.

## Release identity and verification

- Package: `com.macleanofduartenterprises.mybudget`
- Version code/name: `8` / `1.7.0`
- Unit tests: 36 passed
- Android lint: passed with no errors or warnings
- Minified release build: passed
- APK Signature Scheme v2: verified
- Network permissions: none
- Signing certificate SHA-256: `2B:8B:C4:8C:FC:F4:F0:17:0A:80:F9:AA:10:60:5F:59:8F:EF:87:7C:1D:E0:16:68:1D:0B:B4:15:D8:F4:2F:A0`

The signing certificate exactly matches the supplied 1.6.0 APK, allowing an in-place update from that build. The separately supplied fallback `release.keystore` was not used or added to the source.
