# Third-party notices

My Budget includes the following components for fully local document recognition:

- Google ML Kit Text Recognition (`com.google.mlkit:text-recognition:16.0.1`) and its transitive dependencies. See the licenses bundled with those artifacts.
- Tesseract4Android (`cz.adaptech.tesseract4android:tesseract4android:4.9.0`), licensed under the Apache License 2.0.
- Russian, Ukrainian, and Kazakh trained-data files from the official `tesseract-ocr/tessdata_fast` project, licensed under the Apache License 2.0.

The bundled OCR models are used on the device. My Budget does not download a model or upload a financial document.
