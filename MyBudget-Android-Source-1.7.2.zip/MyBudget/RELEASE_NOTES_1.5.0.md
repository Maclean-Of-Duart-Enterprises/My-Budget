# My Budget 1.5.0

## Bank-statement intelligence

- Uses a second, locally enhanced OCR pass when the first pass has weak statement text.
- Renders statement PDFs at a higher working resolution and safely falls back on low-memory devices.
- Reconstructs transaction rows split across several OCR lines.
- Corrects common OCR number substitutions and reads numeric or localized month-name dates.
- Recognizes the bank, account type, and masked account ending from the statement header; the user can edit this identity before import.

## Multi-account history, budgets, and reports

- Saves bank and account identity with every imported statement transaction.
- Combines transactions from multiple accounts into a filterable history.
- Uses account-aware fingerprints to skip statement rows that were already imported.
- Detects matching transfers between imported accounts and excludes both sides from income, expense, budget, and report calculations.
- Lets the user manually include or exclude any transaction from AI budget/report calculations.
- Shows account and statement coverage in learned budgets, weekly reports, monthly reports, PDF reports, CSV exports, and PDF transaction exports.

## Verification

- Package: `com.macleanofduartenterprises.mybudget`
- Version code/name: `6` / `1.5.0`
- Minimum/target Android API: `26` / `35`
- Unit tests: 29 passed
- Android lint: passed with no errors
- APK Signature Scheme v2: verified
- Signing certificate SHA-256: `2B:8B:C4:8C:FC:F4:F0:17:0A:80:F9:AA:10:60:5F:59:8F:EF:87:7C:1D:E0:16:68:1D:0B:B4:15:D8:F4:2F:A0`

The bundled key is the replacement local-development key used by the supplied replacement-key 1.2.0 and versions 1.3.0–1.5.0. It is not the unavailable original certificate beginning `E9:B9:EA:2B` and must not be used for public distribution.
