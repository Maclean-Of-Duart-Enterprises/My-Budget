# My Budget 1.6.0

## Manual transaction management

- Adds an explicit **Manage transactions** mode with accessible checkboxes for selecting one or many records.
- A single selected transaction opens the complete editor, including merchant/source, amount, type, category, date, note, bank-account association, AI inclusion, and attachment replacement or removal.
- Multiple selected transactions can replace only user-checked fields: merchant/source, amount, type/category, date, note, bank account, or AI budget/report inclusion.
- Bulk edits preserve all unchecked values, encrypted attachments, and original statement-import fingerprints.
- **Select all shown** respects the current search and bank-account filter.
- Selected transactions can be deleted together after confirmation. Encrypted documents are removed only when no remaining transaction references them.
- Bulk updates and deletions use local database transactions so the selected operation completes atomically.

## Release identity

- Package: `com.macleanofduartenterprises.mybudget`
- Version code/name: `7` / `1.6.0`
- Unit tests: 32 passed
- Android lint: passed with no errors
- APK Signature Scheme v2: verified
- Network permissions: none
- Signing certificate SHA-256: `2B:8B:C4:8C:FC:F4:F0:17:0A:80:F9:AA:10:60:5F:59:8F:EF:87:7C:1D:E0:16:68:1D:0B:B4:15:D8:F4:2F:A0`

The source bundle includes the replacement local-development key used by the supplied replacement-key 1.2.0 and versions 1.3.0–1.6.0. It is not the unavailable original certificate beginning `E9:B9:EA:2B`.
