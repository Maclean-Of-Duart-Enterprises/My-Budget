# My Budget 1.7.2

## AGPLv3 license access

- Added a dedicated **License** section under Settings.
- Added a readable offline license page containing the complete GNU Affero General Public License version 3 text.
- Added the copyright and no-warranty notice, plus corresponding-source availability information.
- Added the authoritative `LICENSE.txt` file to the complete source package.
- Added localized license navigation and explanatory notices for English, Russian, Ukrainian, Kazakh, and Spanish. The authoritative full license remains the unchanged English text.

## Existing functionality preserved

- Customizable income and expense categories, reports, weekly/monthly manual budgets, and local AI budgets are unchanged.
- Financial records, OCR, reports, budgets, and encrypted documents continue to remain on the device.
- The app continues to request no Internet or network-state permission.
- Package: `com.macleanofduartenterprises.mybudget`
- Version code/name: `10` / `1.7.2`
- Signing identity: the bundled continuity key used by versions 1.3.0–1.7.1 is retained for in-place updates.

## Verification

- Unit tests: 42 passed, including the bundled-license and license-localization check.
- Android lint: passed with no issues.
- R8 minification and release resource shrinking: passed.
- The APK contains the complete 33,862-byte `assets/LICENSE.txt`, byte-for-byte matching the source `LICENSE.txt`.
- APK Signature Scheme v2: verified.
- Signing certificate SHA-256: `2B:8B:C4:8C:FC:F4:F0:17:0A:80:F9:AA:10:60:5F:59:8F:EF:87:7C:1D:E0:16:68:1D:0B:B4:15:D8:F4:2F:A0`.
- The signing certificate exactly matches version 1.7.1.
- No Internet or network-state permission is present.
