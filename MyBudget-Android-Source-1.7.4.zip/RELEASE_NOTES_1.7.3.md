# My Budget 1.7.3

## Tracker-free OCR replacement

- Removed Google ML Kit Text Recognition and its complete transitive runtime dependency chain.
- Removed `MlKitInitProvider`, `MlKitComponentDiscoveryService`, Google Play services metadata/activity entries, Firebase component registration, and Google Data Transport components.
- Replaced English and Spanish ML Kit OCR with bundled open-source Tesseract models.
- English, Spanish, Russian, Ukrainian, and Kazakh now use the same fully local Tesseract OCR path.
- Preserved two-pass image enhancement, multi-page PDF recognition, bank-statement review, and editable OCR results.

## Privacy and compatibility

- No Internet or network-state permission is declared.
- No Google ML Kit, Google Play services, Firebase, or Google Data Transport code is packaged.
- OCR models are bundled with the APK and no financial document leaves the device.
- Existing transactions, documents, categories, reports, budgets, appearance, passcode, and AGPLv3 license access are unchanged.
- Package: `com.macleanofduartenterprises.mybudget`
- Version code/name: `11` / `1.7.3`
- The version 1.7.2 signing identity is retained for an in-place update.

## Verification

- 43 unit tests passed with no failures, errors, or skipped tests.
- Android lint reported no issues.
- The optimized release build completed with R8 and resource shrinking enabled.
- The compiled APK declares no permissions, including Internet or network-state access.
- Compiled manifest and DEX inspection found no ML Kit, Google Play services, Firebase, or Google Data Transport runtime or components.
- The runtime dependency tree contains only Tesseract4Android and AndroidX annotations.
- English, Spanish, Russian, Ukrainian, and Kazakh Tesseract models are bundled in the APK.
- ARM64, ARMv7, x86, and x86_64 native libraries are included.
- APK Signature Scheme v2 and 4-byte ZIP alignment verified.
- Signing certificate SHA-256: `2b8bc48cfcf4f0170a80f9aa10605f598fef877c1de016681d0bb415d8f42fa0` (matches version 1.7.2).
- APK SHA-256: `9ed41e156a4f8cd36b88660af910cde1e929f351ea7212543dd6873206a5afe2`.
