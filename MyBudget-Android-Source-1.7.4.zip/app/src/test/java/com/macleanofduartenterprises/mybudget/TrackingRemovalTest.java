package com.macleanofduartenterprises.mybudget;

import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class TrackingRemovalTest {
    @Test public void googleTrackingRuntimeIsAbsentAndTesseractCoversEveryLanguage() throws Exception {
        String build = read("build.gradle");
        String manifest = read("src/main/AndroidManifest.xml");
        String engine = read("src/main/java/com/macleanofduartenterprises/mybudget/OcrEngine.java");
        String runtime = (build + manifest + engine).toLowerCase();

        assertFalse(runtime.contains("com.google.mlkit"));
        assertFalse(runtime.contains("com.google.android.gms"));
        assertFalse(runtime.contains("com.google.firebase"));
        assertFalse(runtime.contains("datatransport"));
        assertFalse(manifest.contains("android.permission.INTERNET"));
        assertFalse(manifest.contains("android.permission.ACCESS_NETWORK_STATE"));
        assertTrue(build.contains("cz.adaptech.tesseract4android:tesseract4android:4.9.0"));

        assertEquals("eng", OcrEngine.modelForLanguage(LanguageManager.ENGLISH));
        assertEquals("spa", OcrEngine.modelForLanguage(LanguageManager.SPANISH));
        assertEquals("rus", OcrEngine.modelForLanguage(LanguageManager.RUSSIAN));
        assertEquals("ukr", OcrEngine.modelForLanguage(LanguageManager.UKRAINIAN));
        assertEquals("kaz", OcrEngine.modelForLanguage(LanguageManager.KAZAKH));

        for (String model : new String[]{"eng", "spa", "rus", "ukr", "kaz"}) {
            Path trainedData = Paths.get("src/main/assets/tessdata", model + ".traineddata");
            assertTrue(model + " trained data is missing", Files.isRegularFile(trainedData));
            assertTrue(model + " trained data is unexpectedly small", Files.size(trainedData) > 1_000_000L);
        }
    }

    private static String read(String path) throws Exception {
        return new String(Files.readAllBytes(Paths.get(path)), StandardCharsets.UTF_8);
    }
}
