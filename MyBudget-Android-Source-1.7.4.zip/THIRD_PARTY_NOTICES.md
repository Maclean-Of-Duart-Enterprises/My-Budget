# Third-party notices

My Budget includes the following components for fully local document recognition:

- Tesseract4Android (`cz.adaptech.tesseract4android:tesseract4android:4.9.0`), licensed under the Apache License 2.0.
- English, Spanish, Russian, Ukrainian, and Kazakh trained-data files from the official `tesseract-ocr/tessdata_fast` project, licensed under the Apache License 2.0.

The bundled OCR engine and models are used entirely on the device. My Budget does not include Google ML Kit or another tracking SDK, does not download an OCR model, and does not upload a financial document.
