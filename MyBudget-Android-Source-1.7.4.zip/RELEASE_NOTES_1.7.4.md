# My Budget 1.7.4
- Settings → Appearance → Theme: Light, Dark, Automatic (follows phone), default Automatic.
- Separate custom color preferences for light and dark; existing colors retained for light. Shared photo, opacity and text size preferences retained.
- Native dialogs and controls use the selected theme. Android configuration changes recreate activities; existing passcode startup policy remains in effect.
- Build not verified: Gradle distribution unavailable in preparation environment.
